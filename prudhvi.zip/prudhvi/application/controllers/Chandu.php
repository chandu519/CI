<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chandu extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->database();

		$this->load->model('chandu_model');
	}
	public function index()
	{
		$params = array('id' => 4, "b_status" => 1 );
		$data = $this->chandu_model->getBanners($params);
		$data['bannerData'] = $data; 
		//echo "<pre>"; print_r($data);exit;
		//$data = array('name' => 'Chandu');
		//echo "<pre>"; print_r($data);
		$this->load->view('chandu',$data);
		//$this->load->view('chandu',$data);
	}

	public function add(){
		$this->load->view('add',$data);
	}

	public function update(){
		$this->load->view('update',$data);
	}

	public function delete(){
		$this->load->view('delete',$data);
	}
}

