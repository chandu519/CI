<?php
Class Chandu_model extends CI_Model {

	public function __construct() {
		parent::__construct();
		$this->load->database();
	}

	public function getBanners($params = NULL){
		$this->db->select('*');
		$this->db->from('pre_banner');
		
		$this->db->where($params);

		$query = $this->db->get();
		$data = $query->result_array();
		return $data;	
	}

}

?>