<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_products";
$pageHeading="Products";
$pageAdd="addProducts.php";
$pageList="Products.php";

if(isset($_POST["addBanner"]) && $_POST["addBanner"]=="Submit"){
 
	$name=str_replace("'","",$_POST['txtName']);
	$gross=mysqli_real_escape_string($mysqli,$_POST['txtGross']);
	$qty=mysqli_real_escape_string($mysqli,$_POST['txtQty']);
	$category=mysqli_real_escape_string($mysqli,$_POST['txtCategory']);

	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		echo  $sql = "update $tableName set prod_name='".$name."',gross='".$gross."',qty='".$qty."',category='".$category."',dt_updated=now() where inc_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		echo  $sql="insert into $tableName(prod_name, gross, qty, category,status,dt_created)values('".$name."','".$gross."','".$qty."','".$category."','1',now())";
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			echo $error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_id, prod_name, gross, qty, category from $tableName where inc_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det2,$det3,$det4,$det5);
											$cat->fetch();											
											//$det3 = base64_decode($det3);
											$det3 = str_replace('\"', '"', $det3);
											$det3 = str_replace("\'", "'", $det3);					
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 

								<div class="wrapper" style=""> 
									<div class="flabel">
										<label for="folder"> Category</label>
									</div>
									<div class="finput">
									<select name="txtCategory" type="text" value="" class="" id="txtCategory" >
										<option>Select Category</option>
										<?php foreach ($items as $key => $value) {
											
									?>
										<option value="<?=$value?>"><?=$value?></option>
									<?php }?>
									</select>
									</div>
								</div>

								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Product Name</label>
									</div>
									<div class="finput">
									<input name="txtName" type="text" value="<?=@$det2?>" class="" id="txtName" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Gross / Weight</label>
									</div>
									<div class="finput">
									<input name="txtGross" type="text" value="<?=@$det3?>" class="" id="txtGross" >
									</div>
								</div>
								<!--<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Qty</label>
									</div>
									<div class="finput">
									<input name="txtQty" type="text" value="<?=@$det4?>" class="" id="txtQty" >
									</div>
								</div>-->
									
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addBanner" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>