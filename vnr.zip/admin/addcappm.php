<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details

$tableName="ppm_cappm";
$pageHeading="CA PPM";
$pageAdd="addcappm.php";
$pageList="cappm.php";

if(isset($_POST["subBanner"]) && $_POST["subBanner"]=="Submit"){
 
	$name=str_replace("'","",$_POST['txtName']);
	$content=mysqli_real_escape_string($mysqli,$_POST['txtContent']);
	//$content=str_replace("'","", $_POST['txtContent']);
	$link=str_replace("'","",$_POST['txtLink']);
	$videolink=str_replace("'","",$_POST['txtvideolink']);

	if($_FILES['txtImage']['name'] != ""){
		$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage');
		
		if($result){
			$imgName = $result;
			if(@$_POST['hid_image']!= ""){
				unlink(SITEDOC_ROOT_PATH."images/".$_POST['hid_image']);
			}
		}
	}else{
		$imgName = $_POST['hid_image'];
	}
	
	if($_POST['txtSeoTitle']!=""){$meta_title=base64_encode($_POST['txtSeoTitle']);}else{$meta_title=base64_encode($_POST['txtName']);}
	if($_POST['txtSeoKeywords']!=""){$meta_keywords=base64_encode($_POST['txtSeoKeywords']);}else{$meta_keywords=base64_encode($_POST['txtName']);}
	if($_POST['txtSeoDesc']!=""){$meta_descr=base64_encode($_POST['txtSeoDesc']);}else{$meta_descr=base64_encode($_POST['txtName']);}
	
	
	
	
	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		$sql = "update $tableName set title='".$name."',image='".$imgName."',content='".$content."',link='".$link."',curl='0',videolink='".$videolink."',meta_title='".$meta_title."',meta_keywords='".$meta_keywords."',meta_descr='".$meta_descr."' where inc_cat_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		$sql="insert into $tableName(title,link,image,content,curl,status,dt_created,icon,videolink,meta_descr,meta_keywords,meta_title)values('".$name."','".$link."','".$imgName."','".$content."','0','1',now(),'".$imgName1."','".$videolink."','".$meta_descr."','".$meta_keywords."','".$meta_title."')";
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			echo $error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}
//Change status of Gallery Categories
if(@$_REQUEST['id'] != '' && @$_REQUEST['changeStat'] != ''){
	$bid = $_REQUEST['id'];
	$sql="update tbl_gal_cat set active_flag='".$_REQUEST['changeStat']."' where inc_cat_id=?";
	if ($stmt = $mysqli->prepare($sql)){
		$si='i';
		$stmt->bind_param($si,$bid);
		//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		$flag=$stmt->execute();
		if($flag){
			$_SESSION['stat']="SE";
			$allClasses->forRedirect ($pg);
			exit;
		}else{
			$_SESSION['stat']="FE";
			$allClasses->forRedirect ($pg);
			exit;
		}
	}
}
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	$img=$_REQUEST['img'];
	unlink(SITEDOC_ROOT_PATH."images/".$img);
	$flag=mysqli_query($mysqli,"update $tableName set image='' where inc_cat_id='".$id."'");
	if($flag){
		$_SESSION['stat']="SD";		
	}else{
		$_SESSION['stat']="FD";
	}
	$allClasses->forRedirect ($pageList);
	exit;
}


?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_cat_id,title,link,image,content,curl,icon,videolink,meta_descr,meta_keywords,meta_title from $tableName where inc_cat_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det2,$det3,$det4,$det5,$det6,$det7,$det8,$det11,$det10,$det9);
											$cat->fetch();											
											//$det3 = base64_decode($det3);
											$det3 = str_replace('\"', '"', $det3);
											$det3 = str_replace("\'", "'", $det3);																						
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Title</label>
									</div>
									<div class="finput">
									<input name="txtName" type="text" value="<?=@$det2?>" class="" id="txtName" required>
									</div>
								</div>
								<div class="wrapper" style="display:none;">
									<div class="flabel">
										<label for="folder"> Link</label>
									</div>
									<div class="finput">
									<input name="txtvideolink" type="text" value="<?=@$det8?>" class="" id="txtvideolink" >
								</div>
								</div>
								<div class="wrapper">
									<div class="flabel">
										<label for="folder">Image </label>
									</div>
									<div class="finput">
										<input type="file" name="txtImage" id="txtImage" accept="image/*">
									</div>
								</div>
								<?php
								if(@$det4!=''){
									echo '<input type="hidden" name="hid_image" value="'.$det4.'">';	
									?>
									<div class="wrapper" style="margin-bottom:10px">
										<div class="flabel">
											<label for="folder"></label>
										</div>
										<div  class="finput">
											<a  href="../images/<?=$det4?>" target="_blank" alt="" title=""><img style="background-color:#333; padding:10px;"  src="../images/<?=$det4?>" width="100" ></a>
										</div>
									</div>									
									<?php 
								}
								?>	

								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
									<textarea name="txtContent" type="text"  class="" id="txtContent" ><?=@$det5?></textarea>
								</div>
								</div>
								
								
								
								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="subBanner" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>