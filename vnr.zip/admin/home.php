<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 
?>
<!doctype html>
<html>
    <head>
    <!-- META DATA -->
    <?php include "includes/ui_meta_tags.php";  ?>                
    </head>
    <body>
        <?php include_once "includes/ui_header.php"; ?>
    
	<style>
	.head10 {
    padding: 10px;
    text-align: center;
    font-size: 90px;
    color: #BBB;
    font-weight: 500;
    letter-spacing: 1px;
    line-height: 100px;
}
	</style>
	<div class="wrapper content_box">
        <div class="wrapper_inner">
            <div class="wrapper">
                <div class="side_menu" style="display: none;">
                <?php include_once "includes/admin_menu.php"; ?>    
                </div>
                <div class="content_block">
                    <!-- <div class="wrapper title"><h1>Dashboard</h1></div> -->
					
                    <div class="wrapper ">
					<div class="head10">
						Welcome to <br> <?=$pgTitle;?><br>Administration
					</div>
                    </div>               
                </div> 
            </div>
        </div>
    </div>
    <?php include_once "includes/ui_footer.php"; ?>      
    </body>
</html>