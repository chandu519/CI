<?php include_once "includes/config.php"; 
if(!isSet($_SESSION['admin_id'])){ $allClasses->forRedirect ("logout.php"); exit; }

//Table & Page Details
$tableName="tbl_admin_users";
$pageHeading="Employee List";
$pageAdd="addemployeeList.php";
$pageList="employeeList.php";

/*********************** Delete ***************************/
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	
	if($stmt1 = $mysqli->prepare("select u_id from $tableName where u_id=?")) {
		$stmt1->bind_param('i', $id);
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($inc_cat_id);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
		
			$sql="update $tableName set status=0,delete_flag=1 where u_id =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='i';
				$stmt->bind_param($s, $id);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}
				$allClasses->forRedirect ($pageList);
				exit;
			}
		}	
	}
}

/*********************** Stats Change Active/Disabled ***************************/
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select u_id from $tableName where u_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
				$stmt->bind_result($inc_cat_id);
				$stmt->fetch();				
				$sq="update $tableName set status=? where u_id=?";
				if ($stm = $mysqli->prepare($sq)){
					$ii='ss';
					$stm->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stm->execute();					
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";						
					}else{
						$_SESSION['stat']="FE";					
					}
					$allClasses->forRedirect ($pageList);
					exit;
				}
			}
		}
	}
}

/*********************** Employee View/Download ***************************/
if(@$_REQUEST['action']!="" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['action']=="view"){
		$sq="update $tableName set image=1 where u_id=?";
	}
	if(@ $_REQUEST['action']=="noview" || @ $_REQUEST['action']=="nodownload"){
		$sq="update $tableName set image='' where u_id=?";
	}
	if(@ $_REQUEST['action']=="download"){
		$sq="update $tableName set image=2 where u_id=?";
	}
	
	$sql="select u_id from $tableName where u_id=?";
	if ($stmt = $mysqli->prepare($sql)){
		$i='i';
		$stmt->bind_param($i,$_REQUEST['id']);
		$flag=$stmt->execute();
		$stmt->store_result();
		if($stmt->num_rows>0){
			$stmt->bind_result($inc_cat_id);
			$stmt->fetch();				
			
			if ($stm = $mysqli->prepare($sq)){
				$ii='s';
				$stm->bind_param($ii,$_REQUEST['id']);
				$flag=$stm->execute();					
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				if($flag){
					$_SESSION['stat']="SE";						
				}else{
					$_SESSION['stat']="FE";					
				}
				$allClasses->forRedirect ($pageList); exit;				
			}
		}
	}	
	
}
?>
<!doctype html>
<html>
	<head>
	<!-- META DATA -->
	<?php include "includes/ui_meta_tags.php";	?>        
<style>	
.viewBtn {
	font-size: 14px;
	color: #fff !important;
	font-size: 14px !important;
	font-weight: 500;
	background: #29c6ca;
	padding: 5px 15px;
	border-radius: 3px;
	transition: all .5s;
	margin:0 !important;
}
.dlBtn{
	background: #95ca29;
}
</style>	
	</head>
    <body>
		<?php include_once "includes/ui_header.php"; ?>
     
    <div class="wrapper content_box">
        <div class="wrapper_inner">
            <div class="wrapper">
                <div class="side_menu">
                    <?php include_once "includes/admin_menu.php"; ?>    
                </div>
                <div class="content_block">
                    <div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                        <ul class="braeds">
                            <li><a href="home.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
                            <li><a><?=$pageHeading?></a></li>
                        </ul>
                    </div>
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>	 
	
                    <div class="wrapper table ">
											<div class="wrapper">
												<a href="addemployeeList.php" class="addNew">Add New Employee</a>
											</div>
<?php 
	$query = "SELECT u_id, name, email, password, mobile, image, dob, dt_created, dt_modified, modified_by, status, delete_flag, fullname FROM $tableName WHERE u_id!=1 ORDER BY u_id DESC";
$res=mysqli_query($mysqli,$query);	
if(mysqli_num_rows($res)>0){ 
	?>                    
                        <div id="tableWrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>SNo</th>							
									<th>name</th>
									<th>Email</th>
									<th>Username / Password</th>
									<th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
<?php 
$i=1;
while($row = mysqli_fetch_array($res)){  
$usr_id=$row['u_id'];


											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['u_id']?>"  />														
																<tr>
												<td><a href="javascript:void(0)"><?=$row['u_id']?></a></td>
												<td><?=$row['fullname']?></td>	
												<td><?=$row['email']?></td>
												<td><?=$row['name']?><br>pwd: <?=$row['password']?></td>												
												
																							
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
														<?php
														if($row['delete_flag']==0){
														if($row['status']=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
														}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
														}
														?>
														<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$row['u_id']?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
														<a class="editBranch"  title="Edit Branch" href="<?=$pageAdd?>?act=edit&id=<?=$row['u_id']?>"><i class="fa fa-pencil-square-o"></i></a>
																												
														<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['u_id']?>';return false;}" title="Remove Branch"><i class="fa fa-trash"></i></a>
<?php }else{
	?><a href="javascript:void(0)" class="btn btn-dark btn-sm disabled">Deleted</a><?php
} ?>
													</div>
												</td>
											</tr>	
<?php $i++;
	}
	?>			
<input type="hidden" name="hidTotal" value="<?=$i?>">	

                                 
                            </tbody>
                        </table>
                        </div>
                   
										<?php
}else { ?>
										<div class="wrapper no_docs_data">
												No data available to view
										</div>
<?php } ?>										
										 </div>
                </div> 
            </div>
        </div>
    </div>
	
	<?php include_once "includes/ui_footer.php"; ?>      

    
	</body>

</html>