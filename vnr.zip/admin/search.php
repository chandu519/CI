<?php include_once "includes/config.php"; 
if(!isSet($_SESSION['admin_id'])){ $allClasses->forRedirect ("logout.php"); exit; }

//Table & Page Details
$tableName="";
$pageHeading="Search";
$pageAdd="search.php";
$pageList="search.php";
?>
<!doctype html>
<html>
	<head>
	<!-- META DATA -->
	<?php include "includes/ui_meta_tags.php";	?>                
<style>	

</style>	
<link href="stylesheets/lity.min.css" rel="stylesheet">	
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>     
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">
					<div class="side_menu">
						<?php include_once "includes/admin_menu.php"; ?>    
					</div>
					<div class="content_block">
						<div class="wrapper title">
							<h1><?=$pageHeading?></h1>
							<ul class="braeds">
								<li><a href="home.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
								<li><a><?=$pageHeading?></a></li>
							</ul>
						</div>
						<div class="wrapper table table2">
							<div class="wrapper search_keyword">
								<span class="wrapper">Enter your search keyword here</span>
								<input type="text" name="txtSearch" id="txtSearch" class="wrapper selectBox" placeholder="enter fileno, mobile, name, email to search here..">
							</div>
							
							<div id="tableWrap">
								<table>
									<thead>
										<tr>
											<th>File No</th>
											<th>Name</th>		
											<th>Email</th>		
											<th>Phone</th>		
											<th>Proces Status</th>												
											<th>Action</th>
										</tr>
									</thead>
									<tbody id="resData">
										<tr>
											<td colspan="2" align="center" valign="center" id="loadingDiv"><i class="fa fa-spinner fa-pulse fa-5x"></i></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div> 
				</div>
			</div>
    </div>
	
	<?php include_once "includes/ui_footer.php"; ?>      
	</body>
<script>	
$("#tableWrap").hide();
$("#loadingDiv").hide();
$("#txtSearch").keyup(function (){
	var str=$("#txtSearch").val().trim();
	if(str!=''){		
		$("#tableWrap").show();
		//ajax call - fetch data
		//show
		$("#loadingDiv").show();
		$.ajax({url:"ajax.php",type: 'POST',data: {'action': 'getSearchResults', 'str': str},success:function(result){
			//console.log(result);
			//hide
			$("#loadingDiv").hide();
			$('#resData').html(result);
		}});		
	}else{
		$('#resData').html('');
		$("#tableWrap").hide();
	}
})
</script>	
<script src="js/lity.min.js"></script>
</html>