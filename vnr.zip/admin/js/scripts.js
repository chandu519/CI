// JavaScript Document
$(document).ready(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').addClass('up');
            $('.header').addClass('up');
        } else {
            $('.scrollup').removeClass('up');
            $('.header').removeClass('up');
        }
    });
    $('.scrollup').click(function() {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });

    // new WOW().init();
    $(".loginDiv:first").show();
    $('#popLogin li:first').addClass('active');
    $("#popLogin li").click(function(){
        $('#popLogin li').removeClass('active');
        $(this).addClass('active');
        var pTab = $(this).attr('rel');
        $(".loginDiv").hide();
        $("#"+pTab).show();
    });

    $('.showMore').click(function () {
        $(this).toggleClass('on');
        var pTab = $(this).attr('rel');
        $("."+pTab).toggleClass('on');     
    });

    $("ul.side_nav li a").each(function() {
        if ($(this).next().length > 0) {
            $(this).addClass("hassub");
        }
    });

    $('.side_nav li').click(function () {
        $('.submenu').slideUp('500');
        $('.side_nav li').removeClass('open'); 
        var text = $(this).find('.submenu');
        if (text.is(':hidden')) {
            text.slideDown('500');
            $(this).addClass('open');     
        } else {
            text.slideUp('500');
            $(this).removeClass('open');     
        } 
    });

    $(".micon").click(function() {
        $(this).toggleClass("open");
        $('.main_menu').toggleClass("open");
    });

    
    $(".addNew").click(function() {
        $('body').addClass("open");
        $('.general_popup').show();
        $('.popupOverlay').show();
        $('.general_model').hide();
        $('.addBranch_pop').show();
    });
    $(".pClose, .popupOverlay").click(function() {
        $('body').removeClass("open");
        $('.general_model').hide();
        $('.general_popup').hide();
        $('.popupOverlay').hide();
    });
		$(".msgC").click(function() {
        $(this).parent('.success_msg').hide();
    });

    $(".success_msg").delay(5000).fadeOut("slow");
});

$(document).on('click', '[data-lightbox]', lity);
