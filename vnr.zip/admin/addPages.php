<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="zsp_services";
$pageHeading="Services";
$pageAdd="addPages.php";
$pageList="viewPages.php";




?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form name="frmAddCategory" action="actions.php" method="post" onSubmit="return validate()" enctype="multipart/form-data">
									<?php
	function getOptions($id,$level,$mysqli){
		$query = "select * from tbl_pages where inc_cat_id='".$id."' order by priority asc";
		$result = mysqli_query($mysqli,$query);
		if(mysqli_num_rows($result)>0){
			$level=$level+1;
		}	
		while($row = mysqli_fetch_assoc($result)){
			$t=1;
			?>
			<option style="padding:4px 0px;" value="<?=$row['inc_prod_id']?>" class="level<?=$level?>" > <?php for($m=1;$m<=($level-1);$m++){ echo '&nbsp; &nbsp; '; } ?> <?=$row['prod_title']?></option>
			<?php
			getOptions($row['inc_prod_id'],$level,$mysqli);
			$t++;
		}
	}
?>	
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Category</label>
									</div>
									<div class="finput">
									<select name="cmbProductCat" class=""  id="cmbProductCat"  >
										<option value="" selected="selected">--Select--</option>
										<?php
											getOptions('0',0,$mysqli);
										?>
									</select>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Title</label>
									</div>
									<div class="finput">
									<input name="txtTitle" type="text" class=""  id="txtTitle" value="">
									</div>
								</div>
								<div class="wrapper"  style="display:none;">
									<div class="flabel">
										<label for="folder" > Link</label>
									</div>
									<div class="finput">
									<input type="text" class="form-control" name="" >
									</div>
								</div>
								<div class="wrapper" style="display:none;">
									<div class="flabel">
										<label for="folder">Image </label>
									</div>
									<div class="finput">
										<input name="txtImage[]" type="file" value="" class="" id="txtImage"  multiple>
									</div>
								</div>
								<?php
										if(@$det7!= ""){
											echo '<input type="hidden" name="hid_image" value="'.$det7.'">';	
											
												?>
									<div class="wrapper" style="margin-bottom:10px">
										<div class="flabel">
											<label for="folder"></label>
										</div>
										<?php 
										$det8A=explode(',',$det7);
											foreach(@$det8A as $k){
										?>
										<div class="finput">
											<a href="../images/<?=$det4?>" target="_blank" alt="" title=""><img src="<?=SITE_IMG_PATH.$k?>" width="100" ></a>
											<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$det1."&img_name=".@$k."&img_a=".$det7?>';return false;}" style="text-decoration:none;background:#eee;border-radius:5px;">
																	<i class="fa fa-times" style="color:#FF0000;font-size:12px;position:absolute;margin:80px 10px 10px -13px;" title="Delete"></i>
																</a>
										</div>
											<?php } ?>
									</div>									
									<?php 
								}
								?>	
								
								
								<div class="wrapper"  style="display:none;">
									<div class="flabel">
										<label for="folder"> Pdf</label>
									</div>
									<div class="finput">
									<input type="file" class="" name="txtPdf" accept="image/*"/>
									</div>
								</div>
								
								<div class="wrapper" style="margin-bottom:25px; display:none;">
									<div class="flabel">
										<label for="folder">Short Content</label>
									</div>
									<div class="finput">
										<textarea type="text" class="form-control" name="txtSContent"></textarea>
									</div>
								</div>
								<div class="wrapper" style="margin-bottom:25px; ">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
										<textarea type="text" class="form-control" name="txtContent"></textarea>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Seo Title</label>
									</div>
									<div class="finput">
									<input type="text" class="form-control" name="txtSeoTitle">
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Seo Keywords</label>
									</div>
									<div class="finput">
									<input type="text" class="form-control" name="txtSeoKeywords" >
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Seo Description</label>
									</div>
									<div class="finput">
									<input name="txtSeoDesc" id="txtSeoDesc" class="form-control">
									</div>
								</div>
									
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addPage" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>