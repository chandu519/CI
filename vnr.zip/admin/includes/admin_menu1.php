<ul class="side_nav">	
	<li class="<?php if($pg=='home.php') echo 'active'; ?>"><a href="home.php"> Home</a></li>
	<li class="<?php if($pg=='list.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Client Files</a>
		<ul class="submenu">
		<?php
		$om = "SELECT * FROM tbl_users where old_new_flag='0' ";
		$omres=mysqli_query($mysqli,$om);
		$omrows=mysqli_num_rows($omres);
		
		$nm = "SELECT * FROM tbl_users where old_new_flag='1'";
		$nmres=mysqli_query($mysqli,$nm);
		$nmrows=mysqli_num_rows($nmres);
		?>
		<li><a href="list.php?mid=0">Old Members (<?=$omrows?>)</a></li>	
		<li><a href="list.php?mid=1">New Members (<?=$nmrows?>)</a></li>	
		<li><a href="list.php">All (<?=$omrows + $nmrows?>)</a></li>	
		</ul>
	</li>
	
	<li class="<?php if($pg=='listsp.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Pending Options</a>
		<ul class="submenu">
		<?php 
		$sp = "SELECT * FROM tbl_user_tax_process where status='1' and dt_created!='' ";
		$spres=mysqli_query($mysqli,$sp);
		$sprows=mysqli_num_rows($spres);
		
		$ip = "SELECT * FROM tbl_user_tax_process where status='2' and dt_created!='' ";
		$ipres=mysqli_query($mysqli,$ip);
		$iprows=mysqli_num_rows($ipres);
		
		$pp = "SELECT * FROM tbl_user_tax_process where status='3' and dt_created!='' ";
		$ppres=mysqli_query($mysqli,$pp);
		$pprows=mysqli_num_rows($ppres);
		
		$payp = "SELECT * FROM tbl_user_tax_process where status='4' and dt_created!='' ";
		$paypres=mysqli_query($mysqli,$payp);
		$payrows=mysqli_num_rows($paypres);
		
		$tfcs = "SELECT * FROM tbl_user_tax_process where status='5' and dt_created!='' ";
		$tfcsres=mysqli_query($mysqli,$tfcs);
		$tfcsrows=mysqli_num_rows($tfcsres);
		
		$na = "SELECT * FROM tbl_user_tax_process where status='6' and dt_created!='' ";
		$nares=mysqli_query($mysqli,$na);
		$narows=mysqli_num_rows($nares);
		
		$efp = "SELECT * FROM tbl_user_tax_process where status='7' and dt_created!='' ";
		$efpres=mysqli_query($mysqli,$efp);
		$efprows=mysqli_num_rows($efpres);
		
		$pfp = "SELECT * FROM tbl_user_tax_process where status='8' and dt_created!='' ";
		$pfpres=mysqli_query($mysqli,$pfp);
		$pfprows=mysqli_num_rows($pfpres);
		
		$efd = "SELECT * FROM tbl_user_tax_process where status='9' and dt_created!='' ";
		$efdres=mysqli_query($mysqli,$efd);
		$efdrows=mysqli_num_rows($efdres);
		
		$pfd = "SELECT * FROM tbl_user_tax_process where status='10' and dt_created!='' ";
		$pfdres=mysqli_query($mysqli,$pfd);
		$pfdrows=mysqli_num_rows($pfdres);
		
		$c = "SELECT * FROM tbl_user_tax_process where status='11' and dt_created!='' ";
		$cres=mysqli_query($mysqli,$c);
		$crows=mysqli_num_rows($cres);
		
		$ta = "SELECT * FROM tbl_user_tax_process where dt_created!='' ";
		$tares=mysqli_query($mysqli,$ta);
		$tarows=mysqli_num_rows($tares);
		
	?>
			
			<?php
			$id1=1;
			$id1=base64_encode($id1);
			
			$id2=2;
			$id2=base64_encode($id2);
			
			$id3=3;
			$id3=base64_encode($id3);
			
			$id4=4;
			$id4=base64_encode($id4);
			
			$id5=5;
			$id5=base64_encode($id5);
			
			$id6=6;
			$id6=base64_encode($id6);
			
			$id7=7;
			$id7=base64_encode($id7);
			
			$id8=8;
			$id8=base64_encode($id8);
			
			$id9=9;
			$id9=base64_encode($id9);
			
			$id10=10;
			$id10=base64_encode($id10);
			
			$id11=11;
			$id11=base64_encode($id11);
				?>			
				<?php 
				$admin_access=explode(",",@$_SESSION['admin_access']);
				if(in_array("1", $admin_access) || $_SESSION['admin_id']=='admin'){?>
					<li><a href="list_allocated.php">To be allocated (<?=$tarows?>)</a></li>	
					<li><a href="listsp.php?id=<?=$id1?>">Schedule Pending (<?=$sprows?>)</a></li>	
				<?php }else{ ?>
					<li><a href="javascript:void(0);">To be allocated (<?=$tarows?>)</a></li>	
					<li><a href="javascript:void(0);">Schedule Pending (<?=$sprows?>)</a></li>	
				<?php } 
				if(in_array("2", $admin_access) || $_SESSION['admin_id']=='admin'){?>
					<li><a href="listsp.php?id=<?=$id2?>">Interview Pending (<?=$iprows?>)</a></li>	
				<?php }else{?>
					<li><a href="javascript:void(0);">Interview Pending (<?=$iprows?>)</a></li>	<?php } 
					if(in_array("3", $admin_access) || $_SESSION['admin_id']=='admin'){?>
					<li><a href="listsp.php?id=<?=$id3?>">Preparation Pending (<?=$pprows?>)</a></li>
					<?php }else{?>
					<li><a href="javascript:void(0);">Preparation Pending (<?=$pprows?>)</a></li>	
					<?php } 
						if(in_array("4", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
					<li><a href="listsp.php?id=<?=$id4?>">Payment Pending (<?=$payrows?>)</a></li>	
						<?php }else{?>
					<li><a href="javascript:void(0);">Payment Pending (<?=$payrows?>)</a></li>	
						<?php } 
						if(in_array("5", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id5?>">Tax Filling Copies Sent (<?=$tfcsrows?>)</a></li>	
						<?php } else{?>
			<li><a href="javascript:void(0);">Tax Filling Copies Sent (<?=$tfcsrows?>)</a></li>	
			<?php } 
						if(in_array("6", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id6?>">Need Approval (<?=$narows?>)</a></li>	
						<?php } else{?>
						<li><a href="javascript:void(0);">Need Approval (<?=$narows?>)</a></li>	
						<?php } ?>
			
		</ul>
	</li>
	
		<li class=""><a href="javascript:void(0);"><i class="fa fa-search"></i> Other Options</a>
		<ul class="submenu">
		<?php if(in_array("7", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id7?>">E Filling Pending (<?=$efprows?>)</a></li>
		<?php } else{?>
			<li><a href="javascript:void(0);">E Filling Pending (<?=$efprows?>)</a></li>
		<?php } if(in_array("8", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id8?>">Paper Filling Pending (<?=$pfprows?>)</a></li>	
			<?php } else{?>
			<li><a href="javascript:void(0);">Paper Filling Pending (<?=$pfprows?>)</a></li>	
			<?php } if(in_array("9", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id9?>">E Filling Done (<?=$efdrows?>)</a></li>	
			<?php } else{?>
			<li><a href="javascript:">E Filling Done (<?=$efdrows?>)</a></li>	
			<?php } if(in_array("10", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id10?>">Paper Filling Done (<?=$pfdrows?>)</a></li>	
			<?php }else{?>
			<li><a href="javascript:">Paper Filling Done (<?=$pfdrows?>)</a></li>	
			<?php } if(in_array("11", $admin_access) || $_SESSION['admin_id']=='admin'){	?>
			<li><a href="listsp.php?id=<?=$id11?>">Cancelled (<?=$crows?>)</a></li>	
			<?php } else{?>
			<li><a href="javascript:">Cancelled (<?=$crows?>)</a></li>	
			<?php } ?>
		</ul>
		</li>
</ul>