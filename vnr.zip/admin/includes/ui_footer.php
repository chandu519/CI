<footer>
	&copy <?=date('Y')?> <?=$pgTitle?> | All Rights Reserved
</footer>
<a href="javascript:void(0)" class="scrollup"><i class="fa fa-angle-up"></i></a>
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>



<!-- <script src="js/scripts.js" type="text/javascript"></script> -->
<script src="js/jquery.validate.min.js"></script>