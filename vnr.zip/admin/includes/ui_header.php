<div class="wrapper header"> 
    <div class="wrapper_inner">        
        <div class="micon"><span></span></div>
        
        <div class="logo">
            <a href="index.php">
                <img src="images/logo.jpg" alt="">
            </a>
        </div>
       
	  <!--  <div class="logo_text">
            Sri Venkateswara
            <span>Food & Beverages</span>
            <div class="line">Private limited</div>
        </div>-->
    </div>

    <div class="wrapper main_menu">
        <div class="wrapper_inner">
            <?php 
			 if($_SESSION['admin_type']==0){     
			include_once "includes/admin_menu2.php"; 
			 }else{ include_once "includes/admin_menu1.php"; }
			?> 
            <div class="notification">
                <ul>
                    <li><a href="javascript:void(0);" class="hassub"><i class="fa fa-user"></i><span>My Account</span></a>
                        <ul>
                            <li><a href="profile.php"><?=$_SESSION['admin_id']?></a></li>
                            <li><a href="changePassword.php">Change Password</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </li>                                            
                </ul>
            </div>  
        </div>
    </div>
</div>