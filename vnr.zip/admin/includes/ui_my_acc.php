<!--<h3 class="bars">My Account</h3>-->				
<div class="list-group list-group-alternate"> 
	<a href="dashboard.php" class="list-group-item <?php if($pg=='dashboard.php') echo 'active'; ?>">My Account</a> 
	<a href="leads.php" class="list-group-item <?php if($pg=='leads.php') echo 'active'; ?>">Leads</a> 
	<a href="addLead.php" class="list-group-item <?php if($pg=='addLead.php') echo 'active'; ?>">Add Hot Lead</a> 
	<a href="uploadLead.php" class="list-group-item <?php if($pg=='uploadLead.php') echo 'active'; ?>">Upload Lead Data</a> 
	<a href="logout.php" class="list-group-item">Logout</a> 						
</div>
