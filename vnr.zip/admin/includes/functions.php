<?php //SETTING CURRENT PAGE
if($_SERVER['QUERY_STRING'] != ""){
 	$current_page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
}else{
	$current_page = $_SERVER['PHP_SELF'];
}
//FINDING CURRENT PAGE	
$pg = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/')+1, strlen($_SERVER['PHP_SELF']));
if($_SERVER['QUERY_STRING'] != ""){
	$current_page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
}else{
	$current_page = $_SERVER['PHP_SELF'];
}

//WEBSITE TITLE
$siteTitle="Uniaway";

//BASE64DECODE CONVERT
if(!function_exists('base64decode')){
function base64decode($string){
	$string = base64_decode(trim($string));
	$string = str_replace('\"', '"', $string);
	return $string = str_replace("\'", "'", $string);
}
}
if(!function_exists('validate_mobile')){
//Mobile Number Validation
function validate_mobile($mobile)
{
	return preg_match('/^[0-9]{10}+$/', $mobile);
}
}
//Email Validation
if(!function_exists('validate_email')){
function validate_email($email)
{
	return filter_var($email, FILTER_VALIDATE_EMAIL);
}
}
if(!function_exists('hash_equals'))
{
	function hash_equals($str1, $str2)
	{
		if(strlen($str1) != strlen($str2))
		{
			return false;
		}
		else
		{
			$res = $str1 ^ $str2;
			$ret = 0;
			for($i = strlen($res) - 1; $i >= 0; $i--)
			{
					$ret |= ord($res[$i]);
			}
			return !$ret;
		}
	}
}
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
/*
$geopluginURL='http://www.geoplugin.net/php.gp?ip='.$ip;
$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
 
//Get City name by return array
$ip_city = $addrDetailsArr['geoplugin_city'];
 
//Get Country name by return array
$ip_country = $addrDetailsArr['geoplugin_countryName'];
*/
if(!function_exists('encode')){
function encode($value){
$key = sha1('$a!kUm@r');
if(!$value){return false;}
$strLen = strlen($value);
$keyLen = strlen($key);
$j=0;
$crypttext= '';
for ($i = 0; $i < $strLen; $i++) {
$ordStr = ord(substr($value,$i,1));
if ($j == $keyLen) { $j = 0; }
$ordKey = ord(substr($key,$j,1));
$j++;
$crypttext .= strrev(base_convert(dechex($ordStr + $ordKey),16,36));
}
return $crypttext;
}
}
if(!function_exists('decode')){
function decode($value){
    if(!$value){return false;}
        $key = sha1('$a!kUm@r');
        $strLen = strlen($value);
        $keyLen = strlen($key);
        $j=0;
        $decrypttext= '';
        for ($i = 0; $i < $strLen; $i+=2) {
            $ordStr = hexdec(base_convert(strrev(substr($value,$i,2)),36,16));
            if ($j == $keyLen) { $j = 0; }
            $ordKey = ord(substr($key,$j,1));
            $j++;
            $decrypttext .= chr($ordStr - $ordKey);
        }

    return $decrypttext;
}
}

//password hash
if(!function_exists('createHash')){
function createHash($password){
	
	// A higher "cost" is more secure but consumes more processing power, >3
	$cost = 10;

	// Create a random salt
	$salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');

	// Prefix information about the hash so PHP knows how to verify it later.
	// "$2a$" Means we're using the Blowfish algorithm. The following two digits are the cost parameter.
	$salt = sprintf("$2a$%02d$", $cost) . $salt;

	return $hash = crypt($password, $salt);
}
}
// Escape ' character from string
if(!function_exists('escapeString')){
	function escapeString($mysqli,$string){
		$string = mysqli_real_escape_string($mysqli,htmlspecialchars($string));	
		return $string;
	}
}
// Replace \ with ' character from string
if(!function_exists('escapeSlash')){
	function escapeSlash($string){
		$string = trim($string);
		$string = str_replace('\"', '"', $string);
		return $string = str_replace("\'", "'", $string);
	}
}
?>