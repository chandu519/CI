<?php 
$stmt=$mysqli->prepare("SELECT page_name, content, seo_title, seo_keywords, seo_desc FROM tbl_content WHERE page_name = ?");
$stmt->bind_param('s',$page);
$stmt->execute();
$stmt->store_result();
if($stmt->num_rows()>0){
	$stmt->bind_result($title,$desc,$seo_title,$seo_keywords,$seo_desc);
	$stmt->fetch();
	$seo_title=base64decode($seo_title);
	$seo_keywords=base64decode($seo_keywords);
	$seo_desc=base64decode($seo_desc);
}else{
	//echo 'if table doesn't exist';
	$seo_image='';
	$seo_title=$seoTitle;
	$seo_keywords=$seoKeywords;
	$seo_desc=$seoDesc;
	$seo_content='';
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE7">
<meta http-equiv="X-UA-Compatible" content="IE=9" />
<meta http-equiv="X-UA-Compatible" content="chrome=1">
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="ico/png" href="images/favicon.png" type="image/icon">
<!--[if lte IE 8]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js&quot; type="text/javascript"></script>
<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/ie7-squish.js&quot; type="text/javascript"></script>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js&quot; type="text/javascript"></script>
<![endif]-->
<!--[if IE 8]>
<link rel="stylesheet" href="stylesheets/ie8.css" />
<![endif]-->
<title><?=$seo_title?></title>
<!--<meta name="description" content="<?=@$seo_desc?>"/>
<meta name="keywords" content="<?=@$seo_keywords?>"/>-->
<link href="stylesheets/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="stylesheets/anim.css" rel="stylesheet">
<link href="stylesheets/style.css" rel="stylesheet" type="text/css">
