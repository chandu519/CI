<?php /* <ul class="side_nav">	
	<li class="<?php if($pg=='home.php') echo 'active'; ?>"><a href="home.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
	
	<li class="<?php if($pg=='branch.php' || $pg=='employeeList.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-list"></i>Admin Users</a>
		<ul class="submenu">
					
			
			<li><a href="employeeList.php">Users List</a></li>	
			
		</ul>
	</li>

	<!--<li class="<?php if($pg=='search.php') echo 'active'; ?>"><a href="search.php"><i class="fa fa-search"></i> Search</a></li>-->
	
	<li class="<?php if($pg=='banners.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Home Page</a>
	<ul class="submenu">
				
			<li><a href="banners.php">Banners</a></li>	
			<li><a href="wContent.php">Welcome Content</a></li>	
			<!--<li><a href="quicklinks.php">Who We Are</a></li>-->
			<li><a href="quicklinks2.php">Benefits</a></li>	
			<li><a href="services.php">Services</a></li>
			<li><a href="news.php">News</a></li>
			<li><a href="testimonials.php">Testimonials</a></li>	
			<li><a href="contact.php">Addresses</a></li>
			<li><a href="contactDetails.php">Social Links</a></li>	
		
		</ul>
	</li>
	<li class="<?php if($pg=='refund.php'||$pg=='pricing.php'||$pg=='editContent.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Other Pages</a>
	<ul class="submenu">
				
			
			<li><a href="refund.php">Refund Status</a></li>	
			<li><a href="pricing.php">Pricing</a></li>
			<li><a href="wContent1.php">Refer</a></li>
			<li><a href="editContent.php">Seo Content</a></li>
			<li><a href="innerBanners.php">Inner Banners</a></li>
			
		
		</ul>
	</li>
	
	<li class="<?php if($pg=='users.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Registered Users</a>
	<ul class="submenu">
					
			
			<li><a href="users.php">Users</a></li>
			<li><a href="referals.php">User Referals</a></li>	
			
		</ul>
	</li>
	
	<li class="<?php if($pg=='contactDetails.php') echo 'active'; ?>"><a href="javascript:void(0);"><i class="fa fa-search"></i> Contact</a>
	<ul class="submenu">
					
			
			
		</ul>
	</li>
	
</ul>
*/?>