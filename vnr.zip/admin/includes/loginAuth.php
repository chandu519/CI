<?php

/*********************** login Check Start **************************/
if((isset($_SESSION['admin_id']) && $_SESSION['admin_id']!="")){
	/* $pageArray=array('home.php','profile.php','changePassword.php','logout.php','leads.php','conLeadData.php','addLeadData.php','assignAgent.php','leadTrack.php','leadTrackData.php');
	if($_SESSION['admin_type']==1){
		if(in_array($pg,$pageArray)){
			
		}else{
			$allClasses->forRedirect ("403.php");
			exit;
		}
	} */
}else{
	$allClasses->forRedirect ("logout.php");
	exit;
}
/*********************** login Check End ***************************/
?>