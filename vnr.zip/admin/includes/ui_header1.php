<div class="wrapper header"> 
    <div class="wrapper_inner">        
        <div class="micon"><span></span></div>
        
        <div class="logo">
            <a href="index.php">
                <img src="https://www.3kits.com/demo/onlinetaxfiler/images/logo.jpg" alt="">
            </a>
        </div>
      
	  <?php 
			$admin_access=explode(",",@$_SESSION['admin_access']);
			if(in_array("1", $admin_access) || $_SESSION['admin_type']=='0'){
		?>
	   <div class="top_right">
           <li><h3>Refferee</h3></li>

           <?php
					$referrals = "select * from tbl_user_referals";
					$referrals_query = mysqli_query($mysqli, $referrals);
					$total_referrals = mysqli_num_rows($referrals_query);
					$registered_referrals = 0;
					$unregistered_referrals = 0;
					while($row_referrals = mysqli_fetch_array($referrals_query))
					{
						$reg_check = "select * from tbl_users where email = '".$row_referrals['email']."'";
						$reg_check_query = mysqli_query($mysqli, $reg_check);
						if(mysqli_num_rows($reg_check_query)>=1)
						{ $registered_referrals = $registered_referrals+1; }
						else { $unregistered_referrals = $unregistered_referrals+1; }
					}
				?>
	
		<li><a href="referals_totlal.php">Total(<?=$total_referrals?>)</a></li>	
		<li><a href="referals_reg.php">Registered(<?php echo $registered_referrals; ?>)</a></li>	
		<li><a href="referals_unreg.php">Unregistered(<?php echo $unregistered_referrals; ?>)</a></li>	
        </div>
			<?PHP } ?>
	    <!-- <div class="logo_text">
            Sri Venkateswara
            <span>Food & Beverages</span>
            <div class="line">Private limited</div>
        </div>-->
    </div>

    <div class="wrapper main_menu">
        <div class="wrapper_inner">
            <?php include_once "includes/admin_menu1.php"; ?> 
            <div class="notification">
                <ul>
                    <li><a href="javascript:void(0);" class="hassub"><i class="fa fa-user"></i><span>My Account</span></a>
                        <ul>
                            <li><a href="profile.php"><?=$_SESSION['admin_id']?></a></li>
                            <li><a href="changePassword.php">Change Password</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </li>                                            
                </ul>
            </div>  
        </div>
    </div>
</div>