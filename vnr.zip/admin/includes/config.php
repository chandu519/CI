<?php session_start();
/** Developer: Sai **/
date_default_timezone_set("Asia/Kolkata");  // Time Zone in India
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
//DATABASE CONFIGURATION
if($_SERVER['HTTP_HOST'] == "localhost"){
    $host = "localhost";
	$user = "root";
	$password = "";
	$db = "vnr";
	error_reporting(0);
	define ('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/');
	define ('SITE_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/admin/');	
	define ('SITE_IMG_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/images/');	
	define ('ROOT_IMG_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/admin/images/');		
	define ('SITEDOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/');
	
	
	error_reporting(E_ALL);
}else{
	//SERVER CONFIGURATION
	$host = "dbvnr1.db.5628983.840.hostedresource.net";
		$user = "dbvnr1";
	$password = "Reset!2345";
	$db = "dbvnr1";
	
		define (DOC_ROOT_PATH,'/home/content/83/5628983/html/demo/vnr1/admin/');
    define (SITE_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/vnr1/admin/');    
    define (SITE_IMG_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/vnr1/images/');      
    define (ROOT_IMG_PATH, '/home/content/83/5628983/html/demo/vnr1/images/');
    define (SITEDOC_ROOT_PATH, '/home/content/83/5628983/html/demo/vnr1/');  

}
global $mysqli;
$mysqli = new mysqli($host, $user, $password, $db);
if ($mysqli->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	exit;
}
require DOC_ROOT_PATH."includes/pagedresults.php";
require_once DOC_ROOT_PATH."includes/forClasses.php"; 
$allClasses = new forClasses();

$pages = array(
	'',
	'Home',	
	'About Us',
	'Refund Status',
	'Testimonials',
	'Pricing',	
	'Refer A Friend',		
	'Contact Us'
);

$err=array('WP'=>'Invalid Details. Please try again.','SA'=>'Added Successfully.','FA'=>'Unable to Add. Please try again.','SE'=>'Updated Successfully.','FE'=>'Unable to Update. Please try again.','SD'=>'Removed Successfully.','FD'=>'Unable to delete. Please try again.','LR'=>'Login access denied','ND'=>'Please fill out all fields','SFP'=>'Success, credentials have beeb sent to your email','FFP'=>'Failed to retreive your data, try again later.','WP'=>'Invalid credentials!','RE'=>'Data already exits with same values');

$items=array('gold'=>'gold','silver'=>'silver');

if($_SERVER['QUERY_STRING'] != ""){
 	$current_page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
}else{
	$current_page = $_SERVER['PHP_SELF'];
}

$pgTitle="vnr Inc";
$pgTitleStory="vnr Inc";

//FINDING CURRENT PAGE	
$pg = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/')+1, strlen($_SERVER['PHP_SELF']));


//FUNCTIONS
include "includes/functions.php";

$page="Home";
?>