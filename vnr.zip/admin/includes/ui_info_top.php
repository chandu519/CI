<style>
.file_nav {
    margin-bottom: 20px;
}
.file_nav li {
    width: 12.5%;
    text-align: center;
    float: left;
    color: #333;
}
.file_nav li a {
    height: 50px;
    display: grid;
    align-content: center;
    justify-content: center;
    background: #3b3b3b;
    color: #fff;
}
.file_nav li a:hover, .file_nav li a.active {
	background: #f5a301;
}
</style>
<?php $file_no=$_REQUEST['file_no'];?>
<ul class="wrapper file_nav">
	<li><a href="viewDetails.php?file_no=<?=$file_no?>">Tax Payer</a></li>
	<li><a href="view-spouce-Details.php?file_no=<?=$file_no?>">Spouse Details</a></li>
	<li><a href="dependent-info.php?file_no=<?=$file_no?>">Dependent Details</a></li>
	<li><a href="interview-pending-info.php?file_no=<?=$file_no?>">Interview Pending</a></li>
	<li><a href="userDocuments.php?file_no=<?=$file_no?>">Documents</a></li>
	<li><a href="userTaxSummary.php?file_no=<?=$file_no?>">Tax Summary</a></li>
	<li><a href="referals.php?file_no=<?=$file_no?>">Refferee</a></li>
	<li><a href="userFilestatus.php?file_no=<?=$file_no?>">File Status/Info</a></li>
</ul>