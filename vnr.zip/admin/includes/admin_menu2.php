<ul class="side_nav">	
	<li class="<?php if($pg=='home.php') echo 'active'; ?>"><a href="home.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
	
	

	<li class="<?php if($pg=='pricing.php') echo 'active'; ?>"><a href="pricing.php"><i class="fa fa-search"></i> Pricing</a><!-- 
	<ul class="submenu">
				
			<li><a href="users.php">users</a></li>	
			<li><a href="pricing.php">Pricing</a></li>
			<li><a href="products.php">Products</a></li>	
			<li><a href="billing.php">invoices</a></li>
			<li><a href="info.php">Info</a></li>
			
		
		</ul> -->
	</li>
	
	<li class="<?php if($pg=='users.php' || $pg=='addusers.php') echo 'active'; ?>"><a href="users.php"><i class="fa fa-list"></i>Usera</a>
		
	</li>
	<li class="<?php if($pg=='products.php' || $pg=='addproducts.php') echo 'active'; ?>"><a href="products.php"><i class="fa fa-list"></i>products</a>
		
	</li>
	<li class="<?php if($pg=='addbilling.php' || $pg=='billing.php') echo 'active'; ?>"><a href="billing.php"><i class="fa fa-list"></i>Invoices</a></li>
	<li class="<?php if($pg=='info.php') echo 'active'; ?>"><a href="info.php"><i class="fa fa-list"></i>Info</a></li>
	
	
</ul>