<style>
.errorMsg{ font-size:12px; color:red; text-transform:initial; }
</style>
<!-- Connector login -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
		<div class="modal-dialog">
		<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					
					<div class="signin-form profile">
					<h3 class="agileinfo_sign">Sign In</h3>	
							<div class="login-form">
								<span class="errorMsg" id="errMsgLog"></span>
								<form action="#" method="post">
									<input type="email" name="txtEmailL" id="txtEmailL" placeholder="Username">
									<input type="password" name="txtPasswordL" id="txtPasswordL" placeholder="Password">
									<div class="tp">
										<input type="submit" value="Sign In" onClick="return checkLogin();" >
									</div>
								</form>
							</div>
							<div class="login-social-grids">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>							
						</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal2 -->	
	<!-- Modal1 -->
	<!-- Connector signup -->
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog">
		<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>					
					<div class="signin-form profile">
					<h3 class="agileinfo_sign">Enter Your Details</h3>	
							<div class="login-form">
								<span class="errorMsg" id="errMsgCReg"></span>
								<form action="#" method="post">
									<input type="text" name="txtCName" id="txtCName" placeholder="Name *">
									<input type="text" name="txtCPhone" id="txtCPhone" placeholder="Mobile *">																		
									<input type="password" name="txtCPassword" id="txtCPassword" placeholder="Password *">																		
									<input type="email" name="txtCEmail" id="txtCEmail" placeholder="Email (Optional)">													
									<select name="selLocation" id="selLocation">										
										<option value="Hyderabad" selected>Hyderabad</option>										
										<option value="Vijaywada" disabled>Vijaywada (Coming soon)</option>										
										<option value="Guntur" disabled>Guntur (Coming soon)</option>										
									</select>
									<input type="submit" value="Submit" onClick="return checkCRegister();">
								</form>
							</div>
							<p><a href="javascript:void(0)"> By clicking submit, I agree to your terms</a></p>
						</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal1 -->		
	<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
		<div class="modal-dialog">
		<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>					
					<div class="signin-form profile">
					<h3 class="agileinfo_sign">Enter Your Details</h3>	
							<div class="login-form">
								<span class="errorMsg" id="errMsgReg"></span>
								<form action="#" method="post">
									<input type="text" name="txtName" id="txtName" placeholder="Name *">
									<input type="text" name="txtPhone" id="txtPhone" placeholder="Mobile *">									
									<select name="selLoanType" id="selLoanType">
										<option value="">Loan Type*</option>
										<option value="Personal Loan">Personal Loan</option>
										<option value="Business Loan">Business Loan</option>
									</select>
									<select name="selSalType" id="selSalType">
										<option value="">Are you a*</option>
										<option value="Salaried Employee">Salaried Employee</option>
										<option value="Non-salaried Employee">Non-salaried Employee</option>
									</select>
									<input type="email" name="txtEmail" id="txtEmail" placeholder="Email (Optional)">													
									<input type="submit" value="Submit" onClick="return checkRegister();">
								</form>
							</div>
							<p><a href="javascript:void(0)"> By clicking submit, I agree to your terms</a></p>
						</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal3 -->	
<!-- //bootstrap-pop-up -->

<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->

<script src="js/mainScript.js"></script>
<script src="js/rgbSlide.min.js"></script>

<!-- flexSlider -->
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(window).load(function(){
	$('.flexslider').flexslider({
	animation: "slide",
	start: function(slider){
		$('body').removeClass('loading');
	}
	});
});
</script>
<!-- //flexSlider -->
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
$(".scroll").click(function(event){		
	event.preventDefault();
	$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
});
});
</script>
<!-- start-smooth-scrolling -->
<!-- for bootstrap working -->
<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
<script type="text/javascript">
$(document).ready(function() {
	/*
		var defaults = {
		containerID: 'toTop', // fading element id
		containerHoverID: 'toTopHover', // fading element hover id
		scrollSpeed: 1200,
		easingType: 'linear' 
		};
	*/						
	$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<script>		
function checkCRegister(){
	
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;	
	var nameformat = /^([a-zA-Z ]|\s)*$/;	
	//var sNumber = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
	var sNumber = /^[\+]{0,1}(\d{10,13}|[\(][\+]{0,1}\d{2,}[\13)]*\d{5,13}|\d{2,6}[\-]{1}\d{2,13}[\-]*\d{3,13})*$/;	;
	
	var txtCName = document.getElementById("txtCName").value.trim();
	var txtCPhone = document.getElementById("txtCPhone").value.trim();
	var txtCEmail = document.getElementById("txtCEmail").value.trim();
	var txtCPassword = document.getElementById("txtCPassword").value.trim();
	var selLocation = document.getElementById("selLocation").value.trim();
	
	$("#errMsgCReg").html("");
	if (txtCName.length == 0) {		
		$("#errMsgCReg").html("Please provide full name");
		document.getElementById("txtCName").value = "";
		document.getElementById("txtCName").focus();
		return false;
	}
	if(!txtCName.match(nameformat))  
	{
		$("#errMsgCReg").html("Please provide a valid name, only alphabets are allowed");
		document.getElementById("txtCName").value = "";
		document.getElementById("txtCName").focus();
		return false;
	}	 	
	if (txtCPhone.length == 0) {		
		$("#errMsgCReg").html("Please provide mobile number");
		document.getElementById("txtCPhone").value = "";
		document.getElementById("txtCPhone").focus();
		return false;
	} 
	if(!txtCPhone.match(sNumber))  
	{
		$("#errMsgCReg").html("Please provide a valid mobile number");		
		document.getElementById("txtCPhone").focus();
		return false;
	}	
	if (txtCPassword.length == 0 || txtCPassword.length <6 ) {		
		$("#errMsgCReg").html("Please enter password, min 6 characters");
		document.getElementById("txtCPassword").value = "";
		document.getElementById("txtCPassword").focus();
		return false;
	}
	if(txtCEmail!='' && !txtCEmail.match(mailformat))  
	{
		$("#errMsgCReg").html("Please provide a valid email address");		
		document.getElementById("txtCEmail").focus();
		return false;
	}	
	 
	$("#errMsgCReg").html('Please wait..');          
	$.ajax({url:"ajax.php",type: 'POST',data: {'action': 'checkCRegister', 'txtCName': txtCName, 'txtCPhone': txtCPhone, 'txtCEmail': txtCEmail, 'txtCPassword': txtCPassword, 'selLocation': selLocation },success:function(result){
		$("#errMsgCReg").html(result);          
		//console.log(result);
		if(result.trim()!=9){
			if(result.trim()==1){
				$("#errMsgCReg").html('Thank you, please wait while we redirect you'); 
			}else if(result.trim()==2){
				$("#errMsgCReg").html('Something went wrong, try again later..!'); 
			}else if(result.trim()==3){
				$("#errMsgCReg").html('Phone/Mobile number is alredy registered'); 
			}
			$("#errMsgCReg").addClass('successMsg'); 			
			setTimeout(function(){ 
			window.location.href = 'index.php';
    }, 5000);  			
		}		
	}});
	return false;
}
function checkRegister(){
	
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;	
	var nameformat = /^([a-zA-Z ]|\s)*$/;	
	//var sNumber = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
	var sNumber = /^[\+]{0,1}(\d{10,13}|[\(][\+]{0,1}\d{2,}[\13)]*\d{5,13}|\d{2,6}[\-]{1}\d{2,13}[\-]*\d{3,13})*$/;	;
	
	var txtName = document.getElementById("txtName").value.trim();
	var txtPhone = document.getElementById("txtPhone").value.trim();
	var txtEmail = document.getElementById("txtEmail").value.trim();
	var selLoanType = document.getElementById("selLoanType").value.trim();
	var selSalType = document.getElementById("selSalType").value.trim();
	
	$("#errMsgReg").html("");
	if (txtName.length == 0) {		
		$("#errMsgReg").html("Please provide full name");
		document.getElementById("txtName").value = "";
		document.getElementById("txtName").focus();
		return false;
	}
	if(!txtName.match(nameformat))  
	{
		$("#errMsgReg").html("Please provide a valid name, only alphabets are allowed");
		document.getElementById("txtName").value = "";
		document.getElementById("txtName").focus();
		return false;
	}	 	
	if (txtPhone.length == 0) {		
		$("#errMsgReg").html("Please provide mobile number");
		document.getElementById("txtPhone").value = "";
		document.getElementById("txtPhone").focus();
		return false;
	} 
	if(!txtPhone.match(sNumber))  
	{
		$("#errMsgReg").html("Please provide a valid mobile number");		
		document.getElementById("txtPhone").focus();
		return false;
	}	
	if(txtEmail!='' && !txtEmail.match(mailformat))  
	{
		$("#errMsgReg").html("Please provide a valid email address");		
		document.getElementById("txtEmail").focus();
		return false;
	}	
	if (selLoanType == '') {		
		$("#errMsgReg").html("Please select loan type");
		document.getElementById("selLoanType").value = "";
		document.getElementById("selLoanType").focus();
		return false;
	}
	if (selSalType == '') {		
		$("#errMsgReg").html("Please select salary type");
		document.getElementById("selSalType").value = "";
		document.getElementById("selSalType").focus();
		return false;
	} 
	$("#errMsgReg").html('Please wait..');          
	$.ajax({url:"ajax.php",type: 'POST',data: {'action': 'checkRegister', 'txtName': txtName, 'txtPhone': txtPhone, 'txtEmail': txtEmail, 'selLoanType': selLoanType, 'selSalType': selSalType },success:function(result){
		$("#errMsgReg").html(result);          
		//console.log(result);
		if(result.trim()!=9){
			if(result.trim()==1){
				$("#errMsgReg").html('Thank you, our representaive will get back to you soon..!'); 
			}else if(result.trim()==2){
				$("#errMsgReg").html('Something went wrong, try again later..!'); 
			}
			$("#errMsgReg").addClass('successMsg'); 			
			setTimeout(function(){ 
			window.location.href = 'index.php';
    }, 5000);  			
		}		
	}});
	return false;
}

function checkLogin(){
	
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;	
	
	var txtEmailL = document.getElementById("txtEmailL").value.trim();
	var txtPasswordL = document.getElementById("txtPasswordL").value.trim();
		
	$("#errMsgLog").html("");	
	if (txtEmailL.length == 0) {		
		$("#errMsgLog").html("Please provide a valid username.");
		document.getElementById("txtEmailL").value = "";
		document.getElementById("txtEmailL").focus();
		return false;
	} 
	/* if(!txtEmailL.match(mailformat))  
	{
		$("#errMsgLog").html("Please provide a valid email address.");		
		document.getElementById("txtEmailL").focus();
		return false;
	} */
	if (txtPasswordL.length == 0) {		
		$("#errMsgLog").html("Please provide a password");
		document.getElementById("txtPasswordL").value = "";
		document.getElementById("txtPasswordL").focus();
		return false;
	}
	if (txtPasswordL.length < 6) {		
		$("#errMsgLog").html("Please provide a 6 character password");		
		document.getElementById("txtPasswordL").focus();
		return false;
	}
	 
	$("#errMsgLog").html('Please wait..');          
	$.ajax({url:"ajax.php",type: 'POST',data: {'action': 'checkLogin', 'txtEmailL': txtEmailL, 'txtPasswordL': txtPasswordL },success:function(result){
		$("#errMsgLog").html(result);          
		console.log(result);
		if(result.trim()=='success'){
			$("#errMsgLog").addClass('successMsg'); 
			$("#errMsgLog").html('Successfully logged in, please while we redirect you'); 
			setTimeout(function(){ 
			window.location.href = 'dashboard.php';
    }, 1000);  			
		}				
	}}); 	
	return false;
}
</script>
<!-- //here ends scrolling icon -->