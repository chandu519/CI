<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_welcome";
$pageHeading=" Welcome Content";
$pageList="wContent.php";

/*********************** Add Banners ***************************/
if(isset($_POST["addBanner"]) && $_POST["addBanner"]=="Submit"){
	
	$name = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtName']));
	$name2 = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtName2']));
	$link = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtLink']));
	$content = base64_encode($_POST['txtContent']);
	$name1 = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtname1']));
	/*if($_FILES['txtImage']['name'] != ""){
		$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage');
		
		if($result){
			$imgName = $result;
			if(@$_POST['hid_image']!= ""){
				unlink(SITEDOC_ROOT_PATH."images/".$_POST['hid_image']);
			}
		}
	}else{
		$imgName = $_POST['hid_image'];
	}*/
	if(!empty($_FILES['txtImage']['name']))
	{		
		//Count number of files in array, loop through each file
		for($i=0; $i<count($_FILES['txtImage']['name']); $i++) {
	 
			// If the file in array exists
			if ($_FILES["txtImage"]["name"][$i]){
			
				// If the file isnt 0 bytes
				if ($_FILES["txtImage"]["error"][$i] > 0) {
					echo "Return Code: " . $_FILES["txtImage"]["error"][$i] . "<br>";
				}
				else {			
					// Code to action
					$filname= time().$_FILES["txtImage"]["name"][$i];
					$result = move_uploaded_file($_FILES["txtImage"]["tmp_name"][$i],"../images/" . $filname);
					$rimgName.= $filname.",";				
				}
			}
		}
		/*if($_POST['hid_image']!= ""){
			$hid_imageA=explode(',',$_POST['hid_image']);
			foreach($hid_imageA as $hda){
				unlink(ROOT_IMG_PATH.$hda);	
			}			
		}*/ 
		$rimgName=rtrim($rimgName,',');		
		$rimgName=ltrim($rimgName,',');
		if($_POST['hid_image']!="")
		{
		$rimgName1=@$_POST['hid_image'].','.$rimgName;			
		}	else{ 
		$rimgName1=@$rimgName.','.$_POST['hid_image'];		
		}		
		
		$rimgName1=rtrim($rimgName1,',');		
	}else{
		$rimgName1=@$_POST['hid_image'];
	}

	
	
	$sql="update tbl_welcome set image=?,title=?,link=?, content=?,image=?,name=?,name2=? where inc_cat_id=1";
	if ($stmt = $mysqli->prepare($sql)){
		$si='sssssss';
		$stmt->bind_param($si,$imgName,$name,$link,$content,$rimgName1,$name1,$name2);
		$flag=$stmt->execute();
	//	echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error; exit;
		if($flag){
			$_SESSION['stat']="SE";
			$allClasses->forRedirect ("wContent.php");
			exit;
		}else{
			$_SESSION['stat']="FE";
			$allClasses->forRedirect ("wContent.php");
			exit;
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
		<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
								$cid =1;
									if ($cat = $mysqli->prepare("select inc_cat_id,title,content,link,image,name,name2 from tbl_welcome where inc_cat_id=?")) {
									$cat->bind_param('i',$cid );
									$cat->execute();
									$cat->store_result();
									if($cat->num_rows>0){
										$cat->bind_result($det1,$det2,$det4,$det5,$det3,$det8,$det9);
										$cat->fetch();
										
										$det9 = trim($det9);
										$det9 = str_replace('\"', '"', $det9);
										$det9 = str_replace("\'", "'", $det9);
										
										$det4 = base64_decode($det4);
										$det4 = str_replace('\"', '"', $det4);
										$det4 = str_replace("\'", "'", $det4);
										
										$det2 = trim($det2);
										$det2 = str_replace('\"', '"', $det2);
										$det2 = str_replace("\'", "'", $det2);
										
										
										$cat->close();
									}
								}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Title</label>
									</div>
									<div class="finput">
											<input name="txtname1" type="text" value="<?=@$det8?>" class="" id="txtname1" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Heading</label>
									</div>
									<div class="finput">
											<input name="txtName" type="text" value="<?=@$det2?>" class="" id="txtName" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Link</label>
									</div>
									<div class="finput">
										<input name="txtLink" type="text" value="<?=@$det5?>" class="" id="txtLink" >
									</div>
								</div>
								<div class="wrapper" style="margin-bottom:25px; ">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
										<textarea class="" name="txtContent" ><?php echo @$det4; ?></textarea>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Scrolling Content</label>
									</div>
									<div class="finput">
										<input name="txtName2" type="text" value="<?=@$det9?>" class="" id="txtName2" >
									</div>
								</div>
								<div class="wrapper" style="display:none;">
									<div class="flabel">
										<label for="folder">Image (WxH : 945 x 460 in pixels)</label>
									</div>
									<div class="finput">
										<input type="file" name="txtImage" id="txtImage" accept="image/*">
									</div>
								</div>
								<?php
								if(@$det3!=''){
									echo '<input type="hidden" name="hid_image" value="'.$det3.'">';		
									?>
									<div class="wrapper" style="margin-bottom:10px">
										<div class="flabel">
											<label for="folder"></label>
										</div>
										<div class="finput">
											<?php
										/*if(@$det3!= ""){
											echo '<input type="hidden" name="hid_image" value="'.$det3.'">';	
											?>
											<a href="../images/<?=$det3?>" target="_blank"><img src="../images/<?=$det3?>" height="60px" width="60px"style="padding:5px;margin-top:10px;background:#eee;border-radius:5px;"></a>							
						<!--	<a href="javascript:void(0)" class="anc_del" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del1&id=".$det1."&img=".$det3?>';return false;}"style="margin-top:50px;"><i class="fa fa-trash"></i></a>-->
											<?php
											//echo '<a href="../images/'.$det4.'" target="_blank" class="readmore">Click here to view the image.</a>';
									 	}*/
									 ?>			

												<?php
										if(@$det3!= ""){
											echo '<input type="hidden" name="hid_image" value="'.$det3.'">';	
											$det8A=explode(',',$det3);
											foreach(@$det8A as $k){
												?>
												<img src="<?=SITE_IMG_PATH.$k?>" style="width:60px;height:60px;padding:5px;margin-top:10px;background:#eee;border-radius:5px;">
												<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$det1."&img_name=".@$k."&img_a=".$det3?>';return false;}" style="text-decoration:none;background:#eee;border-radius:5px;">
																	<i class="fa fa-trash" style="color:#FF0000;font-size:12px;position:absolute;margin:80px 10px 10px -13px;" title="Delete"></i>
																</a>
												<?php
											}											
									 	}
									 ?>	
										</div>
									</div>									
									<?php 
								}
								?>								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addBanner" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>