<?php include "includes/config.php";
if(isSet($_SESSION['admin_id'])){ $allClasses->forRedirect ("banners.php"); exit; }
?>
<!doctype html>
<html>
	<head>
	<!-- META DATA -->
	<?php include "includes/ui_meta_tags.php"; ?>                
	<style>		
	.errMsg{ color: red; margin-top: 16px; display: inline-block; width: 100%; }
	</style>					
	</head>
	<body>
    <div class="wrapper login_page"> 
        <div class="login_box">
            <div class="wrapper logPop">
                <img src="../images/logo2.png" width="200px" alt="">
                <?php 
							if(isSet($_SESSION['stat'])){
								?><span class="errMsg"><?php
							if($_SESSION['stat']==='WP'){
							?>
							<?php echo $err[$_SESSION['stat']]; ?>
							<?php 
							}
							if($_SESSION['stat']==='ND'){
							?>
							<?php echo $err[$_SESSION['stat']]; ?>
							<?php 
							}
							unset($_SESSION['stat']);
							?></span><?php
							}
							?>
								<form name="frmAdminLogin" method="post" action="actions.php" onSubmit="return validate()" class="wrapper">
                    <div class="wrapper">
                        <label for="txtUser">Username *</label>
                        <input type="text" name="txtUser" id="txtUser" autocomplete="off">
                    </div>
                    <div class="wrapper">
                        <label for="txtPassword">Password</label>
                        <input type="password" name="txtPassword" id="txtPassword" autocomplete="off">
                    </div>
                    <input type="submit" class="lBtn" value="Login" name="logintoadmin">
                </form>
                <div class="wrapper">
                    <!--<a href="forgotPassword.php" class="newPwd">Forgot Password?</a>-->
                </div>
            </div>
        </div>
        
        <div class="login_imgright"><!--
        	<img src="images/dashboard-05.jpg" alt="">-->
        </div>
    </div>

<a href="javascript:void(0)" class="scrollup"><i class="fa fa-angle-up"></i></a>
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="js/scripts.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
function validate(){
	var txtUser=document.frmAdminLogin.txtUser.value;
	var txtPassword=document.frmAdminLogin.txtPassword.value;
	
	if($.trim(txtUser) == "" || txtUser.length<3){
		alert("Please enter a valid Username");
		document.frmAdminLogin.txtUser.focus();
		document.frmAdminLogin.txtUser.value='';
		return false;
	}	
	document.frmAdminLogin.txtUser.value=$.trim(txtUser);
	if($.trim(txtPassword) == ""){
		alert("Password should not be Empty");
		document.frmAdminLogin.txtPassword.focus();
		document.frmAdminLogin.txtPassword.value='';
		return false;
	}
	document.frmAdminLogin.txtPassword.value=$.trim(txtPassword);	
	return true;
}
</script>		
</body>
</html>