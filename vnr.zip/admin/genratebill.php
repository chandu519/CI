<?php 
include_once("includes/config.php");
$id=$_REQUEST['id'];
$stmt = $mysqli->prepare("SELECT inc_id,inc_cat_id,name,phone,comments,total_amt,given_amt,balence,village FROM tbl_bills WHERE inc_id = ? AND  status='1'");
	$stmt->bind_param('s', $_REQUEST['id']);
	$stmt->execute();
	$stmt->store_result();
	$recs_existed = $stmt->num_rows;
	
		$stmt->bind_result($det11,$det21,$det31,$det41,$det51,$det61,$det71,$det81,$det91);
		$stmt->fetch();
		$today = date("d/m/Y");
	?>
<!doctype html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE7">
        <meta http-equiv="X-UA-Compatible" content="chrome=1">
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Invoice</title>
        <style>
            *, *:before, *:after {
                margin: 0px;
                padding: 0px;
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -o-box-sizing: border-box;
                -ms-box-sizing: border-box;
            }
            body {background: #ff9e9e;padding: 50px;color:#111;line-height: 22px;}
            .wrapper{width: 100%;float: left;position: relative;}
            .tc{text-align: center;}
            .tr{text-align: right;}
            .header {margin-bottom: 20px;font-size: 16px;}
            .Nleft {float:left;max-width: 200px}
            .Nleft span {float:right;}
            .Nright span {float:right;}
            .Nright {float:right;max-width: 200px}
            table{border-collapse: collapse;border: 1px solid #111;margin: 15px 0}
            table td{padding:10px;border: 1px solid #111;}
        </style>
    </head>
    <body>
       <div class="wrapper header tc">
            <div class="wrapper">!!SHREE!!</div>
            <div class="wrapper">ESTIMATE/ON APPROVAL</div>
            <div class="wrapper">Issue</div>
        </div>
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Name: <?=$det31?></div>
                <div class="wrapper">Phone No: <?=$det41?></div>
            </div>
            <div class="Nright tr">5362
                <div class="wrapper">Date: <?=$today?></div>
                <div class="wrapper">Page No: 1/1</div>
            </div>
        </div>
        <table class="wrapper">
		<?php 
		
		?>
            <tr>
                <td>Sr.</td>
                <td>Item Name</td>
                <td class="tr">Pcs</td>
                <td class="tr">Amount</td>
            </tr>

          <?php 
if(@$_REQUEST['id']!=""){
	$id=$_REQUEST['id'];
  $query = "SELECT bill_id,prod_name,quantity,grams,price,dt_created FROM tbl_bill_products where bill_id='$det11' ORDER BY inc_id DESC";
$res=mysqli_query($mysqli,$query);	
if(mysqli_num_rows($res)>0){ $i=1;
while($row = mysqli_fetch_array($res)){  
?>	
            <tr>
                <td><?=$i?></td>
                <td><?=$row['prod_name']?></td>
                <td class="tr"></td>
                <td class="tr"><?=$row['price']?></td>
            </tr>
<?php $i++;}}}?>
			
			<tr>
                <td colspan="2">Total</td>
                <td class="tr" colspan="2"><?=$det61?></td>
            </tr>
        </table>        
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Fine Amount: <span class="tr">$det61</span></div>
                <div class="wrapper">Labour: <span class="tr">3792.75</span></div>
                <div class="wrapper">&nbsp;</div>
                <div class="wrapper">Net Balance: <span class="tr">204844.86</span></div>
                <div class="wrapper">Narration: <span class="tr">GROSS 6158</span></div>
            </div>
            <div class="Nright">
                <div class="wrapper">Rate: <span class="tr">41000.0/1000.00</span></div>
                <div class="wrapper">Issue: <span class="tr">4903.710</span></div>
                <div class="wrapper">Recipet: <span class="tr"></span></div>
                <div class="wrapper">Old Bal Amt: <span class="tr">0.00</span></div>
                <div class="wrapper">Old Bal Net Wt: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal Amount: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal  net Wt: <span class="tr">0.00</span></div>
            </div>
        </div>	
    </body>
</html>