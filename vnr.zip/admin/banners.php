<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_banner";
$pageHeading="Banners";
$pageAdd="addBanner.php";
$pageList="banners.php";

/*********************** Delete ***************************/
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	
	if($stmt1 = $mysqli->prepare("SELECT id,b_image FROM $tableName WHERE id=?")) {
		$stmt1->bind_param('i', $id);
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($inc_cat_id,$image);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
			if($image!=""){
				unlink(DOC_ROOT_PATH."images/".$image);
			}
			$sql="DELETE FROM $tableName WHERE id =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='i';
				$stmt->bind_param($s, $id);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}				
			}
		}	else{
			$_SESSION['stat']="NDE";					
		}
		$allClasses->forRedirect ($pageList); exit;
	}
}

/*********************** Stats Change Active/Disabled ***************************/
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="SELECT id FROM $tableName WHERE id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
				$stmt->bind_result($inc_cat_id);
				$stmt->fetch();				
				$sq="UPDATE $tableName SET b_status=? WHERE id=?";
				if ($stm = $mysqli->prepare($sq)){
					$ii='ss';
					$stm->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stm->execute();					
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";						
					}else{
						$_SESSION['stat']="FE";					
					}
					$allClasses->forRedirect ($pageList);
					exit;
				}
			}
		}
	}
}
/*********************** Sort Order ***************************/
if(@$_POST['butSubmit']=="Update"){
	for($k=1;$k<=$_POST['hidTotal'];$k++){
		$inc_id=@$_POST['hidID'.$k];
		//echo "update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'"; exit;
		mysqli_query($mysqli,"update $tableName set b_sort_order='".@$_POST['txtPriority'.$k]."',b_dt_modified='".$_SESSION['admin_id']."',b_dt_modified=now() where id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($pageList);
	exit;
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							<?php 
							$query = "SELECT id, b_name, b_image, b_content, b_link, b_sort_order, b_dt_created, b_dt_modified, b_modified_by, b_status FROM $tableName ORDER BY b_sort_order ASC";
							$res=mysqli_query($mysqli,$query);	
							if(mysqli_num_rows($res)>0){ 
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>Title</th>	
												<th>Image</th>											
												<th>Sort Order</th>											
																																																					
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											$usr_id=$row['id'];
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['id']?>" />														
											<tr>
												<td><a href="javascript:void(0)"><?=$row['id']?></a></td>
												<td><a href="javascript:void(0)"><?=$row['b_name']?></a></td>												
												<td><a href="<?=SITE_PATH?>images/<?=$row['b_image']?>" target="_blank"><img src="<?=SITE_PATH?>../images/<?=$row['b_image']?>" width="60"></a></td>			
												<td class="input_table">
										<input type="text" class="" size=3 name="txtPriority<?=$i?>" id="txtPriority<?=$i?>" value="<?=$row['b_sort_order']?>" />
												</td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<?php
													if($row['b_status']=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													?>
													<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$row['id']?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$row['id']?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['id']?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										<tr>
											<td></td>
											<td></td>
											<td></td>											
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
						}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>