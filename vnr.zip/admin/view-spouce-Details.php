<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_spouse_info";
$pageHeading="User Info";
$pageAdd="addBanner.php";
$pageList="viewDetails.php";


?>
<!doctype html>
<!--<li><a href="view-spouce-Details.php">Spouse Details</a></li>-->

<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php //include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
					
					<?php include "includes/ui_info_top.php"; ?>   
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
							<?php 
							if(isSet($_SESSION['stat'])){
							?>										
							<?php 
							if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
								$error_msg="";
							}
							if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
								$error_msg="error_msg";	
							}
							?>
							<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
							<?php 
								unset($_SESSION['stat']);
							}
							?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['file_no']!=""){
										$file_no=$_REQUEST['file_no'];
										$query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
										$res=mysqli_query($mysqli,$query);
										if(mysqli_num_rows($res)>0){ 
										$row = mysqli_fetch_array($res);
										
									
									?> 
									
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">First Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['sf_name']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">middle Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['sm_name']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Last Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['sl_name']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Date Of Birth</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['dob']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Gender</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?php if($row['gender']==1){echo 'male';} else{echo 'Female';}?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Tax Id Type</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['tax_id_type']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">SSN/ITIN Number</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['tin_no']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Passport Number</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['passport_number']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Passport Exp date</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['passport_expiry']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Visa No</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['visa_number']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Visa Exp date</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['visa_expiry']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">First Date of Entry to USA</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['first_date_to_usa']?>" disabled>
									</div>
								</div>
								
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Occupation</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['occupation']?>" disabled>
									</div>
								</div>
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Visa Type</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['visa_type']?>" disabled>
									</div>
								</div>
							
								
									<?php }else{ ?>
							<div class="wrapper no_docs_data">
								No data Available
							</div>
							<?php 
						}
						?> <?php }?>
								
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>