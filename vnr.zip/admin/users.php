<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_users";
$pageHeading="Users";
$pageAdd="adduser.php";
$pageList="users.php";

/*********************** Delete ***************************/
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	
	if(@$_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select user_id from $tableName where user_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
			
				$stmt->bind_result($user_id);
				$stmt->fetch();				
				$sq="update $tableName set status=? where user_id=?";
				if ($stm = $mysqli->prepare($sq)){
					$ii='ss';
					$stm->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stm->execute();					
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";						
					}else{
						$_SESSION['stat']="FE";					
					}
					$allClasses->forRedirect ($pageList);
					exit;
				}
			}
		}
	}
}



/*********************** Delete ***************************/
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	
	if($stmt1 = $mysqli->prepare("select user_id from $tableName where user_id=?")) {
		$stmt1->bind_param('i', $id);
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($user_id);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
			
			$sql="delete from $tableName where user_id =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='i';
				$stmt->bind_param($s, $id);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}
				$allClasses->forRedirect ($pageList);
				exit;
			}
		}	
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							<?php 
							$query = "SELECT * FROM $tableName ORDER BY user_id ASC";
							$res=mysqli_query($mysqli,$query);	
							if(mysqli_num_rows($res)>0){ 
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>Name</th>
												<th>Email</th>		
												<th>Mobile</th>							
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											$usr_id=$row['user_id'];
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['user_id']?>" />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>				
												<td><?=$row['name']?></td>
												<td><?=$row['email']?></td>
												<td><?=$row['phone']?></td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<?php
													if($row['status']=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													?>
													<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$row['user_id']?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$row['user_id']?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['user_id']?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
						}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>