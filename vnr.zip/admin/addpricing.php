<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_pricing";
$pageHeading="Pricing";
$pageAdd="addpricing.php";
$pageList="pricing.php";


if(isset($_POST["addBanner"]) && $_POST["addBanner"]=="Save"){
 
	$date=str_replace("'","",$_POST['txtdate']);
	$gold=str_replace("'","",$_POST['txtGold']);
	$silver=str_replace("'","",$_POST['txtSilver']);

	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		$sql = "update $tableName set date='".$date."',gold='".$gold."',silver='".$silver."' where inc_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		 $sql="insert into $tableName(date, gold, silver, status, dt_created)values('".$date."','".$gold."','".$silver."','1',now())";
	
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			echo $error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_id, date, gold, silver from $tableName where inc_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1, $date, $gold, $silver);
											$cat->fetch();							
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Date</label>
									</div>
									<div class="finput">
									<input name="txtdate" type="date" value="<?=@$date?>" class="" id="txtdate" required style="width:25%;">
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Gold price per gram</label>
									</div>
									<div class="finput">
									<input name="txtGold" type="text" value="<?=@$gold?>" class="" id="txtGold" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Gold price per gram</label>
									</div>
									<div class="finput">
									<input name="txtSilver" type="text" value="<?=@$silver?>" class="" id="txtSilver" >
									</div>
								</div>
								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addBanner" value="Save" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>