<?php
session_start();
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
if($_SERVER['HTTP_HOST'] == "localhost" || $_SERVER['HTTP_HOST'] == "192.168.1.9" || $_SERVER['HTTP_HOST'] == "172.16.0.3" || $_SERVER['HTTP_HOST'] == "172.16.0.4"){
	$host = "localhost";
	$user = "root";
	$password = "";
	$db = "db_excers";
	error_reporting(0);
	define ('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/excers/');
	define ('SITE_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/excers/admin/');	
	define ('SITE_IMG_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/excers/images/');	
	define ('ROOT_IMG_PATH', $_SERVER['DOCUMENT_ROOT'].'/excers/admin/images/');		
	define ('SITEDOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/excers/');
			
}else{
    $host = "dbaerofitdb.db.7463833.hostedresource.com";
    $user = "dbaerofitdb";
    $password = "Reset!2345";
    $db = "dbaerofitdb"; 

  	define (DOC_ROOT_PATH,'/home/content/83/5628983/html/demo/excers1/admin/');
    define (SITE_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/excers1/admin/');    
    define (SITE_IMG_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/excers1/images/');      
    define (ROOT_IMG_PATH, '/home/content/83/5628983/html/demo/excers1/images/');
    define (SITEDOC_ROOT_PATH, '/home/content/83/5628983/html/demo/excers1/');  

}
global $mysqli;
$mysqli = new mysqli($host, $user, $password, $db);
if ($mysqli->connect_errno) {
 //   echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

$items=array('gold'=>'gold','silver'=>'silver');
?>