<?php 
include_once("include/config.php");
$id=$_REQUEST['id'];
$stmt = $mysqli->prepare("SELECT inc_id,inc_cat_id,name,phone,comments,total_amt,given_amt,balence,village FROM tbl_bills WHERE inc_id = ? AND  status='1'");
	$stmt->bind_param('s', $_REQUEST['id']);
	$stmt->execute();
	$stmt->store_result();
	$recs_existed = $stmt->num_rows;
	
		$stmt->bind_result($det11,$det21,$det31,$det41,$det51,$det61,$det71,$det81,$det91);
		$stmt->fetch();
		$today = date("d/m/Y");
	?>
	<style>
            *, *:before, *:after {
                margin: 0px;
                padding: 0px;
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -o-box-sizing: border-box;
                -ms-box-sizing: border-box;
            }
            body {background: #ff9e9e;padding: 50px;color:#111;line-height: 22px;}
            .wrapper{width: 100%;float: left;position: relative;}
            .tc{text-align: center;}
            .tr{text-align: right;}
            .header {margin-bottom: 20px;font-size: 16px;}
            .Nleft {float:left;max-width: 200px}
            .Nleft span {float:right;}
            .Nright span {float:right;}
            .Nright {float:right;max-width: 200px}
            table{border-collapse: collapse;border: 1px solid #111;margin: 15px 0}
            table td{padding:10px;border: 1px solid #111;}
        </style>
		
		
	<div class="wrapper header tc">
            <div class="wrapper">!!SHREE!!</div>
            <div class="wrapper">ESTIMATE/ON APPROVAL</div>
            <div class="wrapper">Issue</div>
        </div>
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Name: <?=$det31?></div>
                <div class="wrapper">Phone No: <?=$det41?></div>
            </div>
            <div class="Nright tr">5362
                <div class="wrapper">Date: <?=$today?></div>
                <div class="wrapper">Page No: 1/1</div>
            </div>
        </div>
        <table class="wrapper">
            <tr>
                <td>Sr.</td>
                <td>Item Name</td>
                <td class="tr">Pcs</td>
                <td class="tr">Amount</td>
            </tr>
<?php 
if(@$_REQUEST['id']!=""){
	$id=$_REQUEST['id'];
  $query = "SELECT bill_id,prod_name,quantity,grams,price,dt_created FROM tbl_bill_products where bill_id='$id' ORDER BY inc_id DESC";
$res=mysqli_query($mysqli,$query);	
if(mysqli_num_rows($res)>0){ $i=1;
?>	
            <tr>
                <td><?=$i?></td>
                <td><?=$row['prod_name']?></td>
                <td class="tr"></td>
               <!--  <td class="tr">5224.00</td>
               <td class="tr">80.00</td>
                <td class="tr">4179.200</td>
                <td class="tr">0.30</td>-->
                <td class="tr"><?=$row['price']?></td>
            </tr>
<?php $i++;}?>
			
			<tr>
                <td colspan="2">Total</td>
                <td class="tr" colspan="2"><?=$det61?></td>
            </tr>
        </table>        
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Fine Amount: <span class="tr">$det61</span></div>
                <div class="wrapper">Labour: <span class="tr">3792.75</span></div>
                <div class="wrapper">&nbsp;</div>
                <div class="wrapper">Net Balance: <span class="tr">204844.86</span></div>
                <div class="wrapper">Narration: <span class="tr">GROSS 6158</span></div>
            </div>
            <div class="Nright">
                <div class="wrapper">Rate: <span class="tr">41000.0/1000.00</span></div>
                <div class="wrapper">Issue: <span class="tr">4903.710</span></div>
                <div class="wrapper">Recipet: <span class="tr"></span></div>
                <div class="wrapper">Old Bal Amt: <span class="tr">0.00</span></div>
                <div class="wrapper">Old Bal Net Wt: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal Amount: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal  net Wt: <span class="tr">0.00</span></div>
            </div>
        </div>	
		
		
	<?php 		
require_once('tcpdf_include.php');
// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {
	//Page header
	public function Header(){
		// get the current page break margin
        $bMargin = $this->getBreakMargin();		
		// Set font
        $this->SetFont('helvetica', '', 9);
		$image_file = ROOT_IMG_PATH.'logo.jpg';
		$this->setJPEGQuality(90);						
		$this->Image($image_file, 0, 0, 0, 31, 'JPG', '');		
	}  
	// Page footer
	public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-25);
        // Set font
        $this->SetFont('helvetica', '', 9);
		$image_file = ROOT_IMG_PATH.'logo.jpg';
		$this->setJPEGQuality(90);		
		//variables defined		
		$this->Image($image_file, 3, 285, 0, 12, 'JPG', '');
    }
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-6', false);

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.'', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

$pdf->SetFont('helvetica', '', 10);
$pdf->AddPage('A4');

// get the current page break margin
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->SetAutoPageBreak(false, 0);

// restore auto-page-break status
$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
$pdf->setPageMark();
$tbl = <<<EOD
<BR><BR><BR><BR><BR>
<div class="wrapper header tc">
            <div class="wrapper">!!SHREE!!</div>
            <div class="wrapper">ESTIMATE/ON APPROVAL</div>
            <div class="wrapper">Issue</div>
        </div>
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Name: $det31</div>
                <div class="wrapper">Phone No: $det41</div>
            </div>
            <div class="Nright tr">
                <div class="wrapper">Date: $today</div>
                <div class="wrapper">Page No: 1/1</div>
            </div>
        </div>
        <table class="wrapper">
            <tr>
                <td>Sr.</td>
                <td>Item Name</td>
                <td class="tr">Pcs</td>
                <td class="tr">Amount</td>
            </tr>
EOD;
			
$tbl = <<<EOD
            <tr>
                <td>1</td>
                <td>SSP</td>
                <td class="tr"></td>
               <!--  <td class="tr">5224.00</td>
               <td class="tr">80.00</td>
                <td class="tr">4179.200</td>
                <td class="tr">0.30</td>-->
                <td class="tr">1567.20</td>
            </tr>
EOD;  
	}
$tbl = <<<EOD			
			<tr>
                <td colspan="2">Total</td>
                <td class="tr" colspan="2">$det61</td>
            </tr>
        </table>        
        <div class="wrapper">
            <div class="Nleft">
                <div class="wrapper">Fine Amount: <span class="tr">$det61</span></div>
                <div class="wrapper">Labour: <span class="tr">3792.75</span></div>
                <div class="wrapper">&nbsp;</div>
                <div class="wrapper">Net Balance: <span class="tr">204844.86</span></div>
                <div class="wrapper">Narration: <span class="tr">GROSS 6158</span></div>
            </div>
            <div class="Nright">
                <div class="wrapper">Rate: <span class="tr">41000.0/1000.00</span></div>
                <div class="wrapper">Issue: <span class="tr">4903.710</span></div>
                <div class="wrapper">Recipet: <span class="tr"></span></div>
                <div class="wrapper">Old Bal Amt: <span class="tr">0.00</span></div>
                <div class="wrapper">Old Bal Net Wt: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal Amount: <span class="tr">0.00</span></div>
                <div class="wrapper">Bal  net Wt: <span class="tr">0.00</span></div>
            </div>
        </div>

EOD;
$pdf->writeHTML($tbl, true, false, false, false, '');    
//Close and output PDF document
$pdf->Output("Download_Brochure ".$main_title.".pdf",'I');
?>