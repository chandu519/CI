<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 
if(isset($_POST["Excel_Download"]) && $_POST["Excel_Download"]=="Download Excel"){ 
  $export = mysqli_query($mysqli,"SELECT name as FirstName,lname as LastName,email as Email,phone as Mobile,phone1 as OtherMobileNo  from tbl_users where status=1 order by dt_created asc");
 
 if(mysqli_num_rows($export)>0){
$fields = mysqli_num_fields ( $export );
 
while ($property = mysqli_fetch_field($export)) {
    @$header .= $property->name. ",";
}
 
//this is where most of the work is done. 
//Loop through the query results, and create 
//a row for each
while( $row = mysqli_fetch_row( $export ) ) {
  $line = '';
  
  //for each field in the row
  foreach( $row as $key => $value ) {
    //if null, create blank field
    if($key=='3'){$user_id=$value;}
    if ( ( !isset( $value ) ) || ( $value == "" ) ){
      $value = ",";
    }
    //else, assign field value to our data
    else {
      $value = str_replace( '"' , '""' , $value );
      $value = '"' . $value . '"' . ",";
    }
    //add this field value to our row
    $line .= $value;
  }
  //echo "select course from tbl_user_edu_details  where user_id='".$user_id."' order by passed_year desc ";
    
  
  //$line=$line."PHD,PG,UG";
  @$data .= trim( $line ) . "\n";
  
  //trim whitespace from each row
  
}
//exit;
//remove all carriage returns from the data
$data = str_replace( "\r" , "" , $data );
$file_name="Users_Data".date("d/m/y");

//create a file and send to browser for user to download
header("Content-type: application/vnd.ms-excel");
header("Content-disposition: csv" . date("Y-m-d") . ".csv");
header( "Content-disposition: filename=".$file_name.".csv");
print "$header\n$data";
exit;
 }else{
	 $_SESSION['stat']="ND";
	 $allClasses->forRedirect ('list.php');
	exit;
 }
 

}

?>