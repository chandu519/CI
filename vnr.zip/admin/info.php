<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_general_info";
$pageHeading=" Gold/ Silver Total Gross";
$pageList="wContent.php";

/*********************** Add Banners ***************************/
if(isset($_POST["addBanner"]) && $_POST["addBanner"]=="Submit"){
	
	$gold = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtGold']));
	$silver = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtSilver']));
	$old_gold = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtOgold']));
	$old_silver = mysqli_real_escape_string($mysqli,stripslashes($_POST['txtOsilver']));
	
	$sql="update tbl_general_info set gold=?,silver=?,old_gold=?, old_silver=? where inc_cat_id=1";
	if ($stmt = $mysqli->prepare($sql)){
		$si='ssss';
		$stmt->bind_param($si,$gold,$silver,$old_gold,$old_silver);
		$flag=$stmt->execute();
	//	echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error; exit;
		if($flag){
			$_SESSION['stat']="SE";
			$allClasses->forRedirect ("info.php");
			exit;
		}else{
			$_SESSION['stat']="FE";
			$allClasses->forRedirect ("info.php");
			exit;
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
		<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
					
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
								$cid =1;
									if ($cat = $mysqli->prepare("select inc_cat_id, gold, silver, old_gold, old_silver from tbl_general_info where inc_cat_id=?")) {
									$cat->bind_param('i',$cid );
									$cat->execute();
									$cat->store_result();
									if($cat->num_rows>0){
										$cat->bind_result($det1,$det2,$det3,$det4,$det5);
										$cat->fetch();
										
										
										$det4 = ($det4);
										$det4 = str_replace('\"', '"', $det4);
										$det4 = str_replace("\'", "'", $det4);
										
										$det2 = trim($det2);
										$det2 = str_replace('\"', '"', $det2);
										$det2 = str_replace("\'", "'", $det2);
										
										
										$cat->close();
									}
								}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Total Gold</label>
									</div>
									<div class="finput">
											<input name="txtGold" type="text" value="<?=@$det2?>" class="" id="txtGold" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Total Silver</label>
									</div>
									<div class="finput">
											<input name="txtSilver" type="text" value="<?=@$det3?>" class="" id="txtSilver" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Old Gold</label>
									</div>
									<div class="finput">
										<input name="txtOgold" type="text" value="<?=@$det4?>" class="" id="txtOgold" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Old Silver</label>
									</div>
									<div class="finput">
										<input name="txtOsilver" type="text" value="<?=@$det5?>" class="" id="txtOsilver" >
									</div>
								</div>
															
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addBanner" value="Submit" class="fbtn">
									</div>
								</div>
								
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>