<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_admin_users";
$pageHeading="Add Employee";
$pageAdd="addemployeeList.php";
$pageList="employeeList.php";


/*********************** Add  ***************************/
if(isset($_POST["addUser"]) && $_POST["addUser"]=="Save"){
 
	$name=trim($_POST['txtName']);
	$fullname=trim($_POST['txtfullname']);
	$email=trim($_POST['txEmail']);
	$mobile=trim($_POST['txtmobile']);
	$dob=$_POST['txtdob'];
	
	$password=$_POST['txtpassword'];
	 $created_by="admin";
	 $modified_by="admin";
	 
	 $access=$_POST['txtaccess'];
	 
	 foreach($access as $key=>$val){
		 $access1.=$val.',';
	 }
	 $access1=trim($access1,','); 
	 
	if($_FILES['txtImage']['name'] != ""){
		$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage');
		
		if($result){
			$imgName = $result;
			if(@$_POST['hid_image']!= ""){
				unlink(SITEDOC_ROOT_PATH."images/".$_POST['hid_image']);
			}
		}
	}else{
		$imgName = $_POST['hid_image'];
	}
	
	
	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		
		$sql = "update $tableName set name=?,email=?,password=?,mobile=?,image=?,dob=?,fullname=?,access=?,modified_by=?,dt_modified=now() where u_id=?";
		
		 if ($stmt = $mysqli->prepare($sql))
			{			
				$ps='ssssssssss';
				$stmt->bind_param($ps,$name,$email,$password,$mobile,$imgName,$dob,$fullname,$access1,$modified_by,$_POST['hid_cat_id']);
				$flag=$stmt->execute();
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;			
			}	
			
		if($flag)
			{
				$_SESSION['stat']="SE";
				$allClasses->forRedirect ($pageList);
				exit;
			}else{
				$_SESSION['stat']="FE";
				$allClasses->forRedirect ($pageList);
				exit;
			}
	}else{
		
		
		$sql="insert into $tableName(name,email,password,mobile,image,dob,fullname,access,created_by,status,type,dt_created)values(?,?,?,?,?,?,?,?,?,1,1,now())";
			if ($stmt = $mysqli->prepare($sql))
			{			
				$ps='sssssssss';
				$stmt->bind_param($ps,$name,$email,$password,$mobile,$imgName,$dob,$fullname,$access1,$created_by);
				$flag=$stmt->execute();
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;exit;		 				   
			}			
			if($flag)
			{			
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pageList);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pageList);
				exit;
			}
		
		
		
	}
}
/*********************** Delete Image (Update Image) ***************************/
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	$img=$_REQUEST['img'];
	unlink(SITEDOC_ROOT_PATH."images/".$img);
	$flag=mysqli_query($mysqli,"update tbl_banners set image='' where inc_cat_id='".$id."'");
	if($flag){
		$_SESSION['stat']="SE";		
	}else{
		$_SESSION['stat']="FE";
	}
	$allClasses->forRedirect ($pageAdd."?act=edit&id=".$id);
	exit;
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
										$cid=$_REQUEST['id'];
										if ($cat = $mysqli->prepare("select u_id,name,email,password,mobile,image,dob,fullname,access from $tableName where u_id=?")) {
									$cat->bind_param('i',$cid );
									$cat->execute();
									$cat->store_result();
									if($cat->num_rows>0){
										$cat->bind_result($det1,$name,$email,$password,$mobile,$det7,$dob,$fullname,$access);
										$cat->fetch();
																			
										
										echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';
										echo '<input type="hidden" name="hid_action" value="editcat" />';
										$cat->close();
									}
								}
									}else{
										$cid=0;
									}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Name</label>
									</div>
									<div class="finput">
										<input name="txtfullname" type="text" value="<?=@$fullname?>" id="txtfullname" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> email</label>
									</div>
									<div class="finput">
									<input name="txEmail" type="text" value="<?=@$email?>" class="" id="txEmail" >
										
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Username</label>
									</div>
									<div class="finput">
										<input name="txtName" type="text" value="<?=@$name?>" placeholder="This will be used for login" id="txtName" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Password </label>
									</div>
									<div class="finput">
									<input name="txtpassword" type="text" value="<?=@$password?>" class="" id="txtpassword" >
										
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Mobile No </label>
									</div>
									<div class="finput">
									<input name="txtmobile" type="text" value="<?=@$mobile?>" placeholder="optional" id="txtmobile" >
										
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="mobile">User Access </label>
									</div>
									<div class="finput">
										 <?php 
													$access11=explode(",",@$access);
														 foreach($process_status as $key => $val){
															  
													?>
													<label class="checkbox">
													<input name="txtaccess[]" type="checkbox" value="<?=@$key?>"  class="" id="txtaccess" <?php if(in_array(@$key,$access11)){ echo 'checked'; } ?>><?=$val?>
														</label> 
														
														 
														 <?php } ?>
									</div>
								</div>
								
																
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addUser" value="Save" class="fbtn">
									</div>
								</div>							
								
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>