<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_upload_files";
$pageHeading="Pqc Tab";
$pageAdd="addpqc.php";
$pageList="pqc.php";
?>
<?php 
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	$sql = "update $tableName set l1_status='".$_REQUEST['changeStatus']."',l1_created_by='".$_SESSION['admin_id']."'  where inc_id=".$_REQUEST['id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
	}
}
?>
<?php 
	/*if(@$_POST['butSubmit']=="Update"){
	for($k=1;$k<=$_POST['hidTotal'];$k++){
		$inc_id=@$_POST['hidID'.$k];
		mysqli_query($mysqli,"update $tableName set l1_status='".@$_POST['Fstatus'.$k]."',l1_created_by='".$_SESSION['admin_id']."' where inc_id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($pageList);
	exit;
}*/
	?>
<?php 
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>


<div class="wrapper table form_upload" style="margin-bottom:25px;">	
<form method="GET" class="wrapper" enctype="multipart/form-data">
<div class="rowLess" style="">
	
	<div class="width10">
		<h2>File Status :</h2>
	</div>
	<div class="width25">
		<select  name="File_Status" id="" >
		<option value="">Select</option>
		<option value="Accept" <?php if(@$_REQUEST['File_Status']=='Accept'){echo 'selected';}?>>Accept</option>
		<option value="Reject" <?php if(@$_REQUEST['File_Status']=='Reject'){echo 'selected';}?>>Reject</option>
		<option value="Corrections" <?php if(@$_REQUEST['File_Status']=='Corrections'){echo 'selected';}?>>Corrections</option>
	</select>
	</div>
	
	<div class="width25 ga_btn ">
		<input type="submit" name="submit"  value="Search" class="fbtn">
	</div>
</div>
</form>
</div>



  <style>
 .form_upload .finput input {
    float: right;
	height: 38px;
	margin-left: 10px;
 }
</style>
					
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						
						
						
						<div class="wrapper table form_upload">	

						<div class="wrapper finput" >
							<!--<a href="<?=$pageAdd?>" class="addNew">Add New</a>-->
						</div>						
							<?php 
							if(@$_REQUEST['File_Status']!=""){
								@$sq= "and file_status='".$_REQUEST['File_Status']."'";
							}
							if ($cat1 = $mysqli->prepare("select inc_id,journals_id,article_id,file_name,file,image,tables,status,priority,l1_status from $tableName where status=1 ".@$sq." order by dt_created asc ")) 
								{
									$cat1->execute();
									$cat1->store_result();
									if($cat1->num_rows>0){
										$cat1->bind_result($det11,$det21,$det31,$det41,$det81,$det61,$det91,$det51,$det71,$file_status);
					
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>S no</th>
												<th>Article Id</th>
												<th>File Name</th>
												<th>File</th>																		
												<th>Image</th>																		
												<th>File Status</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($cat1->fetch()){
									?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>"  />														
											<tr>
												<td><?=$i?></td>
												<td><a href="addarticles.php?act=edit&id=<?=$det31?>" target="_blank"><?=$det31?></a></td>
												<td><a href="addfiles.php?act=edit&id=<?=$det11?>" target="_blank"><?=$det41?></a></td>
												<td><a href="../documents/<?=$det81?>" target="_blank">View File</a></td>
												<td><a href="../images/<?=$det61?>" target="_blank">View Image</a></td>
											
												<td class="finput" style="width:100%;">
	
<style>
table a.giveAccept{
    float: right;
    margin-bottom: 5px;
    padding: 5px 5px;
    background: #fff;
	border:1px solid #2e6892;
    color: #fff;
    border-radius: 3px;
    transition: all .5s;
}
table td a.giveAcceptActive{
	float: right;
    margin-bottom: 5px;
    padding: 5px 5px;
  background: #1c5075;
    border:1px solid #2e6892;
    border-radius: 3px;
    transition: all .5s;
	  color: #fff;
}
table a.giveAccept:hover {
    background: #1c5075;
    transition: all .5s;
	  color: #fff;
</style>	
													<!--<a class="addBtn" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$det11?>">Accept</a>-->
											
													
													<a style="font-size: 14px;" href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=Corrections" class="<?php if($file_status=='Corrections'){?>giveAcceptActive<?php }else{?>giveAccept<?php } ?>">Corrections</a>
													<a style="font-size: 14px;" href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=Reject" class="<?php if($file_status=='Reject'){?>giveAcceptActive<?php }else{?>giveAccept<?php } ?>">Reject</a>
													<a style="font-size: 14px; " href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=Accept" class="<?php if($file_status=='Accept'){?>giveAcceptActive<?php }else{?>giveAccept<?php } ?>">Accept</a>
													
													<!--<select name="Fstatus<?=$i?>" id="Fstatus<?=$i?>" style="margin-bottom: 0px;">
													<option value="">Select</option>
													<option value="Accept" <?php if($file_status=='Accept'){echo 'selected';}?>>Accept</option>
													<option value="Reject" <?php if($file_status=='Reject'){echo 'selected';}?>>Reject</option>
													<option value="Corrections" <?php if($file_status=='Corrections'){echo 'selected';}?>>Corrections</option>
													</select>-->
													
												
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										<tr>
											<td></td>
											<td></td>
											<td></td>	
											<td></td>
											<td></td>											
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
								}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>   
					
	</body>
</html>