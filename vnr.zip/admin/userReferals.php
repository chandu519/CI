<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_tax_process";
$pageHeading="Tax Summary";
//$pageAdd="addBanner.php";
$pageList="userReferals.php";

/*-----------------------------------*/


?>
<!doctype html>
<!--

<li><a href="viewDetails.php">Tax Payer</a></li>
<li><a href="view-spouce-Details.php">Spouse Details</a></li>
<li><a href="dependent-info.php">Dependent Details</a></li>
<li><a href="interview-pending-info.php">Interview Pending</a></li>
<li><a href="userDocuments.php">Documents</a></li>
<li><a href="userTaxSummary.php">Tax Summary</a></li>
<li><a href="userReferals.php">Referals</a></li>
<li><a href="userFilestatus.php">File Info/Status</a></li>

-->

<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php //include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
							<?php 
							if(isSet($_SESSION['stat'])){
							?>										
							<?php 
							if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
								$error_msg="";
							}
							if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
								$error_msg="error_msg";	
							}
							?>
							<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
							<?php 
								unset($_SESSION['stat']);
							}
							?>							
						 
					<div class="wrapper table">	
									
							<?php 
							if(@$_REQUEST['file_no']!=""){
								$file_no=$_REQUEST['file_no'];
								$query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
								$res=mysqli_query($mysqli,$query);
								if(mysqli_num_rows($res)>0){ 
								
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th> Name </th>
												<th> Email</th>	
												<th>Phone</th>											
																			
																
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>" />														
											<tr>
												<td><?=$i?></td>
												<td><?=$row['ref_first_name']?> <?=$row['ref_last_name']?></td>
												<td><?=$row['ref_email_id']?></td>		
												<td><?=$row['ref_phone']?></td>
												
											</tr>	
											<?php $i++;
										}
										?>			
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>


						
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>