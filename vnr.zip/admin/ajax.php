<?php include_once "includes/config.php"; 
if($_POST['action']=="forgotPassword" && $_POST['str']!="")
{
	$id=trim($_POST["str"]);

	$stmt = $mysqli->prepare("select name,password,status,type,email from tbl_admin_users where BINARY email=? or name=?");
	/* Bind parameters. Types: s = string, i = integer, d = double,  b = blob */
	$stmt->bind_param('ss', $id, $id);
	$stmt->execute();
	$stmt->store_result();
	if($stmt->num_rows>0){
		$stmt->bind_result($user_id, $user_pwd, $status, $type,$email);
		$stmt->fetch();
		if($status==1){				
			$message = "Dear, <br> <br> Below are your login details.<br><br><table border-collapse:collapse  width='100%' cellpadding='5' cellspacing='5' style='border-radius:0.4em;font-family:Arial;font-size:13px;background-color:#eee'>
			<tr style='border-bottom: 1px solid #ccc;'>
			<td width='20%'><b>Username</b></td>
			<td width='1%'>:</td>
			<td width='78%'>$user_id</td>
			</tr>
			<tr style='border-bottom: 1px solid #ccc;'>
			<td width='20%'><b>Password</b></td>
			<td width='1%'>:</td>
			<td width='78%'>$user_pwd</td>
			</tr>    			    
			</table><br><br>Thanks,<br>SVFB";		
			$subject = "$pgTitle - Password Recovery";
			// To send HTML mail, the Content-type header must be set
			$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$headers .= 'From: info@svfb.co'. "\r\n";
	
			// Mail it			
			if(@mail($email, $subject, $message, $headers)){
				echo "Password has been sent to your email";
			}else{
				echo 'Something went wrong..!';
			}
		}else{
			echo 'Username locked';
		}				
	}else{
		echo 'Invalid username';
	}		
}
if($_POST['action']=="getBranchDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT id, b_name, b_login_id, b_password, b_phone, b_location, b_address FROM tbl_branch WHERE id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($id, $b_name, $b_login_id, $b_password, $b_phone, $b_location, $b_address);		
		$qlinksStmt->fetch();
		?>		
		<input type="hidden" name="hid_id" value="<?=$id?>">
		<input class="wrapper" type="text" value="<?=$b_login_id?>" disabled>	 
		<input id="val-username" class="wrapper" type="text" name="val-username" placeholder="Enter branch name" value="<?=$b_name?>" required>	 
		<input id="val-password" class="wrapper" type="text" name="val-password" placeholder="Enter password" value="<?=$b_password?>" required>
		<input id="val-phoneus" class="wrapper" type="text" name="val-phoneus" placeholder="Enter phone (optional)" value="<?=$b_phone?>">
		<input type="submit" name="btnEditBranch" value="Submit">
		<?php		
	}
}
if($_POST['action']=="getEmployeeDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT u_id, name, email, password, mobile, image, dob FROM tbl_admin_users WHERE u_id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($id, $b_name, $b_login_id, $b_password, $b_phone, $b_location, $b_address);		
		$qlinksStmt->fetch();
		?>		
		<input type="hidden" name="hid_id" value="<?=$id?>">
		<input class="wrapper" type="text" value="<?=$b_name?>" disabled>	 
		<input id="val-username" class="wrapper" type="text" name="val-username" placeholder="Enter email" value="<?=$b_login_id?>" required>	 
		<input id="val-password" class="wrapper" type="text" name="val-password" placeholder="Enter password" value="<?=$b_password?>" required>
		<input id="val-phoneus" class="wrapper" type="text" name="val-phoneus" placeholder="Enter phone (optional)" value="<?=$b_phone?>">
		<input type="submit" name="btnEditEmployee" value="Submit">
		<?php		
	}
}
if($_POST['action']=="getDataFormDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT id,d_value,form_fields,form_id FROM tbl_data WHERE id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($d_id, $d_value, $form_fields, $form_id);		
		$qlinksStmt->fetch();
		$d_valueArr=explode('#$#',$d_value);	
		$form_fieldsArr=explode(',',$form_fields);
		?>
		<input type="hidden" name="hid_id" value="<?=$id?>">
		<input type="hidden" name="form_id" value="<?=$form_id?>">
		<?php
		for($d=0;$d<count($d_valueArr);$d++){
			$qlinksStmt1 = $mysqli->prepare("SELECT id,b_name FROM tbl_data_fields WHERE id=?");
			$qlinksStmt1->bind_param('s',$form_fieldsArr[$d]);
			$qlinksStmt1->execute();
			$qlinksStmt1->store_result();	
			$qlinksStmt1->bind_result($df_id,$b_name);		
			$qlinksStmt1->fetch();			
		?>		
		<div class="wrapper">
		<label><?=$b_name?></label>
		<input class="" name="txtValue[]" value="<?=$d_valueArr[$d]?>">	 		
		</div>
		<?php				
		}
		?>
		<input type="submit" name="btnEditUploadDataForm" value="Submit">
		<?php
	}
}
if($_POST['action']=="getFormFieldDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT id, b_name FROM tbl_data_fields WHERE id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($id, $b_name);		
		$qlinksStmt->fetch();
		?>		
		<input type="hidden" name="hid_id" value="<?=$id?>">		
		<input id="val-username" class="wrapper" type="text" name="val-username" placeholder="Enter branch name" value="<?=$b_name?>" required>	 		
		<input type="submit" name="btnEditDFField" value="Submit">
		<?php		
	}
}
if($_POST['action']=="getFolderDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT c_id, c_name, c_pid, c_icon, c_type, c_status FROM tbl_folder_path WHERE c_id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($c_id, $c_name, $pid, $c_icon, $c_type, $c_status);		
		$qlinksStmt->fetch();
		
function getOptions1($id,$level,$cat_id,$mysqli){
	$query = "select * from tbl_folder_path where c_pid='".$id."' order by c_id asc";
	$result = mysqli_query($mysqli,$query);	
	if(mysqli_num_rows($result)>0){
		$level=$level+1;
	}
	while($row = mysqli_fetch_assoc($result)){		 
		?>
		<option style="padding:4px 0px;" value="<?=$row['c_id']?>" class="level<?=$level?>" <?php if($cat_id==$row['c_id']) echo 'selected'; ?>> <?php for($m=1;$m<=($level-1);$m++){  echo '-'; } ?> <?=$row['c_name']?></option>
		<?php
		getOptions1($row['c_id'],$level,$cat_id,$mysqli);
	}		
}		
		?>		
		<input type="hidden" name="hid_id" value="<?=$c_id?>">
		<select class="wrapper" name="val-pid" id="val-pid">
			<option value="0">Select Parent</option>
			<?php												
			getOptions1(0,0,$pid,$mysqli);
			?>	
		</select>
		<input id="val-name" class="wrapper" type="text" name="val-name" placeholder="Enter branch name" value="<?=$c_name?>" required>	 
		
		<input type="submit" name="btnEditFolder" value="Submit">
		<?php		
	}
}
//Data
if($_POST['action']=="getDataFolderDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT c_id, c_name, c_pid, c_icon, c_type, c_status FROM tbl_folder_path_data WHERE c_id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($c_id, $c_name, $pid, $c_icon, $c_type, $c_status);		
		$qlinksStmt->fetch();
		
function getOptions1($id,$level,$cat_id,$mysqli){
	$query = "select * from tbl_folder_path_data where c_pid='".$id."' order by c_id asc";
	$result = mysqli_query($mysqli,$query);	
	if(mysqli_num_rows($result)>0){
		$level=$level+1;
	}
	while($row = mysqli_fetch_assoc($result)){		 
		?>
		<option style="padding:4px 0px;" value="<?=$row['c_id']?>" class="level<?=$level?>" <?php if($cat_id==$row['c_id']) echo 'selected'; ?>> <?php for($m=1;$m<=($level-1);$m++){  echo '-'; } ?> <?=$row['c_name']?></option>
		<?php
		getOptions1($row['c_id'],$level,$cat_id,$mysqli);
	}		
}		
		?>		
		<input type="hidden" name="hid_id" value="<?=$c_id?>">
		<select class="wrapper" name="val-pid" id="val-pid">
			<option value="0">Select Parent</option>
			<?php												
			getOptions1(0,0,$pid,$mysqli);
			?>	
		</select>
		<input id="val-name" class="wrapper" type="text" name="val-name" placeholder="Enter branch name" value="<?=$c_name?>" required>	 
		
		<input type="submit" name="btnEditDataFolder" value="Submit">
		<?php		
	}
}
//Gallery
if($_POST['action']=="getGalleryDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT c_id, c_name, c_pid, c_icon, c_type, c_status FROM tbl_folder_path_gal WHERE c_id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($c_id, $c_name, $pid, $c_icon, $c_type, $c_status);		
		$qlinksStmt->fetch();
		
function getOptions1($id,$level,$cat_id,$mysqli){
	$query = "select * from tbl_folder_path_gal where c_pid='".$id."' order by c_id asc";
	$result = mysqli_query($mysqli,$query);	
	if(mysqli_num_rows($result)>0){
		$level=$level+1;
	}
	while($row = mysqli_fetch_assoc($result)){		 
		?>
		<option style="padding:4px 0px;" value="<?=$row['c_id']?>" class="level<?=$level?>" <?php if($cat_id==$row['c_id']) echo 'selected'; ?>> <?php for($m=1;$m<=($level-1);$m++){  echo '-'; } ?> <?=$row['c_name']?></option>
		<?php
		getOptions1($row['c_id'],$level,$cat_id,$mysqli);
	}		
}		
		?>		
		<input type="hidden" name="hid_id" value="<?=$c_id?>">
		<select class="wrapper" name="val-pid" id="val-pid">
			<option value="0">Select Parent</option>
			<?php												
			getOptions1(0,0,$pid,$mysqli);
			?>	
		</select>
		<input id="val-name" class="wrapper" type="text" name="val-name" placeholder="Enter branch name" value="<?=$c_name?>" required>	 
		
		<input type="submit" name="btnEditGallery" value="Submit">
		<?php		
	}
}
//Video
if($_POST['action']=="getVideoDataById" && $_POST['id']!="")
{
	$id=$_POST['id'];
	$qlinksStmt = $mysqli->prepare("SELECT c_id, c_name, c_pid, c_icon, c_type, c_status FROM tbl_folder_path_video WHERE c_id=$id");
	$qlinksStmt->execute();
	$qlinksStmt->store_result();
	if($qlinksStmt->num_rows>0)
	{
		$qlinksStmtCount=$qlinksStmt->num_rows;
		$qlinksStmt->bind_result($c_id, $c_name, $pid, $c_icon, $c_type, $c_status);		
		$qlinksStmt->fetch();
		
function getOptions1($id,$level,$cat_id,$mysqli){
	$query = "select * from tbl_folder_path_video where c_pid='".$id."' order by c_id asc";
	$result = mysqli_query($mysqli,$query);	
	if(mysqli_num_rows($result)>0){
		$level=$level+1;
	}
	while($row = mysqli_fetch_assoc($result)){		 
		?>
		<option style="padding:4px 0px;" value="<?=$row['c_id']?>" class="level<?=$level?>" <?php if($cat_id==$row['c_id']) echo 'selected'; ?>> <?php for($m=1;$m<=($level-1);$m++){  echo '-'; } ?> <?=$row['c_name']?></option>
		<?php
		getOptions1($row['c_id'],$level,$cat_id,$mysqli);
	}		
}		
		?>		
		<input type="hidden" name="hid_id" value="<?=$c_id?>">
		<select class="wrapper" name="val-pid" id="val-pid">
			<option value="0">Select Parent</option>
			<?php												
			getOptions1(0,0,$pid,$mysqli);
			?>	
		</select>
		<input id="val-name" class="wrapper" type="text" name="val-name" placeholder="Enter branch name" value="<?=$c_name?>" required>	 
		
		<input type="submit" name="btnEditVideo" value="Submit">
		<?php		
	}
}
if($_POST['action']=="getSearchResults" && $_POST['str']!="")
{
	$str=trim($_POST['str']);
	$query = "select * from tbl_users where file_no like '%".$str."%' or email like '%".$str."%' or phone like '%".$str."%'  order by inc_id asc";
	$result = mysqli_query($mysqli,$query);	
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result)){
		?>
		<tr>
			<td><?=$row['file_no']?></td>		
			<td><?=$row['name']?></td>		
			<td><?=$row['email']?></td>			
			<td><?=$row['phone']?></td>	

				<?php 
				$query1 = "SELECT * FROM tbl_user_tax_process where file_no='".$row['file_no']."'";
				$res1=mysqli_query($mysqli,$query1);
				$row1 = mysqli_fetch_array($res1);
					?>
				<td><?=$process_status[$row1['status']];?></td>			
			<td><a href="viewDetails.php?file_no=<?=$row['file_no']?>">View Details</a></td>		
	
						
			
		</tr>		
		<?php
		}
	}else{
		?>
		<tr>
			<td colspan="3">No data</td>
		</tr>	
		<?php
	}
}
?>