<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

$tableName="tbl_home_content";
$pageHeading="Edit SEO Content";
$pageAdd="editContent.php";
$pageList="editContent.php";

if(isset($_POST["addContent"]) && $_POST["addContent"]=="Submit"){
	$id=0;
	$category = $pages[$_POST['cmbPGNames']];
	$content = base64_encode($_POST['txtContent']);
	$seo_title = base64_encode($_POST['txtSeoTitle']);
	$seo_keywords = base64_encode($_POST['txtSeoKeywords']);
	$seo_desc = base64_encode($_POST['txtSeoDesc']);
	
		$cat = $mysqli->prepare("select content from tbl_content where page_name=?");
		//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		$cat->bind_param('s',$category );
		$cat->execute();
		$cat->store_result();
		if($cat->num_rows>0){
				$sql="update tbl_content set content=?,seo_title=?,seo_keywords=?,seo_desc=? where page_name =?";
				if ($stmt = $mysqli->prepare($sql)){
					$si='sssss';
					$stmt->bind_param($si,$content,$seo_title,$seo_keywords,$seo_desc,$category);
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					$flag=$stmt->execute();
					if($flag){
						$_SESSION['stat']="SE";
						$allClasses->forRedirect ("editContent.php?pgId=".$_REQUEST['pgId']);
						exit;
					}else{
						$_SESSION['stat']="FE";
						$allClasses->forRedirect ("editContent.php?pgId=".$_REQUEST['pgId']);
						exit;
					}
				}
		}else{
				$sql="insert into tbl_content(page_name,content,seo_title,seo_keywords,seo_desc,dt_created)values(?,?,?,?,?,current_date())";
				if($stmt = $mysqli->prepare($sql)){
					$s='sssss';
					$stmt->bind_param($s,$category, $content,$seo_title,$seo_keywords,$seo_desc);
					$flag=$stmt->execute();
					if($flag){
						$_SESSION['stat']="SA";
						$allClasses->forRedirect ("editContent.php?pgId=".$_REQUEST['pgId']);
						exit;
					}else{
						$_SESSION['stat']="FA";
						$allClasses->forRedirect ("editContent.php?pgId=".$_REQUEST['pgId']);
						exit;
					}
				}
		}
	
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
		<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       <ul class="braeds">
                           
                            <li><a href="https://www.3kits.com/blog-details.php?key=the-importance-of-keywords-in-search" target="_blank">What is SEO ?</a></li>
                        </ul>
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Select Page </label>
									</div>
									<div class="finput">
									
									<select name="cmbPGNames" class="form-control" onChange="javascript:window.location='<?=$_SERVER['PHP_SELF']."?pgId="?>'+this.value" required>
										<option value="" selected="selected">--Select Page Name--</option>

										<?php
											if($_REQUEST['pgId']!="" && is_numeric($_REQUEST['pgId'])){
												$pgId = $_REQUEST['pgId'];
											}else{
												$pgId = 1;
											}
											
											/*if($_REQUEST['pgId'] == 1){
												$selected = ' selected="selected"';
												echo '<option value="1"'.$selected.'>Home</option>';
											}else{*/
												foreach($pages as $key => $val){
													if($key >= 1){
														$selected = '';
														if($pgId == $key){
															$selected = ' selected="selected"';
														}
														echo '<option value="'.$key.'"'.$selected.'>'.$val.'</option>';
													}
												}
											/*}	*/
											?>            
										</select>
									
									
											
									</div>
								</div>
								
								<?php
							if($pgId <= count($pages)){
								$cat_name = $pages[$pgId];
								if ($cat = $mysqli->prepare("select content, seo_title, seo_keywords, seo_desc from tbl_content where page_name=?")) {
									$cat->bind_param('s',$cat_name );
									$cat->execute();
									$cat->store_result();
									if($cat->num_rows>0){
										$cat->bind_result($content,$seo_title,$seo_keywords,$seo_desc);
										$cat->fetch();
										
										$content = base64_decode($content);
										$content = str_replace('\"', '"', $content);
										$content = str_replace("\'", "'", $content);
										
										$seo_title = base64_decode($seo_title);
										$seo_title = str_replace('\"', '"', $seo_title);
										$seo_title = str_replace("\'", "'", $seo_title);
										
										$seo_keywords = base64_decode($seo_keywords);
										$seo_keywords = str_replace('\"', '"', $seo_keywords);
										$seo_keywords = str_replace("\'", "'", $seo_keywords);
										
										$seo_desc = base64_decode($seo_desc);
										$seo_desc = str_replace('\"', '"', $seo_desc);
										$seo_desc = str_replace("\'", "'", $seo_desc);
										
										$cat->close();
									}
								}
						?>	
						<?php
							}else{
								echo '<div class="redtext2"><br><br><b>Invalid Page Name</b></div>';
							}        
						?>
								
								<div class="wrapper" style="margin-bottom:25px; ">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
										<textarea class="" name="txtContent" ><?php echo @$det4; ?></textarea>
									</div>
								</div>
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Meta Title</label>
									</div>
									<div class="finput">
									<input type="text" class="" name="txtSeoTitle" id="txtSeoTitle" value="<?=@$seo_title?>"/>	
										
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Meta Keywords</label>
									</div>
									<div class="finput">
									<input type="text" class="form-control" name="txtSeoKeywords" id="txtSeoKeywords" value="<?=@$seo_keywords?>"/>			
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Meta Description</label>
									</div>
									<div class="finput">
									<input type="text" class="form-control" name="txtSeoDesc" id="txtSeoDesc" value="<?=@$seo_desc?>"/>	
									</div>
								</div>
															
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addContent" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>