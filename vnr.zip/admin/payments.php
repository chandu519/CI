<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_payments";
$pageHeading="Payments";
$pageAdd="";
$pageList="payments.php";

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	

										
							<?php 
							$query = "SELECT * FROM $tableName ORDER BY inc_id desc";
							$res=mysqli_query($mysqli,$query);	
							if(mysqli_num_rows($res)>0){ 
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>File No </th>
												<th>Transaction Id </th>
												<th>Amount</th>
												<th>Currency</th>		
												<th>Status</th>													
												<th>Payment Date</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											$usr_id=$row['inc_id'];
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>" />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$row['file_no']?></a></td>	
												<td><?=$row['tx_id']?></a></td>				
												<td><?=$row['amt']?></td>
												<td><?=$row['cc']?></td>
												<td><?=$row['status']?></td>
											
												<td class="button-list">
													<?=$row['dt_created']?>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
						}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>