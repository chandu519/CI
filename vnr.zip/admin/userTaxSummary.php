<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_tax_summary";
$pageHeading="Tax Summary";
$pageAdd="addBanner.php";
$pageList="userTaxSummary.php";

/*-----------------------------------*/

if(isset($_POST["subFile"]) && $_POST["subFile"]=="UPLOAD"){
	
	$file_no=$_REQUEST['file_no'];
	
	$txtdoc_type=$_POST['tax_summary_type'];
	if($_FILES['txtFile']['type']=="pdf"){
	if($_FILES['txtFile']['name']!=""){
		$file_name = $_FILES['txtFile']['name'];
		$file_tmp =$_FILES['txtFile']['tmp_name'];
		$desired_dir=DOC_ROOT_PATH."documents/";
		$newfile_name = date('Y')."_".time()."_".str_replace(" ","_",$file_name);
		move_uploaded_file($file_tmp,"$desired_dir/".$newfile_name);
	}
	
		 $sql="INSERT INTO  tbl_tax_summary(file_no, uploaded_by, tax_summary_type, path, dt_created, dt_modified) VALUES ('".$file_no."','".$_SESSION['admin_id']."','".$txtdoc_type."','".$newfile_name."',now(),now())";
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			//exit;
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($current_page);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ('userTaxSummary.php');
				exit;
			}
		}
	
	}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ('userTaxSummary.php');
				exit;
			}
	
}

if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	$file_no=$_REQUEST['file_no'];
	if($stmt1 = $mysqli->prepare("SELECT inc_id,path FROM $tableName WHERE inc_id=?")) {
		$stmt1->bind_param('i', $id);
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($inc_cat_id,$image);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
			if($image!=""){
				unlink(DOC_ROOT_PATH."images/".$image);
			}
			$sql="DELETE FROM $tableName WHERE inc_id =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='i';
				$stmt->bind_param($s, $id);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}				
			}
		}	else{
			$_SESSION['stat']="NDE";					
		}
		$allClasses->forRedirect ('userTaxSummary.php?file_no='.$file_no); exit;
	}
}

?>
<!doctype html>
<!--

<li><a href="viewDetails.php">Tax Payer</a></li>
<li><a href="view-spouce-Details.php">Spouse Details</a></li>
<li><a href="dependent-info.php">Dependent Details</a></li>
<li><a href="interview-pending-info.php">Interview Pending</a></li>
<li><a href="userDocuments.php">Documents</a></li>
<li><a href="userTaxSummary.php">Documents</a></li>
<li><a href="userReferals.php">Documents</a></li>

-->

<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php //include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">
					<?php include "includes/ui_info_top.php"; ?>   					
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
							<?php 
							if(isSet($_SESSION['stat'])){
							?>										
							<?php 
							if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
								$error_msg="";
							}
							if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
								$error_msg="error_msg";	
							}
							?>
							<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
							<?php 
								unset($_SESSION['stat']);
							}
							?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								
									
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Select Document Type</label>
									</div>
									<div class="finput">
										<select name="tax_summary_type" id="tax_summary_type" required>
											<option value="">Select Tax Summary Type</option>
											<option value="2017 Tax Summary">2017 Tax Summary</option>
											<option value="2016 Tax Summary">2016 Tax Summary</option>
											<option value="2015 Tax Summary">2015 Tax Summary</option>
											<option value="Tax Documents">Tax Documents</option>
										</select>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Choose File</label>
									</div>
									<div class="finput">
										<input type="file" name="txtFile" id="txtFile" value="" >
									</div>
								</div>
															
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="subFile" value="UPLOAD" class="fbtn">
									</div>
								</div>
							
								
								
								
							</form>
						</div>   
		<div class="wrapper table">	
					
							<?php 
							if(@$_REQUEST['file_no']!=""){
								$file_no=$_REQUEST['file_no'];
								$query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
								$res=mysqli_query($mysqli,$query);
								if(mysqli_num_rows($res)>0){ 
								
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th> Tax Summary </th>
												<th> Date Uploded </th>	
												<th>Document</th>
												<th>Action</th>											
																			
																
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>" />														
											<tr>
												<td><?=$i?></td>
												<td><?=$row['tax_summary_type']?></td>
												<td><?=$row['dt_created']?></td>		
												<td><a href="../documents/<?=$row['path']?>" target="_blank">View</a></td>
												<td><a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?file_no=".$row['file_no']."&act=del&id=".$row['inc_id']?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a></td>
												
											</tr>	
											<?php $i++;
										}
										?>			
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>


						
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>