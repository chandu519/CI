<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_info";
$pageHeading="User Info";
//$pageAdd="addBanner.php";
$pageList="viewDetails.php";


?>

<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php //include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
					<?php include "includes/ui_info_top.php"; ?>      
					
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
							<?php 
							if(isSet($_SESSION['stat'])){
							?>										
							<?php 
							if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
								$error_msg="";
							}
							if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
								$error_msg="error_msg";	
							}
							?>
							<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
							<?php 
								unset($_SESSION['stat']);
							}
							?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['file_no']!=""){
										$file_no=$_REQUEST['file_no'];
									 $query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
										$res=mysqli_query($mysqli,$query);
										if(mysqli_num_rows($res)>0){ 
										$row = mysqli_fetch_array($res);
										
									?> 
									
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">First Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['f_name']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">middle Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['m_name']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Last Name</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['l_name']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">SSN/ITIN Number</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['tin']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Occupation</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['occupation']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Date Of Birth</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['dob']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Gender</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?php if($row['gender']==1){echo 'male';} else{echo 'Female';}?>" disabled>
									</div>
								</div>
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Phone , Other Phone No</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['phone']?> , <?=$row['phone1']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Email ID</label>
									</div>
									<div class="finput">
									<?php 
									$query1 = "SELECT * FROM tbl_users where file_no='".$file_no."' ";
										$res1=mysqli_query($mysqli,$query1);
										$row1 = mysqli_fetch_array($res1);
									?>
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row1['email']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Street Address & Apt No</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['address']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">City</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['city']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">State</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['state']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Zipcode</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['pincode']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Country</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['country']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Visa Type</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['vis_type']?>" disabled>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Current Employer</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['c_employer']?>" disabled>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Filing Status</label>
									</div>
									<div class="finput">
										<input type="text" name="txtTitle" id="txtTitle" value="<?=$row['filling_status']?>" disabled>
									</div>
								</div>
								
									<?php }else{ ?>
							<div class="wrapper no_docs_data">
								No data Available
							</div>
							<?php 
						}
						?> <?php }?>
								
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>