<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 


//Table & Page Details
$tableName="ppm_catalogues";
$pageHeading="Service Catalogues";
$pageAdd="addcatalogues.php";
$pageList="catalogues.php";

/*********************** Add Banners ***************************/
if(isset($_POST["subBanner"]) && $_POST["subBanner"]=="Submit"){

	$txtName=$_POST['txtName'];
	$txtLink=$_POST['txtLink'];
	$txtContent=$_POST['txtContent'];
	
	if($_POST['txtSeoTitle']!=""){$meta_title=base64_encode($_POST['txtSeoTitle']);}else{$meta_title=base64_encode($_POST['txtName']);}
	if($_POST['txtSeoKeywords']!=""){$meta_keywords=base64_encode($_POST['txtSeoKeywords']);}else{$meta_keywords=base64_encode($_POST['txtName']);}
	if($_POST['txtSeoDesc']!=""){$meta_descr=base64_encode($_POST['txtSeoDesc']);}else{$meta_descr=base64_encode($_POST['txtName']);}
	
	
		if(@$_POST['hid_action']=="edit" && $_POST['hid_id']!=""){
	
		
		$stmt_1 = $mysqli->prepare("update $tableName set title=?,content=?,link=?,meta_descr=?,meta_keywords=?,meta_title=? where image=777 and inc_cat_id=?");
		$stmt_1->bind_param("sssssss",$txtName,$txtContent,$txtLink,$meta_descr,$meta_keywords,$meta_title,$_POST['hid_id']);							
		$flag_1=$stmt_1->execute();			
		$_SESSION['stat']="SE";
		$link=$_POST['hid_id']; 
		}
		
	
 
}

if(@$_REQUEST['act']=="delete" && @$_REQUEST['cid']!=""){
$sql="delete from $tableName where inc_cat_id='".$_REQUEST['cid']."'";
mysqli_query($mysqli,$sql);
$_SESSION['stat']="SD";
$allClasses->forRedirect ($pageList);
exit;
}

?>
<?php 
	if(@$_POST['butSubmit']=="Update"){
	for($k=1;$k<=$_POST['hidTotal'];$k++){
		$inc_id=@$_POST['hidID'.$k];
		//echo "update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'"; exit;
		mysqli_query($mysqli,"update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($pageList);
	exit;
}
	?>
<?php 
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select inc_cat_id from $tableName where inc_cat_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
				$sql="update $tableName set status=? where inc_cat_id=?";
				if ($stmt = $mysqli->prepare($sql)){
					$ii='ss';
					$stmt->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stmt->execute();
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";
						$allClasses->forRedirect ($pageList);
						exit;
					}else{
						$_SESSION['stat']="FE";
						$allClasses->forRedirect ($pageList);
						exit;
					}
				}
			}
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table form_upload">
						<div class="wrapper">
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									$cid="1";
								if ($cat = $mysqli->prepare("select inc_cat_id,title,link,content,meta_descr,meta_keywords,meta_title from $tableName where inc_cat_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det2,$det3,$det4,$det11,$det10,$det9);
											$cat->fetch();
											
											//$det3 = base64_decode($det3);
											$det4 = str_replace('\"', '"', $det4);
											$det4 = str_replace("\'", "'", $det4);
											
											$det2 = str_replace('\"', '"', $det2);
											$det2 = str_replace("\'", "'", $det2);
											
												$det9 = base64_decode($det9);
												$det9 = str_replace('\"', '"', $det9);
												$det9 = str_replace("\'", "'", $det9);
											
												$det10 = base64_decode($det10);
												$det10 = str_replace('\"', '"', $det10);
												$det10 = str_replace("\'", "'", $det10);
											
												$det11 = base64_decode($det11);
												$det11 = str_replace('\"', '"', $det11);
												$det11 = str_replace("\'", "'", $det11);
												
											
											echo '<input type="hidden" name="hid_id" value="'.$det1.'" />';
											echo '<input type="hidden" name="hid_action" value="edit" />';
											$cat->close();
										}
									}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Heading 1</label>
									</div>
									<div class="finput">
									<input name="txtName" type="text" class="" id="txtName" value="<?=@$det2?>" placeholder=""></div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Heading 2</label>
									</div>
									<div class="finput">
									<input name="txtLink" type="text" class="" id="txtLink" value="<?=@$det3?>" placeholder=""></div>
								</div>
								<div class="wrapper" style="margin-bottom:25px; ">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
										<textarea class="" name="txtContent" id="txtContent" ><?php echo @$det4; ?></textarea>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Seo Title</label>
									</div>
									<div class="finput">
									<input name="txtSeoTitle" type="text" value="<?=@$det9?>" class="" id="txtSeoTitle" >
									</div>
								</div><div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Seo Keywords</label>
									</div>
									<div class="finput">
									<input name="txtSeoKeywords" type="text" value="<?=@$det10?>" class="" id="txtSeoKeywords" >
									</div>
								</div><div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Seo Description</label>
									</div>
									<div class="finput">
									<input name="txtSeoDesc" type="text" value="<?=@$det11?>" class="" id="txtSeoDesc" >
									</div>
								</div>
																
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="subBanner" value="Submit" class="fbtn">
									</div>
								</div>
							</form>							
						</div>
						
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							<?php 
							if ($cat1 = $mysqli->prepare("select inc_cat_id,title,link,content,status,image,priority from $tableName where  curl='0' order by priority asc ")) 
			{
				$cat1->execute();
				$cat1->store_result();
				if($cat1->num_rows>0){
					$cat1->bind_result($det11,$det21,$det31,$det41,$det51,$det61,$det71);
					
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>S no</th>
												<th>Name</th>
												<th>Image</th>
												<th>Priority</th>																																									
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($cat1->fetch()){
									?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>"  />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$det21?></td>
												<td><?php if($det61!=""){?><a href="../images/<?=$det61?>" target="_blank">View File</a><?php } ?></td>
												<td>
												<input type="text" size="1" name="txtPriority<?=$i?>" id="txtPriority<?=$i?>" value="<?=$det71?>" />
												</td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<?php
													if($det51=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													?>
													<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$det11?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=delete&cid=".$det11?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										<tr>
											<td></td>
											<td></td>
											<td></td>											
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
								}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>