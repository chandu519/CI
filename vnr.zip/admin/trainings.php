<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="edu_trainings";
$pageHeading="Education Trainings";
$pageAdd="addtrainings.php";
$pageList="trainings.php";

/*********************** Delete ***************************/

if(@$_POST['butSubmit']=="Submit Priority"){
	$res=mysqli_query($mysqli,"select * from edu_trainings");
	while($row=mysqli_fetch_array($res)){
		if(@$_POST['txtLink'.$row['inc_prod_id']] == 1){
			$post_link = 1;
		}else{
			$post_link = 0;
		}
		mysqli_query($mysqli,"update edu_trainings set priority='".@$_POST['txtPri'.$row['inc_prod_id']]."',link=$post_link where inc_prod_id='".$row['inc_prod_id']."'");
	}
}




?>
<?php
	
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	
	if(@$_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select inc_prod_id from edu_trainings where inc_prod_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
			
				$stmt->bind_result($inc_prod_id);
				$stmt->fetch();				
				$sq="update edu_trainings set stat=? where inc_prod_id=?";
				if ($stm = $mysqli->prepare($sq)){
					$ii='ss';
					$stm->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stm->execute();					
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";						
					}else{
						$_SESSION['stat']="FE";					
					}
					$allClasses->forRedirect ("viewtrainings.php");
					exit;
				}
			}
		}
	}
}


if(@$_REQUEST['act'] == "del" && is_numeric($_REQUEST['inc_prod_id'])){
	$query1="select inc_prod_id,prod_image from edu_trainings where inc_prod_id=".$_REQUEST['inc_prod_id'];
	$res=mysqli_query($mysqli,$query1);
	if(mysqli_num_rows($res)>0){
	    $rowdel=mysqli_fetch_assoc($res);
	
			$query = "delete from edu_trainings where inc_prod_id=".$_REQUEST['inc_prod_id'];			
			$result = mysqli_query($mysqli,$query);
			
			$error = mysqli_error($mysqli);
		
			if($error == ""){
				if($rowdel['prod_image']!=""){
			    	unlink(ROOT_IMG_PATH.$rowdel['prod_image']);
					//unlink(ROOT_DOC_PATH.$rowdel['prod_inner_img']);
				}
				$msg = '<div align="center" class="redtext2">Record has been removed successfully.</div>';
			}else{
				$msg = '<div align="center" class="redtext2">Error: Unable to remove record. Please try again.</div>';
			}
	  }	
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>
	<style>
.level1{
	background-color:#F5FEFD;
	color:#000000;
	font-weight:700;
	 color: #71686a;
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 1px;
}
.level2{
	background-color:#FEF8F5;
	color:#855712;
	font-weight:500;
	
}
.level3{
	background-color:#FFFFFF;
	color:#436A0F;
	font-weight:500;
}
.level4{
	background-color:#F9F9F9;
	color:#1672B6;
	font-weight:700;
}

</style>					
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							                      
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												
												<th>S No</th>
												<th>Title</th>	
																					
												<th>Sort Order</th>											
																																																					
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php
	function getOptions($id,$level,$mysqli){
       
		$query = "select *,date_format(dt_created, '%d %M, %Y')as dt_created2 from edu_trainings where inc_cat_id='".$id."' order by priority asc";
		$result = mysqli_query($mysqli,$query);
		if(mysqli_num_rows($result)>0){
			$level=$level+1;
		}
		$t=1;	
		while($row = mysqli_fetch_assoc($result)){
			
			?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_prod_id']?>" />														
											
											<tr class="level<?=$level?>">
											<td class=""><?=$t?></td>
												<td align="left" ><a href="javascript:void(0)"><?php for($m=1;$m<=($level-1);$m++){ echo '&nbsp;&nbsp;&nbsp;'; } ?> <?=$t?> . &nbsp;  <?=$row['prod_title']?></a></td>												
															
												<td class="input_table">
												<input type="text" class="level<?=$level?> " name="txtPri<?=$row['inc_prod_id']?>" value="<?=$row['priority']?>" size="5"  />
										
												</td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<?php
													if($row['stat']=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													
													?>
													<a title="Click to <?=$title_label?>" href="viewtrainings.php?act=editSatus&id=<?=$row['inc_prod_id']?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=@$pageHeading?>" href="edittrainings.php?act=edit&inc_prod_id=<?=$row['inc_prod_id']?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&inc_prod_id=".$row['inc_prod_id']?>';return false;}" title="Remove <?=@$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php
			getOptions($row['inc_prod_id'],$level,$mysqli);
			$t++;
		}
		
	}
?>
	<?php
	getOptions('0',0,$mysqli);
?>		
										<input type="hidden" name="hidTotal" value="<?=$t?>">	
										<tr>
											<td></td>										
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
																
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>