<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_schedule_tax_notes";
$pageHeading="INTERVIEW PENDING";


?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
					<?php include "includes/ui_info_top.php"; ?>   
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	
					
							<?php 
							if(@$_REQUEST['file_no']!=""){
								$file_no=$_REQUEST['file_no'];
								$query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
								$res=mysqli_query($mysqli,$query);
								if(mysqli_num_rows($res)>0){ 
								
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>Date </th>
												<th> Time </th>	
												<th>Time Zone</th>											
																			
																
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['id']?>" />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><a href="javascript:void(0)"><?=$row['date']?></a></td>
												<td><a href="javascript:void(0)"><?=$row['time']?></a></td>		
												<td><a href="javascript:void(0)"><?=$row['time_zone']?></a></td>
												
											</tr>	
											<?php $i++;
										}
										?>			
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>