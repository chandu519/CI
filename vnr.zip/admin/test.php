<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
$(".tag-item").click(function() {
  var btnid = $(this).data("id");
  var btnname = $(this).data("name");
  $("#article-tags").append("<button type='button' class='tag-selected ntdelbutton'>" + btnname + " &nbsp;<i class='fa fa-times-circle' aria-hidden='true'></i></button>");
  $(this).css({
    "background-color": "#DFE2E5",
    "color": "#ababab"
  });
  $(this).attr("disabled", true);
  $(".ntdelbutton").click(function() {
    $(this).remove();
  });
});
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div id="article-tags">
</div>

<div>
  <button type="button" data-id="1" data-name="tag" class="tag-item">tag</button>
  <button type="button" data-id="2" data-name="tag2" class="tag-item"> tag2</button>
  <button type="button" data-id="3" data-name="tag3" class="tag-item">tag3</button>
  <button type="button" data-id="4" data-name="tag4" class="tag-item">tag4</button>
</div>