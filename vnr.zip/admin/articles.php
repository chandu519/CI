<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_articles";
$pageHeading="Articles";
$pageAdd="addarticles.php";
$pageList="articles.php";

/*********************** Add Banners ***************************/
if(@$_REQUEST['act']=="delete" && @$_REQUEST['cid']!=""){
$sql="delete from $tableName where inc_id='".$_REQUEST['cid']."'";
mysqli_query($mysqli,$sql);
$_SESSION['stat']="SD";
$allClasses->forRedirect ($pageList);
exit;
}

?>
<?php 
	if(@$_POST['butSubmit']=="Update"){
	for($k=1;$k<=$_POST['hidTotal'];$k++){
		$inc_id=@$_POST['hidID'.$k];
		//echo "update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'"; exit;
		mysqli_query($mysqli,"update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($pageList);
	exit;
}
	?>
<?php 
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select inc_id from $tableName where inc_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
				$sql="update $tableName set status=? where inc_id=?";
				if ($stmt = $mysqli->prepare($sql)){
					$ii='ss';
					$stmt->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stmt->execute();
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";
						$allClasses->forRedirect ($pageList);
						exit;
					}else{
						$_SESSION['stat']="FE";
						$allClasses->forRedirect ($pageList);
						exit;
					}
				}
			}
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>

<div class="wrapper table form_upload" style="margin-bottom:25px;">	
<form method="GET" class="wrapper" enctype="multipart/form-data">
<div class="rowLess" style="">
	
	<div class="width10">
		<h2>Journals :</h2>
	</div>
	<div class="width25">
		<select  name="jid" id="" >
		<option value="">Select</option>
		<?php 
		$sql="select journals_id,title from tbl_journals where status=1 order by priority asc";
		$res=mysqli_query($mysqli,$sql);
		while($row=mysqli_fetch_array($res)){
		?>
		<option value="<?=$row['journals_id']?>" <?php if(@$_REQUEST['jid']==$row['journals_id']){echo 'selected';}?>><?=$row['title']?> </option>
									<?php } ?>
	</select>
	</div>
	
	<div class="width25 ga_btn ">
		<input type="submit" name="submit"  value="Search" class="fbtn">
	</div>
</div>
</form>
</div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						
						
						
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							<?php 
							if(@$_REQUEST['jid']!=""){
								@$sq= "where journals_id='".$_REQUEST['jid']."'";
							}
							if ($cat1 = $mysqli->prepare("select inc_id,article,recived_date,title,author_name,author_email,priority,status from $tableName ".@$sq." order by priority asc ")) 
								{
									$cat1->execute();
									$cat1->store_result();
									if($cat1->num_rows>0){
										$cat1->bind_result($det11,$det21,$det31,$det41,$det81,$det61,$det71,$det51);
					
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>S no</th>
												<th>Article</th>
												<th>Title</th>
												<th>Author</th>
												<th>Priority</th>																		
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($cat1->fetch()){
									?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>"  />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$det21?></td>
												<td><?=$det41?></td>
												<td><?=$det81?></td>
												<td>
												<input type="text" size="1" name="txtPriority<?=$i?>" id="txtPriority<?=$i?>" value="<?=$det71?>" />
												</td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">	
													<?php
													if($det51=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													?>
													<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$det11?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=delete&cid=".$det11?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										<tr>
											<td></td>
											<td></td>
											<td></td>	
											<td></td>											
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
								}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>