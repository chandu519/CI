<?php include_once "includes/config.php"; 
	  include_once "includes/loginAuth.php"; 

	 include_once "includes/model.php";  
if(!empty($_POST)){
	echo "<pre>";
	print_r($_POST);exit;
}
	
	
	$date = ($_REQUEST['date'] != '') ? $_REQUEST['date'] : date('Y-m-d');
	$priceData = getDayWisePricing($date);
?>

<!doctype html>
<html>
	<head>

		<style type="text/css">
			.address{
				float: left;
			    width: 100%;
			    
			    border: 1px solid #ddd;
			    border-radius: 3px;
			    padding: 8px 10px;
			    font-size: 16px;
			    color: #333;
			    margin-bottom: 15px;
			}
			.addBtn{ padding: 3px 8px; background:green; color: #fff; border:0px; height: 35px; line-height: 25px; cursor: pointer;  }
			.removeBtn{
				padding: 3px 8px; background:#ff0000; color: #fff; border:0px; height: 35px; line-height: 25px; cursor: pointer;
			}
		</style>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1>Invoice</h1>                       
                    </div>

						<?php 
						if(isSet($_SESSION['stat'])){
						?>										
						<?php 
						if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
							$error_msg="";
						}
						if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
							$error_msg="error_msg";	
						}
						?>
						<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
						<?php 
							unset($_SESSION['stat']);
						}
						?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" name="invoiceForm" id="invoiceForm" class="form" enctype="multipart/form-data" method="post" class="wrapper">
								

								<input type="hidden" name="gold_price" id="gold_price" value="<?php echo $priceData[0]['gold']; ?>">
								<input type="hidden" name="silver_price" id="silver_price" value="<?php echo $priceData[0]['silver']; ?>">

								<div style="background:#f9f9f9; width: 100%; float:left; padding: 10px;">
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"><h3> Contact Info</h3></label>
									</div>
								</div>
								<div class="rowLess" >
									<div class="width25">
										<input type="text" name="name" id="name" value="" placeholder="Enter Name">
									</div>
									<div class="width25">
										<input type="text" name="email" id="email" value="" placeholder="Enter Email">
									</div>
									<div class="width25">
										<input type="text" name="phone" id="phone" value="" placeholder="Enter Phone">
									</div>
									<div class="width25">
										<textarea name="address" id="address" class="address" placeholder="Enter Address"></textarea>	
									</div>
																	
								</div>
								</div>
								

								<div style="background:#e5e5e5; width: 100%; float:left; padding: 10px;">
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"><h2>  Add Products</h2></label>
									</div>
								</div>
								
								<div class="prodlist">
									
								
									
								<div class="rowLess">
									<div class="width25">
										<!-- <input type="text" name="prod_name[]" value="" placeholder="Product Name"> -->
										<select name="prod_name[]" >
											<optgroup label="Gold">
												<option value="1">100gr</option>
												<option value="2">200gr</option>
												<option value="3">300gr</option>
											</optgroup>
											<optgroup label="Silver">
												<option value="4">100gr</option>
												<option value="5">200gr</option>
												<option value="6">300gr</option>
											</optgroup>
										</select>
									</div>
									<div class="width10">
										<input type="text" name="weight[]" value="" placeholder="Weight">
									</div>
									<div class="width10">
										<input type="text" name="qty[]" value="" placeholder="Quantity">
									</div>
									<div class="width10">
										<input type="text" name="mkg_chrgs[]" value="" placeholder="Making Charges">
									</div>
									<div class="width10">
										<input type="text" name="stone_wgt[]" value="" placeholder="Stone Weight">
									</div>
									<div class="width20">
										<input type="text" name="prod_tot_price[]" value="" placeholder="Total Price">
									</div>

									<div class="width10">
										<button type="button" class="addBtn"> + </button>
									</div>									
								</div>
								
								</div>
								</div>
									<div style="background:#f9f9f9; width: 100%; float:left; padding: 10px;">
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"><b>  Old Item</b></label>
									</div>
								</div>
								<div class="rowLess" >
									<div class="width25">
										<input type="text" name="txtini_pro_ino" id="" value="" placeholder="Product Name">
									</div>
									<div class="width10">
										<input type="text" name="txtini_pro_date" id="txtini_pro_date" value="" placeholder="Weihgt">
									</div>
									<div class="width10">
										<input type="text" name="txtini_pro_month" id="" value="" placeholder="Quantity">
									</div>
									<div class="width25">
										<input type="text" name="txtini_pro_year" id="" value="" placeholder="Making Changes">
									</div>
									<div class="width10">
										<input type="text" name="txtini_pro_year" id="" value="" placeholder="Stone Weight">
									</div>
									<div class="width20">
										<input type="text" name="txtini_pro_year" id="" value="" placeholder="Total Price">
									</div>									
								</div>
							</div>
								

									<div style="background:#f9f9f9; width: 100%; float:left; padding: 10px;">

								<div class="wrapper" style="margin-top:25px;">
									<div class="width70" style="float: left;">
										
									</div>

									<div class="width30" style="float: right;">
									<div class="flabel">
										<label for="folder"> Total Amount</label>
									</div>
									<div class="finput">	
									<input name="tot_amount" id="tot_amount" type="text"  class="" id="tot_amount" required readonly >
									</div>
									</div>
								</div>
								
								
								<div class="wrapper" style="">
									<div class="width70" style="float: left;">
										
									</div>


									<div class="width30" style="float: right;">
									<div class="flabel">
										<label for="folder"> Paid Amount</label>
									</div>
									<div class="finput">	
									<input name="paid_amount" id="paid_amount" type="text" value="<?=@$det6?>" class="" id="paid_amount">
									</div>
								</div>
								</div>
								
								<div class="wrapper" style="">

									<div class="width70" style="float: left;">
										
									</div>

									<div class="width30" style="float: right;">
									<div class="flabel">
										<label for="folder"> Due Amount </label>
									</div>
									<div class="finput">	
									<input name="due_amount" id="due_amount" type="text" value="<?=@$det7?>" class="" id="due_amount" readonly>
									</div>
									</div>
								</div>
								</div>
								<div class="wrapper" >
									<div class="flabel">&nbsp;</div>
									<div class="finput" >
										<input type="submit" name="addInvice" value="Submit" class="fbtn" style="float:right;">
									</div>
								</div>
							</form>
						</div>    
						
				
				</div>
			</div>
    </div>		
    

						<?php include_once "includes/ui_footer.php"; ?>  

	</body>
<!-- 
<select name="prod_name[]" ><optgroup label="Gold"><option value="1">100gr</option><option value="2">200gr</option><option value="3">300gr</option></optgroup><optgroup label="Silver"><option value="4">100gr</option><option value="5">200gr</option><option value="6">300gr</option></optgroup></select> -->
	<script type="text/javascript">
		$(document).ready(function (){
			$(".addBtn").click(function(){
				$(".prodlist").append('<div class="rowLess"><div class="width25"><select name="prod_name[]" ><optgroup label="Gold"><option value="1">100gr</option><option value="2">200gr</option><option value="3">300gr</option></optgroup><optgroup label="Silver"><option value="4">100gr</option><option value="5">200gr</option><option value="6">300gr</option></optgroup></select></div><div class="width10"><input type="text" name="weight[]" value="" placeholder="Weight"></div><div class="width10"><input type="text" name="qty[]" value="" placeholder="Quantity"></div><div class="width10"><input type="text" name="mkg_chrgs[]" value="" placeholder="Making Charges"></div><div class="width10"><input type="text" name="stone_wgt[]" value="" placeholder="Stone Weight"></div><div class="width20"><input type="text" name="prod_tot_price[]" value="" placeholder="Total Price"></div><div class="width10"><button type="button" class="removeBtn">-</button></div></div>')
			});

			$(document).on('click', '.removeBtn', function(e) {
				$(this).parent().parent().remove();
			});


			$(".fbtn").click(function(){
				event.preventDefault();
		        var lngtxt = $('input[name="weight[]"]').length;
		        var errCount = 0;
		        if (lngtxt == 0) {
		            errCount++;
		        } else {
		        	var prodErr = weightErr = qtyErr = mkgChrgsErr = stnWgtErr = totPrcErr = 0;
		        	var prodData = document.getElementsByName('prod_name[]');
		        	var weightData = document.getElementsByName('weight[]');
		        	var qtyData = document.getElementsByName('qty[]');
		        	var mkgChrgsData = document.getElementsByName('mkg_chrgs[]');
		        	var stnWgtData = document.getElementsByName('stone_wgt[]');
		        	var totPrcData = document.getElementsByName('prod_tot_price[]');

		        	if($("#name").val()==""|| $("#email").val()=="" ||$("#phone").val()==""||$("#address").val()=="" || $("#tot_amount").val()==""|| $("#paid_amount").val()==""|| $("#due_amount").val()=="")
		        		 errCount++;

			        for (let i = 0; i < weightData.length; i++) {
			            
			        	if(prodData[i].value == '' || prodData[i].value == undefined || prodData[i].value == null )
			            	prodErr++;

			            if(weightData[i].value == '' || weightData[i].value == undefined || weightData[i].value == null )
			            	weightErr++;

						if(qtyData[i].value == '' || qtyData[i].value == undefined || qtyData[i].value == null )
			            	qtyErr++;

						if(mkgChrgsData[i].value == '' || mkgChrgsData[i].value == undefined || mkgChrgsData[i].value == null )
			            	mkgChrgsErr++;

			            if(totPrcData[i].value == '' || totPrcData[i].value == undefined || totPrcData[i].value == null )
			            	totPrcErr++;

						if(stnWgtData[i].value == '' || stnWgtData[i].value == undefined || stnWgtData[i].value == null )
			            	stnWgtErr++;				            				            	            
			        }		         	
		        }  

		        if(errCount > 0){
			        alert("Enter required fields to continue");
			        return false;
		        }else if(prodErr > 0){
		        	alert("Enter all Product fields");
		          	return false;	
		        }else if(weightErr > 0){
		        	alert("Enter all weights");
		          	return false;	
		        }else if(qtyErr > 0){
		        	alert("Enter all Quantity");
		          	return false;	
		        }else if(mkgChrgsErr > 0){
		        	alert("Enter all Making Charges");
		          	return false;	
		        }else if(stnWgtErr > 0){
		        	alert("Enter all Stone Weight fields");
		          	return false;	
		        }else if(totPrcErr > 0){
		        	alert("Error with Total Product price fields ");
		          	return false;	
		        }else{
		        	$("#invoiceForm").submit();
		        }

						        
      
			})
		})

	</script>


	
</html>