<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_other_links";
$pageHeading=" Contact Us";
$pageList="contactDetails.php";

/*********************** Add Banners ***************************/
$pageHeading="Contact Details";
if(isset($_POST["updateContact"]) && $_POST["updateContact"]=="Save"){
	
    $id=0;
	$mail=$_POST['txtMail'];
	$phone=$_POST['txtPhone'];
	$facebook=$_POST['txtFace'];
	$addr=$_POST['txtAddr'];
	$linked=$_POST['txtLinked'];
	$twitter=$_POST['txtTwitter'];
	$gplus=$_POST['txtgoogle'];
	$youtube=$_POST['txtYT'];
	$dt_created=$_POST['txtMap'];
	$web=$_POST['txtWeb'];
	
	if($_POST['hid_action']=="editcat" && $_POST['hid_contact_id']!=""){
	
		$sql="update tbl_other_links set mail =?,phone =?,face=?,linked=?,twitter=?,youtube=?,google_plus=?,addr=?,dt_created=?,web=? where cid=?";
		
		if ($stmt = $mysqli->prepare($sql)){
			$bind='ssssssssssi';
			$stmt->bind_param($bind,$mail,$phone,$facebook,$linked,$twitter,$youtube,$gplus,$addr,$dt_created,$web,$_POST['hid_contact_id']);
			$flag=$stmt->execute();
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;  exit;
			if($flag){
				$_SESSION['stat']="SE";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FE";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
		<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									$cid=777;
								if ($cat = $mysqli->prepare("select * from tbl_other_links where cid =?")) {
										//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($cid,$mail,$phone,$facebook,$linked,$twitter,$youtube,$google_plus,$addr,$web,$dt_created);
											$cat->fetch();
											
											echo '<input type="hidden" name="hid_contact_id" value="'.$cid.'" />';
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Admin Mail</label>
									</div>
									<div class="finput">
											<input name="txtMail" type="text" value="<?=$mail?>" class="" id="txtMail" >
													
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Mail 2</label>
									</div>
									<div class="finput">
										<input name="txtgoogle" type="text" value="<?=$google_plus?>" class="form-control" id="txtgoogle" >			
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Us Mobile</label>
									</div>
									<div class="finput">
									<input name="txtPhone" type="text" value="<?=$phone?>" class="" id="txtPhone" >
										
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">India Mobile </label>
									</div>
									<div class="finput">
									<input name="txtWeb" type="text" value="<?=$web?>" class="" id="txtWeb" >
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Whats App</label>
									</div>
									<div class="finput">
									<input name="txtYT" type="text" value="<?=$youtube?>" class="form-control" id="txtYT" >
									
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Facebook</label>
									</div>
									<div class="finput">
									<input name="txtFace" type="text" value="<?=$facebook?>" class="form-control" id="txtFace" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Twitter</label>
									</div>
									<div class="finput">
									<input name="txtTwitter" type="text" value="<?=$twitter?>" class="form-control" id="txtTwitter" ></div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> LinkedIn</label>
									</div>
									<div class="finput">
									<input name="txtLinked" type="text" value="<?=$linked?>" class="form-control" id="txtLinked" >
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Google Map</label>
									</div>
									<div class="finput">
									<input name="txtMap" type="text" class="form-control" id="txtMap" value="<?=$dt_created?>">
									</div>
								</div>	
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Address</label>
									</div>
									<div class="finput">
									<textarea class="" style="" name="txtAddr" id="txtAddr" ><?=$addr?></textarea>
									</div>
								</div>						
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="updateContact" value="Save" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>