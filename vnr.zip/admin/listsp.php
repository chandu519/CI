<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$_REQUEST['id']=base64_decode($_REQUEST['id']);
$tableName="tbl_user_tax_process";
$pageHeading=$process_status[$_REQUEST['id']];
$pageAdd="adduser.php";
$pageList="list.php";

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	

					<!--	<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>	-->					
							<?php 
						 $rid=$_REQUEST['id'];
							 $query = "SELECT * FROM $tableName where status='".$rid."' and dt_created!='' ORDER BY file_no DESC";
							 $res=mysqli_query($mysqli,$query);	
							if(mysqli_num_rows($res)>0){ 
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>File No </th>
												<th>Name</th>
												<th>Email</th>		
												<th>Mobile</th>		
												<th>File Process</th>													
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											
											?>
											
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><a href="javascript:void(0)"><?=$row['file_no']?></a></td>	
										<?php 
										$query1 = "SELECT * FROM tbl_users where file_no='".$row['file_no']."'";
										$res1=mysqli_query($mysqli,$query1);
										$row1 = mysqli_fetch_array($res1);
										
												?>												
												<td><?=$row1['name']?></td>
												<td><?=$row1['email']?></td>
												<td><?=$row1['phone']?></td>
										
												
										
											<td><?=$process_status[$rid]?></td>
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<a href="viewDetails.php?file_no=<?=$row['file_no']?>" >View Details</a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
						}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>