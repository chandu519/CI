<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_aproofarticles";
$pageHeading="Author Proofed Articles";
$pageAdd="aproofArticles.php";
$pageList="aproofArticles.php";

if(isset($_POST["butSubmit"]) && $_POST["butSubmit"]=="Submit"){
	$txtCurecases = $_POST['txtCurecases1'];
	$cat = $_REQUEST['id'];
	if($txtCurecases >0){
		for($i=1;$i<=$txtCurecases;$i++){
			$title = $_POST['txtTitle'.$i];	
			if($_FILES['txtImage'.$i]['name'] != ""){
				$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage'.$i);			
				if($result){
					$imgName = $result;
					//$result = $allClasses->resizeImage(SITEDOC_ROOT_PATH."images/".$imgName,104,58,SITEDOC_ROOT_PATH."images/product_thumbs/".$imgName);
				}
				$image = $imgName;
				$sql="insert into tbl_aproofarticles(prop_id,title,image,date_created)values(?,?,?,now())";
				if($stmt = $mysqli->prepare($sql)){
					$s='sss';
					$stmt->bind_param($s,$cat,$title,$image);
					$flag=$stmt->execute();
					if($flag){
						$_SESSION['stat']= "SA";
					}else{
						$_SESSION['stat']= "FA";
					}
				}
			}else{
				$_SESSION['stat']= "ND";
			}
		}
	}else{
		$_SESSION['stat']= "ND";
	}
	$allClasses->forRedirect ($current_page); exit;
}

/*********************** Delete ***************************/
if(@$_REQUEST['act'] == 'del' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	
	if($stmt1 = $mysqli->prepare("select inc_img_id,image from $tableName where inc_img_id=?")) {
		$stmt1->bind_param('i', $id);
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($inc_cat_id,$image);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
			if($image!=""){
				unlink(SITEDOC_ROOT_PATH."images/".$image);
			}
			$sql="delete from $tableName where inc_img_id =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='i';
				$stmt->bind_param($s, $id);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}
				$allClasses->forRedirect ('aproofArticles.php');
				exit;
			}
		}	
	}
}

/*********************** Sort / Priority ***************************/
if(@$_POST['butSubmit']=="Update"){
	//echo 'hii';exit;
		for($k=1;$k<=$_POST['hidTotal'];$k++){
			$inc_id=@$_POST['hidID'.$k];
			$txtTitle=@$_POST['txtTitle'.$k];
			mysqli_query($mysqli,"update $tableName set title='".$txtTitle."' where inc_img_id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($current_page);
	exit;
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>
<script>
function validate(){
   
	if(document.frmCase.txtCurecases1.value >0){ 
		
		for(i=1;i<=document.frmCase.txtCurecases1.value;i++){
			img = document.getElementById('txtImage'+i).value;
		if(img == ""){
			alert("image should not be empty.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
		
		var lpos = img.lastIndexOf('.');
		ext = img.substr(lpos+1);
		ext = ext.toLowerCase();
		if(ext != "jpeg" & ext !='gif' & ext !='png' & ext !='jpg'){
			alert("Please select a jpeg or jpg or gif or png image.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
			
		}
	}
return true;
}	
var vldnum=/^[0-9]+$/;
var i =0;	
function displayChildInfo(caseimages){
	
var txtImageDetails = "";
match=vldnum.test(caseimages);
if(!match){	  
alert("Enter numbers only.");
return false;
}else{
if(caseimages >0){
	txtImageDetails ='<div class="wrapper table form_upload"><div class="wrapper"><form action="" name="frmCase" method="POST" class="wrapper" onSubmit="return validate();" enctype="multipart/form-data"><input type="hidden" name="txtCurecases1" id="txtCurecases1" value='+caseimages+'><div class="form-body"><div class="row">';
	for(i=1;i<=caseimages;i++){
		txtImageDetails += '<div class="wrapper"><div class="flabel"><label for="folder">Title'+i+'</label></div><div class="finput"><input type="text" class="" name="txtTitle'+i+'" id="txtTitle'+i+'"></div></div><div class="wrapper"><div class="flabel"><label for="folder">Img'+i+'</label></div><div class="finput"><input type="file" class="" placeholder="12n" name="txtImage'+i+'" id="txtImage'+i+'"><small class="form-control-feedback">W x H:100 x 100</small></div></div>';		
	}
	txtImageDetails +='</div></div><input type="submit" name="butSubmit" class="fbtn" value="Submit"> </form></div></div>';
}else{
	document.getElementById('divImageInfo').innerHTML = '';
}
}
if(txtImageDetails != ""){
document.getElementById('divImageInfo').innerHTML = txtImageDetails;
}
}			
	</script>
	<script language="javascript" type="text/javascript">
function go(id){
		window.location = 'aproofArticles.php?id='+id;
}
</script>		
	</head>
	
	<body>
		<?php include_once "includes/ui_header.php"; ?>
		<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Title</label>
									</div>
									<div class="finput">
									<select name="txtCat" id="txtCat" class="" style="width:100%;" onChange="return go(this.value);">
							<option value="">-Select Article-</option>
									<?php 
									$sql="select inc_id,journals_id,article from tbl_articles where status=1 order by priority asc";
									$res=mysqli_query($mysqli,$sql);
									while($row=mysqli_fetch_array($res)){
										
									?>
									<option value="<?=$row['inc_id']?>" <?php if(@$_REQUEST['id']==$row['inc_id']){echo 'selected';}?>><?=$row['article']?> </option>
									<?php } ?>
							
							
						</select>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> No Of Images</label>
									</div>
									<div class="finput">
											<input class="" name="txtCurecases" type="text" id="txtCurecases" size="3" maxlength="2" value="0" onKeyUp="displayChildInfo(this.value)" />
														<small class="form-control-feedback"> Enter Only 1 images you can upload </small>
									</div>
								</div>
															
								<div class="wrapper">
									<div class="finput">										
									<div id="divImageInfo"></div>
									</div>
								</div>
															
								
							</form>
						</div>    
						<div class="flabel">&nbsp;</div>
						
					

<?php 
if(@$_REQUEST['id']!=""){
	$id=$_REQUEST['id'];
 $query = "SELECT inc_img_id,title,image,date_created,date_last_updated FROM $tableName where prop_id='$id' ORDER BY inc_img_id DESC";
$res=mysqli_query($mysqli,$query);	
if(mysqli_num_rows($res)>0){ $i=1;
?>					<div class="wrapper table form_upload">	
			<div class="wrapper title">
                        <h1>Uploded Images</h1>
                       
                    </div>	
				<div id="tableWrap">
				
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>Image Name</th>	
												<th>File</th>							
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
											while($row = mysqli_fetch_array($res)){  
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_img_id']?>"  />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><div class="wrapper" ><div class="finput" style="width:100%;"><input type="text" class="" name="txtTitle<?=$i?>" id="txtTitle<?=$i?>" value="<?=$row['title']?>"></div></div></td>												
												<td><a href="<?=SITE_PATH?>../images/<?=$row['image']?>" target="_blank">View FIle</a></td>		
												
												<td class="button-list">
													<div class="btn-group btn-group-justified">		
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['inc_img_id']."&img=".$row['image']?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden"  name="hidTotal" value="<?=$i?>" />	
										<tr>
											<td></td>
																			
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
				</div>
<?php } ?>				
				<!-- End PAge Content -->
	<?php 
}
?>		

		
						
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>