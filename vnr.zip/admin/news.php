<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 


//Table & Page Details
$tableName="tbl_news";
$pageHeading="News";
$pageAdd="addnews.php";
$pageList="news.php";

/*********************** Add Banners ***************************/
if(isset($_POST["addBanner"]) && $_POST["addBanner"]=="Save"){

	$txtName=$_POST['txtName'];
	$txtLink=$_POST['txtLink'];
	$txtContent=$_POST['txtContent'];
	
	if($_FILES['txtImage1']['name'] != ""){
	
		$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage1');
		
		if($result){
			$imgName = $result;
			if(@$_POST['hid_image']!= ""){
				unlink(SITEDOC_ROOT_PATH."images/".$_POST['hid_image']);
			}
		}
	}else{
		$imgName = $_POST['hid_image'];
	}
	
		if(@$_POST['hid_action']=="edit" && $_POST['hid_id']!=""){
	
		$stmt_1 = $mysqli->prepare("update $tableName set title=?,content=?,link=?,curl=? where image=1 and inc_cat_id=?");
		$stmt_1->bind_param("sssss",$txtName,$txtContent,$txtLink,$imgName,$_POST['hid_id']);							
		$flag_1=$stmt_1->execute();			
		$_SESSION['stat']="SE";
		$link=$_POST['hid_id']; 
		}
		
		$sql1="insert into $tableName(title,link,content,image,status,priority,dt_created)values(?,?,?,'0','1','1',now())";
		$stmt = $mysqli->prepare($sql1);
		//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			
		$allClasses->forRedirect ($pageList);
		exit;
		
	
	
	 
}

if(@$_REQUEST['act']=="delete" && @$_REQUEST['cid']!=""){
$sql="delete from $tableName where inc_cat_id='".$_REQUEST['cid']."'";
mysqli_query($mysqli,$sql);
$_SESSION['stat']="SD";
$allClasses->forRedirect ($pageList);
exit;
}
if(@$_REQUEST['act'] == 'del1' &&  is_numeric($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	$img=$_REQUEST['img'];
	unlink(SITEDOC_ROOT_PATH."images/".$img);
	$flag=mysqli_query($mysqli,"update $tableName set content='' where inc_cat_id=1");
	if($flag){
		$_SESSION['stat']="SD";		
	}else{
		$_SESSION['stat']="FD";
	}
	$allClasses->forRedirect ($pageList);
	exit;
}
?>
<?php 
	if(@$_POST['butSubmit']=="Update"){
	for($k=1;$k<=$_POST['hidTotal'];$k++){
		$inc_id=@$_POST['hidID'.$k];
		//echo "update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'"; exit;
		mysqli_query($mysqli,"update $tableName set priority='".@$_POST['txtPriority'.$k]."' where inc_cat_id='".$inc_id."'");
	}
	$_SESSION['stat']="SE";
	$allClasses->forRedirect ($pageList);
	exit;
}
	?>
<?php 
if(@$_REQUEST['act']=="editSatus" && $_REQUEST['id']!="" ){
	if(@ $_REQUEST['changeStatus']=="1" || @$_REQUEST['changeStatus']=="0" ){
		$sql="select inc_cat_id from $tableName where inc_cat_id=?";
		if ($stmt = $mysqli->prepare($sql)){
			$i='i';
			$stmt->bind_param($i,$_REQUEST['id']);
			$flag=$stmt->execute();
			$stmt->store_result();
			if($stmt->num_rows>0){
				$sql="update $tableName set status=? where inc_cat_id=?";
				if ($stmt = $mysqli->prepare($sql)){
					$ii='ss';
					$stmt->bind_param($ii,$_REQUEST['changeStatus'],$_REQUEST['id']);
					$flag=$stmt->execute();
					//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
					if($flag){
						$_SESSION['stat']="SE";
						$allClasses->forRedirect ($pageList);
						exit;
					}else{
						$_SESSION['stat']="FE";
						$allClasses->forRedirect ($pageList);
						exit;
					}
				}
			}
		}
	}
}
?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						
						
						
						<div class="wrapper table">	

						<div class="wrapper">
							<a href="<?=$pageAdd?>" class="addNew">Add New</a>
						</div>						
							<?php 
							if ($cat1 = $mysqli->prepare("select inc_cat_id,title,link,content,status,image,priority from $tableName  order by priority asc ")) 
			{
				$cat1->execute();
				$cat1->store_result();
				if($cat1->num_rows>0){
					$cat1->bind_result($det11,$det21,$det31,$det41,$det51,$det61,$det71);
					
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>S no</th>
												<th>Name</th>
												<th>Link</th>
												<th>Priority</th>																																									
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
											while($cat1->fetch()){
									?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>"  />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$det21?></td>
												<td><?=$det31?></td>
												<td>
												<input type="text" size="1" name="txtPriority<?=$i?>" id="txtPriority<?=$i?>" value="<?=$det71?>" />
												</td>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">														
													<?php
													if($det51=='1'){
														$active_label="";
														$title_label="inactive";
														$btn_label="dark";
														$stat="0";
													}else{
														$active_label="-o";	
														$title_label="active";
														$btn_label="success";
														$stat="1";
													}
													?>
													<a title="Click to <?=$title_label?>" href="<?=$pageList?>?act=editSatus&id=<?=$det11?>&changeStatus=<?=$stat?>" ><i class="fa fa-check-circle<?=$active_label?>"></i></a>														
													<a class="editBranch" title="Edit <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$det11?>"><i class="fa fa-pencil-square-o"></i></a>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=delete&cid=".$det11?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										<tr>
											<td></td>
											<td></td>
											<td></td>											
											<td class="input_table">
												<input type="submit" class="addNew" name="butSubmit" value="Update" />
											</td>                                                														
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
								}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>