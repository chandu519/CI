<?php include_once "includes/config.php"; 
extract($_POST);
if(isset($btnUpdateProfile) && $btnUpdateProfile=='Update'){
	if(trim($txtPass)!=''){
		if(trim($txtPass) == trim($txtPassC)){
			$stmt = $mysqli->prepare("UPDATE tbl_admin_users SET password=?,modified_by=?,dt_modified=now() WHERE name=?");
			$stmt->bind_param('sss', $txtPass, $_SESSION['admin_id'], $_SESSION['admin_id']);
			$flag=$stmt->execute();
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			if($flag){			 
				$_SESSION['stat']="SE";		
			}else{
				$_SESSION['stat']="FE";		
			}
		}else{
			$_SESSION['stat']="FE";		
		}
	}else{
		$_SESSION['stat']="FE";		
	}
	$allClasses->forRedirect ("changePassword.php");
	exit;
}
?>
<!doctype html>
<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE7">
	<meta http-equiv="X-UA-Compatible" content="IE=9" />
	<meta http-equiv="X-UA-Compatible" content="chrome=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="ico/png" href="images/favicon.png" type="image/icon">
	<!--[if lte IE 8]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<!--[if lt IE 9]>
	<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js&quot; type="text/javascript"></script>
	<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/ie7-squish.js&quot; type="text/javascript"></script>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js&quot; type="text/javascript"></script>
	<![endif]-->
	<!--[if IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" />
	<![endif]-->
	<title>Profile</title>
	<!--<meta name="description" content="<?=@$seo_desc?>"/>
	<meta name="keywords" content="<?=@$seo_keywords?>"/>-->
	<link href="stylesheets/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="stylesheets/anim.css" rel="stylesheet">
	<link href="stylesheets/style.css" rel="stylesheet" type="text/css">
	</head>
<body>

	<?php include_once "includes/ui_header.php"; ?>
 
	<div class="wrapper content_box">
        <div class="wrapper_inner">
            <div class="wrapper">
                <div class="content_block">
                    <div class="wrapper title">
						<h1>Edit Profile</h1>
						<ul class="braeds">
							<li><a href="home.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
							<li><a>My Profile</a></li>
						</ul>
                    </div>
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>			 
					<div class="wrapper table form_upload">
						<form action="" method="POST" class="wrapper">
							 
							<div class="wrapper">
								<div class="flabel">
									<label for="fname">New Password *</label>
								</div>
								<div class="finput">
									<input type="password" id="txtPass" name="txtPass" required>
								</div>
							</div>	
							<div class="wrapper">
								<div class="flabel">
									<label for="fname">Confirm Password *</label>
								</div>
								<div class="finput">
									<input type="password" id="txtPassC" name="txtPassC" required>
								</div>
							</div>								 
							
							<div class="wrapper">
								<div class="flabel">&nbsp;</div>
								<div class="finput">
									<input type="submit" name="btnUpdateProfile" value="Update" class="fbtn">
								</div>
							</div>
						</form>
					</div>
				</div> 
			</div>
		</div>
    </div>
	
	<?php include_once "includes/ui_footer.php"; ?>  

	<a href="javascript:void(0)" class="scrollup"><i class="fa fa-angle-up"></i></a>
	<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
	<script src="js/scripts.js" type="text/javascript"></script>
	<script src="js/jquery.validate.min.js"></script>  
</body>
</html>