<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_users";
$pageHeading="Members List";
$pageAdd="adduser.php";
$pageList="list_allocated.php";



if(@$_REQUEST['act'] == 'del'){
	$id=$_REQUEST['id'];
	
	if($stmt1 = $mysqli->prepare("SELECT inc_id,file_no FROM $tableName WHERE file_no='".$id."'")) {
		$stmt1->execute();
		$stmt1->store_result();
		$stmt1->bind_result($inc_id,$file_no);
		$stmt1->fetch();
		if($stmt1->num_rows>0){
			$sql="DELETE FROM $tableName WHERE file_no =?";
			if ($stmt = $mysqli->prepare($sql)){
				$s='s';
				$stmt->bind_param($s, $file_no);
				//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
				$flag=$stmt->execute();
				$ui = "DELETE  FROM tbl_user_info where file_no='".$file_no."' ";
				$uires=mysqli_query($mysqli,$ui);
				
				$sp = "DELETE  FROM tbl_user_spouse_info where file_no='".$file_no."' ";
				$spres=mysqli_query($mysqli,$sp);
				
				$di = "DELETE  FROM tbl_user_dependent_info where file_no='".$file_no."' ";
				$dires=mysqli_query($mysqli,$di);
				
				$d = "DELETE  FROM tbl_user_docs where file_no='".$file_no."' ";
				$dres=mysqli_query($mysqli,$d);
				
				$l = "DELETE  FROM tbl_user_logs where file_no='".$file_no."' ";
				$lres=mysqli_query($mysqli,$l);
				
				$tp = "DELETE  FROM tbl_user_tax_process where file_no='".$file_no."' ";
				$tpes=mysqli_query($mysqli,$tp);
				
				$ts = "DELETE  FROM tbl_tax_summary where file_no='".$file_no."' ";
				$tses=mysqli_query($mysqli,$ts);
				
				$rs = "DELETE  FROM tbl_user_referals where file_no='".$file_no."' ";
				$rses=mysqli_query($mysqli,$rs);
				
				
				if($flag){					
					$_SESSION['stat']="SD";					
				}else{
					$_SESSION['stat']="FD";
				}				
			}
		}	else{
			$_SESSION['stat']="NDE";					
		}
		$allClasses->forRedirect ('list_allocated.php'); exit;
	}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table form_upload">	
				<form name="" action="DownloadExcel.php" method="post" class="wrapper">
						<div class="wrapper">
						<div class="finput" >	
						<input type="submit" name="Excel_Download" value="Download Excel" class="fbtn" style="float: right;width: 20%; height: 42px; 
    margin-bottom: 25px; border-radius:3px; background: #2e6892; color: #fff;">
							<!--<a href="DownloadExcel.php" class="addNew">Download Excel</a>-->
							</div>		
						</div>	
						</form>
							
							<?php 
							$_REQUEST['mid']=1;
							if(@$_REQUEST['mid']!=""){
								$sq="where old_new_flag='".$_REQUEST['mid']."'";
							}
						 $query = "SELECT * FROM $tableName ".@$sq." ORDER BY file_no DESC";
							$res=mysqli_query($mysqli,$query);	
							if(mysqli_num_rows($res)>0){ 
									
							
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>File No </th>
												<th>Name</th>
												<th>Email</th>		
												<th>Mobile</th>		
												<th>File Process</th>													
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											$usr_id=$row['inc_id'];
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>" />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><a href="javascript:void(0)"><?=$row['file_no']?></a></td>				
												<td><?=$row['name']?></td>
												<td><?=$row['email']?></td>
												<td><?=$row['phone']?></td>
										<?php 
										$query1 = "SELECT * FROM tbl_user_tax_process where file_no='".$row['file_no']."'";
										$res1=mysqli_query($mysqli,$query1);
										$row1 = mysqli_fetch_array($res1);
										if($row1['status']!=""){
												?>
												<td><?=$process_status[$row1['status']];?></td>
										<?php }else{?> <td>0</td><?php } ?>
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">															
													<a href="viewDetails.php?file_no=<?=$row['file_no']?>" >View Details</a>
													<?php  if($_SESSION['admin_type']==0){ ?>
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['file_no']?>';return false;}" title="Delete User"><i class="fa fa-trash"></i></a>
													<?php } ?>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
						}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>