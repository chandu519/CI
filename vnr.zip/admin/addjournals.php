<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_journals";
$pageHeading="Journals";
$pageAdd="addjournals.php";
$pageList="journals.php";

if(isset($_POST["addJournals"]) && $_POST["addJournals"]=="Submit"){
 
	$title=str_replace("'","",$_POST['txtTitle']);
	$content=mysqli_real_escape_string($mysqli,$_POST['txtContent']);
	
	if($_FILES['txtImage']['name'] != ""){
		$result = $allClasses->forFileUpload_ren(SITEDOC_ROOT_PATH."images/", 'txtImage');
		
		if($result){
			$imgName = $result;
			if(@$_POST['hid_image']!= ""){
				unlink(SITEDOC_ROOT_PATH."images/".$_POST['hid_image']);
			}
		}
	}else{
		$imgName = $_POST['hid_image'];
	}
	
	
	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		$sql = "update $tableName set title='".$title."',image='".$imgName."',content='".$content."',dt_updated=now(),updated_by='".$_SESSION['admin_id']."'  where inc_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		$sql="insert into $tableName(title,image,content,priority,status,dt_created,dt_updated,created_by)values('".$title."','".$imgName."','".$content."','0','1',now(),now(),'".$_SESSION['admin_id']."')";
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			echo $error = mysqli_error($mysqli);
			$j_id=mysqli_insert_id($mysqli);
			 $journals_id="j".$j_id;
			if($error == ""){
				$sql2="UPDATE $tableName SET journals_id=? WHERE inc_id=? and status=1";
				$stmt2 = $mysqli->prepare($sql2);
				$stmt2->bind_param('ss',$journals_id,$j_id);	
				$stmt2->execute();
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_id,title,content,image from $tableName where inc_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det2,$det3,$det4);
											$cat->fetch();											
											//$det3 = base64_decode($det3);
											$det3 = str_replace('\"', '"', $det3);
											$det3 = str_replace("\'", "'", $det3);																						
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Title</label>
									</div>
									<div class="finput">
									<input name="txtTitle" type="text" value="<?=@$det2?>" class="" id="txtTitle" >
									</div>
								</div>
								<div class="wrapper">
									<div class="flabel">
										<label for="folder">Image </label>
									</div>
									<div class="finput">
										<input type="file" name="txtImage" id="txtImage" accept="image/*">
									</div>
								</div>
								<?php
								if(@$det4!=''){
									echo '<input type="hidden" name="hid_image" value="'.$det4.'">';	
									?>
									<div class="wrapper" style="margin-bottom:10px">
										<div class="flabel">
											<label for="folder"></label>
										</div>
										<div class="finput">
											<a href="../images/<?=$det4?>" target="_blank" alt="" title=""><img src="../images/<?=$det4?>" width="100" ></a>
										</div>
									</div>									
									<?php 
								}
								?>	
								<div class="wrapper" style="margin-bottom:25px; ">
									<div class="flabel">
										<label for="folder"> Content</label>
									</div>
									<div class="finput">
										<textarea class="" name="txtContent" id="txtContent" ><?php echo @$det3; ?></textarea>
									</div>
								</div>
								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addJournals" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>