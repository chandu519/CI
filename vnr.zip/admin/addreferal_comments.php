<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_referals";
$pageHeading="";
$pageAdd="addreferal_comments.php";
$pageList="referals_totla.php";

if(isset($_POST["subComment"]) && $_POST["subComment"]=="Submit Comment"){
	
	$id=$_POST['hidID'];	
	$comments=escapeString($mysqli,$_POST['txtComment']);		
	
	$sql="INSERT INTO tbl_refer_comments(refers_id,comments,uploaded_by,date_added) VALUES ('".$id."','".$comments."','".$_SESSION['admin_id']."',now())";
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($current_page);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($current_page);
				exit;
			}
		}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">  
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
					
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>				
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	
						
							<?php 
							$cat1 = $mysqli->prepare("select inc_id,file_no,rf_name,rl_name,email,phone,phone1 from $tableName where inc_id='".$_REQUEST['id']."'  ");
								$cat1->execute();
								$cat1->store_result();
								
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												
												<th>Name</th>
												<th>Email</th>
												<th>Mobile </th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$cat1->bind_result($det11,$file_no,$name1,$name2,$email,$phone1,$phone2);
									
										$cat1->fetch();
											?>
											<input type="hidden" name="hidID" value="<?=$det11?>" />														
											<tr>
																							
												<td><?=$name1?> <?=$name2?></td>
												<td><?=$email?> </td>	
												<td><?=$phone1?> </td>	
												
												</tr>		
										<thead>
										<tr>
												<td colspan='3' style="text-align:left"><b>Comments</b></td>											
												
												
												</tr>
												<?php
				$refer_comments = "SELECT * FROM tbl_refer_comments where refers_id = '".$det11."' ORDER BY id DESC";
				$refer_comments_result = mysqli_query($mysqli, $refer_comments);
				if(mysqli_num_rows($refer_comments_result)>=1)
				{
				?>								
												<tr>
												<th>S No</th>
												<th>COMMENT</th>
												<th>Date Updated </th>
											</tr>
											
															
											<?php
				$slno = 1;
				while($row_comments = mysqli_fetch_array($refer_comments_result))
				{
			?>
				<tr>
				<td><?php echo $slno; ?></td>
				<td><?php echo $row_comments['comments']; ?></td>
				<td><?php echo date("m-d-Y", strtotime($row_comments['date_added'])).' &nbsp & &nbsp; '.date("H:i:s", strtotime($row_comments['date_added'])); ?></td>
				</tr>
				<?php
				$slno++;
				}
				}
				else
				{
					echo '<tr>
					<td colspan="3">No Comments added</td>
					</tr>';
				}
				?>	
											
												</thead>
												
										</tbody>
										
										
										
									</table>
									<div class="wrapper table form_upload">	
												<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Add Comment</label>
									</div>
									<div class="finput">
										<input type="text" name="txtComment" id="txtComment" value="">
									</div>
								</div>
														
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="subComment" value="Submit Comment" class="fbtn">
									</div>
								</div>
								</div>
									</form>
								</div>
															
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>