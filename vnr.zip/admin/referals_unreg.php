<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_referals";
$pageHeading="UnRegistered Members";
$pageAdd="addreferal_comments.php";
$pageList="referals_unreg.php";

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">  
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	
						
							<?php 
							//echo "SELECT * FROM tbl_user_referals where email IN (select email from tbl_users) ORDER BY inc_id DESC  ";
							if ($cat1 = $mysqli->prepare("SELECT inc_id,file_no,rf_name,rl_name,email,phone,phone1 FROM tbl_user_referals where email NOT IN (select email from tbl_users) ORDER BY inc_id DESC  ")) 
							{
								$cat1->execute();
								$cat1->store_result();
								if($cat1->num_rows>0){
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>#</th>
												
												<th>Name</th>
												<th>Email</th>
												<th>Mobile </th>
												<th>REF BY	</th>
												<th>LAST COMMENT</th>
												<th>Add Comment</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$cat1->bind_result($det11,$file_no,$name1,$name2,$email,$phone1,$phone2);
										$i=1;
										while($cat1->fetch()){
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>" />														
											<tr>
													<td><a href="javascript:void(0)"><?=$i?></a></td>
												
												<td><?=$name1?> <?=$name2?></td>
												<td><?=$email?> </td>	
												<td><?=$phone1?> </td>	
												<td><?=$file_no?></td>
												<td><?php
													$comments = "select * from tbl_refer_comments where refers_id = '".$det11."' ORDER BY id DESC LIMIT 1";
													$comments_result = mysqli_query($mysqli, $comments);
													while($row_comments = mysqli_fetch_array($comments_result))
													{
														$last_comment = $row_comments['comments'];
													}
												?>
												<?php echo @$last_comment; ?></td>
				
												<td><a class="editBranch" title="ADD <?=$pageHeading?>" href="<?=$pageAdd?>?act=edit&id=<?=$det11?>"><i class="fa fa-plus-square"></i></a> </td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>