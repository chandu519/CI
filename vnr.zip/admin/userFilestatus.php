<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_logs";
$pageHeading="File Status";
$pageAdd="addBanner.php";
$pageList="userFilestatus.php";

/*-----------------------------------*/

if(isset($_POST["SUBMIT"]) && $_POST["SUBMIT"]=="CHANGE STATUS"){
	
	$file_no=$_REQUEST['file_no'];
	
	$process_status=$_POST['txtFile_status'];
	$comments=$_POST['txtComments'];
	
	
	
		echo  $sql="INSERT INTO  $tableName(file_no, modified_by, process_status, comments, dt_created, dt_last_modified) VALUES ('".$file_no."','".$_SESSION['admin_id']."','".$process_status."','".$comments."',now(),now())";
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			echo $sql1 = "UPDATE tbl_user_tax_process SET status='".$process_status."' WHERE file_no='".$file_nos."' ";
				$result1 = mysqli_query($mysqli,$sql1);
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			//exit;
			if($error == ""){
				
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($current_page);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($current_page);
				exit;
			}
		}
	
	
	
}

?>
<!doctype html>
<!--

<li><a href="viewDetails.php">Tax Payer</a></li>
<li><a href="view-spouce-Details.php">Spouse Details</a></li>
<li><a href="dependent-info.php">Dependent Details</a></li>
<li><a href="interview-pending-info.php">Interview Pending</a></li>
<li><a href="userDocuments.php">Documents</a></li>
<li><a href="userTaxSummary.php">Documents</a></li>
<li><a href="userReferals.php">Documents</a></li>

-->

<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php //include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
					<?php include "includes/ui_info_top.php"; ?>   
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
							<?php 
							if(isSet($_SESSION['stat'])){
							?>										
							<?php 
							if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
								$error_msg="";
							}
							if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
								$error_msg="error_msg";	
							}
							?>
							<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
							<?php 
								unset($_SESSION['stat']);
							}
							?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">File No</label>
									</div>
									<div class="finput">
										<input type="text" name="txtFile_no" id="txtFile_no" value="<?=$_REQUEST['file_no']?>" disabled>
									</div>
								</div>
								<?php
								$process_query = "select * from tbl_user_tax_process where file_no='".$_REQUEST['file_no']."' ";
								$process_query_row_result = mysqli_query($mysqli,$process_query);
								$process_query_row = mysqli_fetch_assoc($process_query_row_result);
								$process_query_status=$process_query_row['status'];
								?>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Select Document Type</label>
									</div>
									<div class="finput">
										<select name="txtFile_status" id="txtFile_status" required>
											<option value="">Select Tax Summary Type</option>
											<option value="1" <?php if($process_query_status==1){echo 'selected';}?> >Schedule Pending</option>
											<option value="2" <?php if($process_query_status==2){echo 'selected';}?>  >Interview Pending</option>
											<option value="3"  <?php if($process_query_status==3){echo 'selected';}?> >Preparation Pending</option>
											<option value="4"  <?php if($process_query_status==4){echo 'selected';}?> >Payment Pending</option>
											<option value="5"  <?php if($process_query_status==5){echo 'selected';}?>  >Tax Filing Copies Sent</option>
											<option value="6" <?php if($process_query_status==6){echo 'selected';}?>  >Need Approval</option>
											<option value="7"  <?php if($process_query_status==7){echo 'selected';}?> >E-Filing Pending</option>
											<option value="8" <?php if($process_query_status==8){echo 'selected';}?>  >Paper Filing Pending</option>
											<option value="9"   <?php if($process_query_status==9){echo 'selected';}?> >E-Filing Done</option>
											<option value="10"  <?php if($process_query_status==10){echo 'selected';}?> >Paper Filing Done</option>
											<option value="11" <?php if($process_query_status==11){echo 'selected';}?>  >Cancelled</option>
										</select>
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Comments</label>
									</div>
									<div class="finput">
										<input name="txtComments" type="text" id="txtComments">
									</div>
								</div>
								
							
															
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="SUBMIT" value="CHANGE STATUS" class="fbtn">
									</div>
								</div>
							
								
								
								
							</form>
						</div>   
		<div class="wrapper table">	
					
							<?php 
							if(@$_REQUEST['file_no']!=""){
								$file_no=$_REQUEST['file_no'];
								$query = "SELECT * FROM $tableName where file_no='".$file_no."' ";
								$res=mysqli_query($mysqli,$query);
								if(mysqli_num_rows($res)>0){ 
								
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th> STATUS CHANGED TO	 </th>
												<th>Comments	 </th>
												<th> Date Uploded </th>	
												<th>Updated By</th>											
																			
																
											</tr>
										</thead>
										<tbody>
										<?php 
										$i=1;
										while($row = mysqli_fetch_array($res)){  
											
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>" />														
											<tr>
												<td><?=$i?></td>
												<td><?=$process_status[$row['process_status']]?></td>
												<td style="text-align:left"><?=$row['comments']?></td>	
												<td><?=$row['dt_created']?></td>
												<td><?=$row['modified_by']?></td>		
												
												
											</tr>	
											<?php $i++;
										}
										?>			
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>


						
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>