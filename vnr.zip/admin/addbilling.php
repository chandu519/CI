<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_bills";
$pageHeading="Invoices";
$pageAdd="addbilling.php";
$pageList="billing.php";

if(isset($_POST["addInvice"]) && $_POST["addInvice"]=="Submit"){
	
	$name=mysqli_real_escape_string($mysqli,$_POST['txtName']);
	$phone=mysqli_real_escape_string($mysqli,$_POST['txtphone']);
	$comments=mysqli_real_escape_string($mysqli,$_POST['txtComments']);
	$given_amt=mysqli_real_escape_string($mysqli,$_POST['txtGamt']);
	$balence=($_POST['txtTamount']-$_POST['txtGamt']);
	$total_amt=mysqli_real_escape_string($mysqli,$_POST['txtTamount']);
	$village=mysqli_real_escape_string($mysqli,$_POST['txtvillage']);
	 $txtCurecases = $_POST['txtCurecases1'];
	
	
	
	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		$sql = "update $tableName set article_id='".$article_id."',journals_id='".$journals_id."',invoice_no='".$invoice_no."',date='".$date."',article_title='".$article_title."',authors='".$authors."',author_date='".$author_date."',amt='".$amt."',amt_words='".$amt_words."'  where inc_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		$inc_cat_id=0;
		 $sql="insert into $tableName(inc_cat_id,name,phone,comments,total_amt,given_amt,balence,village,status,dt_created)values('".$inc_cat_id."','".$name."','".$phone."','".$comments."','".$total_amt."','".$given_amt."','".$balence."','".$village."','1',now())";
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			 $prod_id=mysqli_insert_id($mysqli);
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			//exit;
			if($error == ""){
				if($txtCurecases >0){
				for($i=1;$i<=$txtCurecases;$i++){
					 $prod_name = $_POST['txtTitle'.$i];	
					$price = $_POST['txtPrice'.$i];	
						 $sql="insert into tbl_bill_products(bill_id,prod_name,price,dt_created)values(?,?,?,now())";
						if($stmt = $mysqli->prepare($sql)){
							$s='sss';
							$stmt->bind_param($s,$prod_id,$prod_name,$price);
							$flag=$stmt->execute();	
							//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
							//exit;
				   }	
				}
			}
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}

?>
<!doctype html>
<html>
<script>
function validate(){
   
	if(document.frmCase.txtCurecases1.value >0){ 
		
		for(i=1;i<=document.frmCase.txtCurecases1.value;i++){
			img = document.getElementById('txtImage'+i).value;
		if(img == ""){
			alert("image should not be empty.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
		
		var lpos = img.lastIndexOf('.');
		ext = img.substr(lpos+1);
		ext = ext.toLowerCase();
		if(ext != "jpeg" & ext !='gif' & ext !='png' & ext !='jpg'){
			alert("Please select a jpeg or jpg or gif or png image.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
			
		}
	}
return true;
}	
var vldnum=/^[0-9]+$/;
var i =0;	
function displayChildInfo(caseimages){
	
var txtImageDetails = "";
match=vldnum.test(caseimages);
if(!match){	  
alert("Enter numbers only.");
return false;
}else{
if(caseimages >0){
	txtImageDetails ='<div class="wrapper table form_upload"><div class="wrapper"><form action="" name="frmCase" method="POST" class="wrapper" onSubmit="return validate();" enctype="multipart/form-data"><input type="hidden" name="txtCurecases1" id="txtCurecases1" value='+caseimages+'><div class="form-body"><div class="row">';
	for(i=1;i<=caseimages;i++){
		txtImageDetails += '<div class="wrapper"><div class="flabel"><label for="folder">Title'+i+'</label></div><div class="finput"><input type="text" class="" name="txtTitle'+i+'" id="txtTitle'+i+'"></div></div><div class="wrapper"><div class="flabel"><label for="folder">Price'+i+'</label></div><div class="finput"><input type="number" class="" placeholder="Product Price" name="txtPrice'+i+'" id="txtPrice'+i+'" onKeyUp="return GetproductTotal('+caseimages+');"></div></div>';		
	}
	//txtImageDetails +='</div></div><input type="submit" name="butSubmit" class="fbtn" value="Submit"> </form></div></div>';
}else{
	document.getElementById('divImageInfo').innerHTML = '';
}
}
if(txtImageDetails != ""){
document.getElementById('divImageInfo').innerHTML = txtImageDetails;
}
}			
	</script>
	<script language="javascript" type="text/javascript">
/*function go(id){
		window.location = 'innerBanners.php?id='+id;
}*/
</script>


	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_id,inc_cat_id,name,phone,comments,total_amt,given_amt,balence,village,status from $tableName where inc_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det8,$det2,$det3,$det4,$det5,$det6,$det7,$det9,$det10);
											$cat->fetch();											
											//$det3 = base64_decode($det3);
											$det3 = str_replace('\"', '"', $det3);
											$det3 = str_replace("\'", "'", $det3);																						
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Name</label>
									</div>
									<div class="finput">	
									<input name="txtName" type="text" value="<?=@$det2?>" class="" id="txtName" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Phone</label>
									</div>
									<div class="finput">	
									<input name="txtphone" type="text" value="<?=@$det3?>" class="" id="txtphone" >
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Village</label>
									</div>
									<div class="finput">	
									<input name="txtvillage" type="text" value="<?=@$det9?>" class="" id="txtvillage" required>
									</div>
								</div>
								<div class="wrapper" style="margin-bottom:25px;">
									<div class="flabel">
										<label for="folder"> Comments</label>
									</div>
									<div class="finput">	
									<textarea name="txtComments" type="text"  class="" id="txtComments" ><?=@$det4?></textarea>
									</div>
								</div>
								<div class="wrapper" style="display:none;">
									<div class="flabel">
										<label for="folder"> Amount In Words</label>
									</div>
									<div class="finput">	
									<input name="txtamtwords" type="text" value="<?=@$det3?>" class="" id="txtamtwords" >
									</div>
								</div>
								
								
								
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> No Of Contents</label>
									</div>
									<div class="finput">
											<input class="" name="txtCurecases" type="text" id="txtCurecases" size="3" maxlength="2" value="0" onKeyUp="displayChildInfo(this.value)" />
									</div>
								</div>
															
								<div class="wrapper">
									<div class="finput">										
									<div id="divImageInfo"></div>
									</div>
								</div>
								
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Total Amount</label>
									</div>
									<div class="finput">	
									<input name="txtTamount" type="text" value="<?=@$det5?>" class="" id="txtTamount" required disabled>
									</div>
								</div>
								
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Given Amount</label>
									</div>
									<div class="finput">	
									<input name="txtGamt" type="text" value="<?=@$det6?>" class="" id="txtGamt" style="width:50%;">
									</div>
								</div>
								
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Balence</label>
									</div>
									<div class="finput">	
									<input name="" type="text" value="<?=@$det7?>" class="" id="" style="width:50%;" disabled>
									</div>
								</div>
								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addInvice" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
						
<?php 
if(@$_REQUEST['id']!=""){
	$id=$_REQUEST['id'];
  $query = "SELECT bill_id,prod_name,quantity,grams,price,dt_created FROM tbl_bill_products where bill_id='$id' ORDER BY inc_id DESC";
$res=mysqli_query($mysqli,$query);	
if(mysqli_num_rows($res)>0){ $i=1;
?>					<div class="wrapper table form_upload">	
			<div class="wrapper title">
                        <h1>Products</h1>
                       
                    </div>	
				<div id="tableWrap">
				
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>SNo</th>
												<th>Product Name</th>	
												<th>Price</th>					
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php 
											while($row = mysqli_fetch_array($res)){  
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$row['inc_id']?>"  />														
											<tr>
												<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$row['prod_name']?></td>												
												<td><?=$row['price']?></td>			
												
											
												<td class="button-list">
													<div class="btn-group btn-group-justified">		
													<a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&id=".$row['inc_img_id']."&img=".$row['image']?>';return false;}" title="Remove <?=$pageHeading?>"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden"  name="hidTotal" value="<?=$i?>" />	
										<tr>
											<td></td>
																			
											<td class="input_table">
												<!--<input type="submit" class="addNew" name="butSubmit" value="Update" />-->
											</td>                                                														
											<td></td>
											<td></td>
										</tr>
										</tbody>
									</table>
									</form>
								</div>
				</div>
<?php } ?>				
				<!-- End PAge Content -->
	<?php 
}
?>	
						
						
						
						
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>  
<script>
  function GetproductTotal(id) {

var sum = 0;
for($i=1; $i<=id; $i++){ 
	 sum+=parseInt(document.getElementById("txtPrice"+$i+"").value);
console.log(sum);
}
	if(sum>1){
		$("#txtTamount").val(sum);
	}else{
		$("#txtTamount").val(document.getElementById("txtPrice1").value);
	}

/* 	  
  var num1 = document.getElementById("txtPrice").value;
  var num2 = document.getElementById("txtinitial_cert_gst").value;
  var num3 = num1 * num2/100;
  var result = parseInt(num1)+parseInt(num3);
   document.getElementById('txtinitial_cert_total').value = result; */
 }
	</script>					
	</body>
</html>