<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_user_referals";
$pageHeading="User Referals";
$pageAdd="addreferals.php";
$pageList="referals.php";

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">					
					
					<?php include_once "includes/admin_menu.php"; ?>    
					
					<div class="content_block">
					<?php include "includes/ui_info_top.php"; ?>   
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php //include_once "includes/ui_message.php"; ?>	
						<div class="wrapper table">	
						
							<?php 
							if ($cat1 = $mysqli->prepare("select inc_id,file_no,rf_name,rl_name,email,phone,phone1 from $tableName where file_no='".$_REQUEST['file_no']."'  order by inc_id	asc ")) 
							{
								$cat1->execute();
								$cat1->store_result();
								if($cat1->num_rows>0){
								?>                        
								<div id="tableWrap">
									<form name="" action="" method="post" class="">
									<table>
										<thead>
											<tr>
												<th>#</th>
												<th>File No</th>
												<th>Name</th>
												<th>Email</th>
												<th>Mobile 1</th>
												<th>Mobile 2</th>
											</tr>
										</thead>
										<tbody>
										<?php 
										$cat1->bind_result($det11,$file_no,$name1,$name2,$email,$phone1,$phone2);
										$i=1;
										while($cat1->fetch()){
											?>
											<input type="hidden" name="hidID<?=$i?>" value="<?=$det11?>" />														
											<tr>
													<td><a href="javascript:void(0)"><?=$i?></a></td>
												<td><?=$file_no?></td>
												<td><?=$name1?> <?=$name2?></td>
												<td><?=$email?> </td>	
												<td><?=$phone1?> </td>	
												<td><?=$phone2?> </td>
											</tr>	
											<?php $i++;
										}
										?>			
										<input type="hidden" name="hidTotal" value="<?=$i?>">	
										
										</tbody>
									</table>
									</form>
								</div>
							<?php
						}else{ ?>
							<div class="wrapper no_docs_data">
								No data
							</div>
							<?php 
							}}
						?>										
						</div>
					</div> 
				</div>
			</div>
    </div>		
					<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>