<?php include_once "includes/config.php"; 
include_once "includes/loginAuth.php"; 

//Table & Page Details
$tableName="tbl_invoice";
$pageHeading="Invoices";
$pageAdd="addinvoice.php";
$pageList="invoice.php";

if(isset($_POST["addInvice"]) && $_POST["addInvice"]=="Submit"){
 
	
	$article=explode(',',$_POST['txtArticle']);
	$article_id=$article[0];
	$journals_id=$article[1];
	
	
	$invoice_no=mysqli_real_escape_string($mysqli,$_POST['txtIvno']);
	$date=mysqli_real_escape_string($mysqli,$_POST['txtIvd']);
	$article_title=mysqli_real_escape_string($mysqli,$_POST['txtAtitle']);
	$authors=mysqli_real_escape_string($mysqli,$_POST['txtAuthor']);
	$author_date=mysqli_real_escape_string($mysqli,$_POST['txtAdate']);
	$amt=mysqli_real_escape_string($mysqli,$_POST['txtamtno']);
	$amt_words=mysqli_real_escape_string($mysqli,$_POST['txtamtwords']);
	
	
	
	
	if(@$_POST['hid_action']=="editcat" && @$_POST['hid_cat_id']!=""){
		$sql = "update $tableName set article_id='".$article_id."',journals_id='".$journals_id."',invoice_no='".$invoice_no."',date='".$date."',article_title='".$article_title."',authors='".$authors."',author_date='".$author_date."',amt='".$amt."',amt_words='".$amt_words."'  where inc_id=".$_POST['hid_cat_id'];
		
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			if($error == ""){
				$_SESSION['stat']="SE";				
			}else{
				$_SESSION['stat']="FE";
			}
			$allClasses->forRedirect ($pageList);
			exit;
		}
	}else{
		 $sql="insert into $tableName(journals_id,article_id,invoice_no,author_date,authors,date,article_title,amt,amt_words,status,dt_created)values('".$journals_id."','".$article_id."','".$invoice_no."','".$author_date."','".$authors."','".$date."','".$article_title."','".$amt."','".$amt_words."','1',now())";
		if($sql != ""){
			$result = mysqli_query($mysqli,$sql);
			$error = mysqli_error($mysqli);
			//echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
			//exit;
			if($error == ""){
				$_SESSION['stat']="SA";
				$allClasses->forRedirect ($pg);
				exit;
			}else{
				$_SESSION['stat']="FA";
				$allClasses->forRedirect ($pg);
				exit;
			}
		}
	}
}

?>
<!doctype html>
<html>
	<head>
		<!-- META/CSS/JS DATA -->
		<?php include "includes/ui_meta_tags.php"; ?>                
	</head>
	<body>
		<?php include_once "includes/ui_header.php"; ?>
	<?php include_once "includes/ui_editor1.php"; ?>
    <div class="wrapper content_box">
			<div class="wrapper_inner">
				<div class="wrapper">										
					<?php include_once "includes/admin_menu.php"; ?>    					
					<div class="content_block">	
						<div class="wrapper title">
                        <h1><?=$pageHeading?></h1>
                       
                    </div>
						<!-- Breadcrumb -->
						<?php // include_once "includes/ui_breadcrumb.php"; ?>    
						
						<!-- Success/Fail Message -->
						<?php // include_once "includes/ui_message.php"; ?>	
<?php 
if(isSet($_SESSION['stat'])){
?>										
<?php 
if($_SESSION['stat']=='SE' || $_SESSION['stat']=='SD' || $_SESSION['stat']=='SA'){
	$error_msg="";
}
if($_SESSION['stat']=='FE' || $_SESSION['stat']=='FD' || $_SESSION['stat']=='FA'){
	$error_msg="error_msg";	
}
?>
<div class="success_msg <?=$error_msg?>"><?=$err[$_SESSION['stat']]?> <span class="msgC">x</span></div>
<?php 
	unset($_SESSION['stat']);
}
?>							
						<div class="wrapper table form_upload">								
						<div class="wrapper">
						
							<a href="<?=$pageList?>" class="addNew"><i class="fa fa-angle-double-left"></i> Back</a>
						</div>
						
							<form action="" enctype="multipart/form-data" method="post" class="wrapper">
								<?php
									if(@$_REQUEST['act']=="edit" && $_REQUEST['id']!=""){
								$cid=$_REQUEST['id'];
								if ($cat = $mysqli->prepare("select inc_id,journals_id,article_id,invoice_no,date,article_title,authors,author_date,amt,amt_words,status from $tableName where inc_id=?")) {
										$cat->bind_param('i',$cid );
										$cat->execute();
										$cat->store_result();
										if($cat->num_rows>0){
											$cat->bind_result($det1,$det8,$det2,$det3,$det4,$det5,$det6,$det7,$det9,$det10,$det11);
											$cat->fetch();											
											//$det3 = base64_decode($det3);
											$det3 = str_replace('\"', '"', $det3);
											$det3 = str_replace("\'", "'", $det3);																						
											echo '<input type="hidden" name="hid_cat_id" value="'.$det1.'" />';											
											echo '<input type="hidden" name="hid_action" value="editcat" />';
											$cat->close();
										}
									}
							}else{
								$cid=0;
							}
									?> 
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder">Selece Article</label>
									</div>
									<div class="finput">
									<select name="txtArticle" >
									<option >select</option>
									<?php 
									$sql="select inc_id,journals_id,article from tbl_articles where status=1 order by priority asc";
									$res=mysqli_query($mysqli,$sql);
									while($row=mysqli_fetch_array($res)){
										
									?>
									<option value="<?=$row['inc_id']?>,<?=$row['journals_id']?>" <?php if(@$det2==$row['inc_id']){echo 'selected';}?>><?=$row['article']?> </option>
									<?php } ?>
									</select>
									
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Invoice No</label>
									</div>
									<div class="finput">	
									<input name="txtIvno" type="text" value="<?=@$det3?>" class="" id="txtIvno" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Invoice Date</label>
									</div>
									<div class="finput">	
									<input name="txtIvd" type="date" value="<?=@$det3?>" class="" id="txtIvd" style="width:50%;">
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Article Title</label>
									</div>
									<div class="finput">	
									<input name="txtAtitle" type="text" value="<?=@$det3?>" class="" id="txtAtitle" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Author</label>
									</div>
									<div class="finput">	
									<input name="txtAuthor" type="text" value="<?=@$det3?>" class="" id="txtAuthor" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Author Date</label>
									</div>
									<div class="finput">	
									<input name="txtAdate" type="date" value="<?=@$det3?>" class="" id="txtAdate" style="width:50%;">
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Amount In Nos</label>
									</div>
									<div class="finput">	
									<input name="txtamtno" type="text" value="<?=@$det3?>" class="" id="txtamtno" required>
									</div>
								</div>
								<div class="wrapper" style="">
									<div class="flabel">
										<label for="folder"> Amount In Words</label>
									</div>
									<div class="finput">	
									<input name="txtamtwords" type="text" value="<?=@$det3?>" class="" id="txtamtwords" required>
									</div>
								</div>
								
								
								<div class="wrapper">
									<div class="flabel">&nbsp;</div>
									<div class="finput">										
										<input type="submit" name="addInvice" value="Submit" class="fbtn">
									</div>
								</div>
							</form>
						</div>    
					</div> 
				</div>
			</div>
    </div>		
						<?php include_once "includes/ui_footer.php"; ?>      
	</body>
</html>