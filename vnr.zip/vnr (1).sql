-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2019 at 03:42 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vnr`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_users`
--

CREATE TABLE `tbl_admin_users` (
  `u_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `delete_flag` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access` varchar(225) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_admin_users`
--

INSERT INTO `tbl_admin_users` (`u_id`, `name`, `email`, `password`, `mobile`, `image`, `dob`, `dt_created`, `dt_modified`, `created_by`, `modified_by`, `status`, `delete_flag`, `type`, `fullname`, `access`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', '9876543210', NULL, '2010-01-01', '2018-05-07 04:19:38', '2018-11-26 03:54:51', 'admin', 'admin', 1, 0, 0, 'Sai Kumar', ''),
(2, 'admin1', 'admin1@gmail.com', 'admin1', '', NULL, NULL, '2018-11-26 03:58:30', '2019-02-04 12:25:52', NULL, 'admin', 1, 0, 1, 'admin1', '1,2,9,10,11'),
(3, 'admin2', 'admin2@gmail.com', 'admin', '', NULL, NULL, '2018-11-26 03:59:21', '2019-02-04 12:26:23', NULL, 'admin', 1, 0, 1, 'admin2', '1,2,3'),
(4, 'admin3', 'admin3@gmail.com', 'admin3', '', NULL, NULL, '2018-12-13 16:08:50', '2019-02-04 12:26:38', 'admin', 'admin', 1, 0, 0, 'admin3', '1,11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_content`
--

CREATE TABLE `tbl_content` (
  `inc_content_id` int(11) NOT NULL,
  `page_name` varchar(50) DEFAULT NULL,
  `content` longtext,
  `seo_title` text,
  `seo_keywords` text,
  `seo_desc` text,
  `dt_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_content`
--

INSERT INTO `tbl_content` (`inc_content_id`, `page_name`, `content`, `seo_title`, `seo_keywords`, `seo_desc`, `dt_created`) VALUES
(1, 'Home', '', 'VHJhY2tpbmcgU3lzdGVt', 'VHJhY2tpbmcgU3lzdGVt', 'VHJhY2tpbmcgU3lzdGVt', '2014-12-01'),
(2, 'Testimonials', '', 'T25saW5lIFRheCBGaWxlcg==', 'T25saW5lIFRheCBGaWxlcg==', 'T25saW5lIFRheCBGaWxlcg==', '2018-12-19'),
(3, 'About Us', '', 'T25saW5lIFRheCBGaWxlcg==', 'T25saW5lIFRheCBGaWxlcg==', 'T25saW5lIFRheCBGaWxlcg==', '2018-12-19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general_info`
--

CREATE TABLE `tbl_general_info` (
  `inc_cat_id` int(11) NOT NULL,
  `gold` int(11) NOT NULL,
  `silver` int(11) NOT NULL,
  `old_gold` int(11) NOT NULL,
  `old_silver` int(11) NOT NULL,
  `dt_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_general_info`
--

INSERT INTO `tbl_general_info` (`inc_cat_id`, `gold`, `silver`, `old_gold`, `old_silver`, `dt_created`) VALUES
(1, 100, 10000, 50, 5000, '2019-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoces`
--

CREATE TABLE `tbl_invoces` (
  `invoice_id` int(11) NOT NULL,
  `user_info` int(11) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `discount` int(11) NOT NULL,
  `exc_cat_type` varchar(225) DEFAULT NULL,
  `exc_gross_weight` int(11) DEFAULT NULL,
  `exc_price` int(11) DEFAULT NULL,
  `paid_amount` int(11) DEFAULT '0',
  `due_amount` int(11) DEFAULT '0',
  `total_amount` int(11) NOT NULL,
  `dt_created` date NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_invoces`
--

INSERT INTO `tbl_invoces` (`invoice_id`, `user_info`, `description`, `date`, `discount`, `exc_cat_type`, `exc_gross_weight`, `exc_price`, `paid_amount`, `due_amount`, `total_amount`, `dt_created`, `status`) VALUES
(1, 0, '', '2019-03-21', 15000, 'Gold', 9, 21600, 200, 50360, 50560, '2019-03-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_info`
--

CREATE TABLE `tbl_invoice_info` (
  `inc_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `gross` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `making_charges` int(11) NOT NULL,
  `stone_weight` int(11) NOT NULL,
  `price_of_product` int(11) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_invoice_info`
--

INSERT INTO `tbl_invoice_info` (`inc_id`, `invoice_id`, `product_id`, `gross`, `qty`, `making_charges`, `stone_weight`, `price_of_product`, `dt_created`) VALUES
(1, 1, 1, 10, 2, 200, 1, 57200, '2019-03-21 18:18:01'),
(2, 1, 3, 10, 1, 1200, 1, 28200, '2019-03-21 18:18:01'),
(3, 1, 2, 20, 2, 200, 1, 1760, '2019-03-21 18:18:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pricing`
--

CREATE TABLE `tbl_pricing` (
  `inc_id` int(22) NOT NULL,
  `date` date NOT NULL,
  `gold` int(22) NOT NULL,
  `silver` int(22) NOT NULL,
  `status` int(2) NOT NULL,
  `dt_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='gold & Silver Prices datewise';

--
-- Dumping data for table `tbl_pricing`
--

INSERT INTO `tbl_pricing` (`inc_id`, `date`, `gold`, `silver`, `status`, `dt_created`) VALUES
(1, '2019-03-21', 3000, 40, 1, '2019-03-21'),
(2, '2019-03-22', 3100, 41, 1, '2019-03-21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `inc_id` int(11) NOT NULL,
  `prod_name` varchar(225) NOT NULL,
  `gross` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `category` varchar(225) NOT NULL,
  `status` int(2) NOT NULL,
  `dt_created` date NOT NULL,
  `dt_updated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`inc_id`, `prod_name`, `gross`, `qty`, `category`, `status`, `dt_created`, `dt_updated`) VALUES
(1, 'rings', 980, 0, 'gold', 1, '2019-03-21', '0000-00-00'),
(2, 'chains', 460, 0, 'silver', 1, '2019-03-21', '0000-00-00'),
(3, 'bracelits', 90, 0, 'gold', 1, '2019-03-21', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_revd_price`
--

CREATE TABLE `tbl_revd_price` (
  `inc_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `price2` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `dt_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(22) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `address` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL,
  `status` int(2) NOT NULL,
  `dt_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `name`, `email`, `phone`, `address`, `image`, `status`, `dt_created`) VALUES
(1, 'kittu', 'kittu@gmail.com', '8121282835', 'koukuntls', '', 1, '2019-03-21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_users`
--
ALTER TABLE `tbl_admin_users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tbl_content`
--
ALTER TABLE `tbl_content`
  ADD PRIMARY KEY (`inc_content_id`);

--
-- Indexes for table `tbl_general_info`
--
ALTER TABLE `tbl_general_info`
  ADD PRIMARY KEY (`inc_cat_id`);

--
-- Indexes for table `tbl_invoces`
--
ALTER TABLE `tbl_invoces`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `tbl_invoice_info`
--
ALTER TABLE `tbl_invoice_info`
  ADD PRIMARY KEY (`inc_id`);

--
-- Indexes for table `tbl_pricing`
--
ALTER TABLE `tbl_pricing`
  ADD PRIMARY KEY (`inc_id`),
  ADD UNIQUE KEY `date` (`date`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`inc_id`);

--
-- Indexes for table `tbl_revd_price`
--
ALTER TABLE `tbl_revd_price`
  ADD PRIMARY KEY (`inc_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_users`
--
ALTER TABLE `tbl_admin_users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_content`
--
ALTER TABLE `tbl_content`
  MODIFY `inc_content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_general_info`
--
ALTER TABLE `tbl_general_info`
  MODIFY `inc_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_invoces`
--
ALTER TABLE `tbl_invoces`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_invoice_info`
--
ALTER TABLE `tbl_invoice_info`
  MODIFY `inc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_pricing`
--
ALTER TABLE `tbl_pricing`
  MODIFY `inc_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `inc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_revd_price`
--
ALTER TABLE `tbl_revd_price`
  MODIFY `inc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
