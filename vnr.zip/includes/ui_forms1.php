<li class="lastli">
<?php if(isset($_SESSION['exam_user_id']) && $_SESSION['exam_user_id']!=""){ ?>
<a href="onlineExam.php" id="hexam">Online Exam</a><?php }else{?><a href="javascript:void(0);" id="hexam">Online Exam</a><?php }?>
	<div class="menu_exam">                              
	  <div class="header_exam">
		  <form action="actions.php" method="post" class="">
			  <h5>Login</h5>
			  <span id="errMsgLog" style="color:red;"></span>
			  <div class="fullbody">
				  <input type="text" class="hl_input" placeholder="* Username" name="txtEmailL" id="txtEmailL">
				  <input type="password" class="hl_input" placeholder="* Password" id="txtPasswordL" name="txtPasswordL">
				  <input type="submit" class="hl_btn"  value="LOGIN" onClick="return checkLogin();" name="submit">
			  </div>
		  </form>
	  </div>
  </div>

</li>
					  
<li class="lastli1">
<?php if(isset($_SESSION['user_id']) && $_SESSION['user_id']!=""){ ?>
<a href="javascript:void(0);" id="hlogin">MY Account</a>

<div class="menu_login">                              
  <div class="header_login">
	  <ul>
		<li><a href="updateProfile.php">Edit Profile</a></li>
		<li><a href="myAccount.php">My Account</a></li>
		<li><a href="savedjobs.php">Saved Jobs</a></li>
		<li><a href="applyedjobs.php">Applied Jobs</a></li>
		<li><a href="logout.php">Logout</a></li>
	  </ul>
  </div>
</div>
<?php }else{ ?>
<a href="javascript:void(0);" id="hlogin">Login</a> <span>/</span>
<a href="javascript:void(0);" id="hsignup">Register</a>

<div class="menu_login">                              
  <div class="header_login">
	  <?php
		if(@$_SESSION['lstat']=="LFAIL"){ echo '<span style="color:red" >Invalid Username/Password. Please try again.</span>'; }
		if(@$_SESSION['lstat']=="LPFAIL"){ echo '<span style="color:red" >Wrong password. Please try again.</span>'; }
		?>
		<script language="javascript" type="text/javascript">
		function validateLogin(){
		if(document.frmLogin.txtLEmail.value.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) == -1){
		alert("Invalid Email ID.");
		document.frmLogin.txtLEmail.focus();
		return false;
		}
		if(document.frmLogin.txtLPWD.value == ""){
		alert("Password should not be empty.");
		document.frmLogin.txtLPWD.focus();
		return false;
		}	
		return true;
		}
		</script>
	  <form action="actions.php" method="post" name="frmLogin" class="" onSubmit="return validateLogin();">
		  <h5>Login </h5>
		  
		  <div class="fullbody">
			  <input type="text" class="hl_input" placeholder="* Username"  name="txtLEmail" id="txtLEmail" >
			  <input type="password" class="hl_input" placeholder="* Password" name="txtLPWD" id="txtLPWD" >
			  <input type="submit" class="hl_btn" name="butSubmitLogin" value="LOGIN">
		  </div>
	  </form>
  </div>
</div>

<div class="menu_signup">                              
  <div class="header_signup">
	  <?php
		if(@$_SESSION['rstat']=="REXIST"){ echo '<span style="color:red" >User exists with given Email. Try Different One.</span>'; }
		if(@$_SESSION['rstat']=="RFAIL"){ echo '<span style="color:red" >Unable to register. Please try again.</span>'; }
		if(@$_SESSION['rstat']=="RMATCH"){ echo '<span style="color:red" >Password does not match. Please try again.</span>'; }
		?>
		<script language="javascript" type="text/javascript">
		function validateregister(){
		var sNumber = /^[0-9]+$/;

		if(document.frmRegister.txtRName.value == ""){
		alert("Name should not be empty.");
		document.frmRegister.txtRName.focus();
		return false;
		}

		if(document.frmRegister.txtREmail.value.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) == -1){
		alert("Invalid Email ID.");
		document.frmRegister.txtREmail.focus();
		return false;
		}
		match = sNumber.test(document.frmRegister.txtRPhone.value);
		if(!match){
		alert("Invalid phone number.");
		document.frmRegister.txtRPhone.focus();
		return false;
		}
		if(document.frmRegister.txtRPhone.value.length < 10){
		alert("phone number Shoud be 10 Charecters.");
		document.frmRegister.txtRPhone.focus();
		return false;
		}
		if(document.frmRegister.txtRPWD.value == ""){
		alert("Password should not be empty.");
		document.frmRegister.txtRPWD.focus();
		return false;
		}

		if(document.frmRegister.txtRPWD.value.length < 6){
		alert("Password should not be must 6 Charecters.");
		document.frmRegister.txtRPWD.focus();
		return false;
		}



		return true;
		}
		</script>									
	  <form action="actions.php" method="post" class="" name="frmRegister" onSubmit="return validateregister()">
		  <h5>Create An Account</h5>
		  <div class="fullbody"> 
			  <input type="text" class="hl_input" placeholder="* Full name" name="txtRName" id="txtRName">
			  <input type="text" class="hl_input" placeholder="* Email/User ID" name="txtREmail" id="txtREmail">
			  <input type="text" class="hl_input" placeholder="* Phone"  name="txtRPhone" id="txtRPhone" >
			  <input type="password" class="hl_input" placeholder="* Password" name="txtRPWD" id="txtRPWD">
			  <input type="submit" class="hl_btn" name="butRegister" value="Register Now">
		  </div>
	  </form>
  </div>
</div>
<?php }?>

</li>
						  
<script>
function checkLogin(){
	
		var txtEmailL = document.getElementById("txtEmailL").value.trim();
	var txtPasswordL = document.getElementById("txtPasswordL").value.trim();
		
	$("#errMsgLog").html("");	
	if (txtEmailL.length == 0) {		
		$("#errMsgLog").html("Please provide a UserId");
		document.getElementById("txtEmailL").value = "";
		document.getElementById("txtEmailL").focus();
		return false;
	} 
	
	if (txtPasswordL.length == 0) {		
		$("#errMsgLog").html("Please provide a password");
		document.getElementById("txtPasswordL").value = "";
		document.getElementById("txtPasswordL").focus();
		return false;
	}
	if (txtPasswordL.length < 6) {		
		$("#errMsgLog").html("Please provide minimum 6 character password");		
		document.getElementById("txtPasswordL").focus();
		return false;
	}
	 
	$("#errMsgLog").html('Please wait..');          
	$.ajax({ url:"ajax.php",type: 'POST',data: {'action': 'checkLogin', 'txtEmailL': txtEmailL, 'txtPasswordL': txtPasswordL   },success:function(result){
		$("#errMsgLog").html(result);          
		console.log(result);
		if(result.trim()=='success'){
			$("#errMsgLog").html('Successfully logged in, please while we redirect you'); 
			setTimeout(function(){ 
			window.location.href = 'onlineExam.php';
	}, 1000);  			
		}				 
	}}); 	
	return false;
}

 </script>  