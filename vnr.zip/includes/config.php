<?php
session_start();
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past

foreach($_SESSION as $key => $val){
//echo "<br>&nbsp;&nbsp;<b>".$key."</b>&nbsp;&nbsp;:&nbsp;&nbsp;".$val;
}
if($_SERVER['HTTP_HOST'] == "localhost" || $_SERVER['HTTP_HOST'] == "192.168.1.9" || $_SERVER['HTTP_HOST'] == "
	172.16.0.3" || $_SERVER['HTTP_HOST'] == "172.16.0.4"){
    $host = "localhost";
	$user = "root";
	$password = "";
	$db = "db_vnr";
	error_reporting(0);
	
	define ('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/');
	define ('SITE_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/');	
	define ('SITE_IMG_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/images/');	
	define ('SITE_VEDIO_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/videos/');
	define ('ROOT_IMG_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/images/');	
	define ('SITE_DOC_PATH', 'http://'.$_SERVER['HTTP_HOST'].'/vnr/');		
	define ('SITEDOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/vnr/');	
}else
{
		$host = "dbvnr.db.5628983.64d.hostedresource.net";
	$user = "dbvnr";
	$password = "Reset!2345";
	$db = "dbvnr";
	 
	define (DOC_ROOT_PATH,'/home/content/83/5628983/html/demo/vnr/');
	define (SITE_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/vnr/');    
	define (SITE_IMG_PATH, 'http://'.$_SERVER['HTTP_HOST'].'/demo/vnr/images/');    
	define (ROOT_IMG_PATH, '/home/content/83/5628983/html/demo/vnr/images/');	
	define (SITEDOC_ROOT_PATH, '/home/content/83/5628983/html/demo/vnr/'); 
	define (SITE_DOC_PATH, 'http://'.$_SERVER['HTTP_HOST'].'demo/vnr/documents/');
}

global $mysqli;
$mysqli = new mysqli($host, $user, $password, $db);
if ($mysqli->connect_errno) {
  echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

require DOC_ROOT_PATH."includes/pagedresults.php";
require_once DOC_ROOT_PATH."includes/forClasses.php"; 
require_once DOC_ROOT_PATH."includes/functions.php"; 
$allClasses = new forClasses();
include_once DOC_ROOT_PATH."includes/objects.php"; 

//ARRAY OF PAGE NAMES TO MANAGE CONTENT...........ADD NEW PAGE NAMES AT BOTTOM ONLY.
$pages = array(
	'',
	'Home',
	'About Us',
	'Gallery',
	'Courses',
	'Jobs',
	'Gallery',
	'Online Exam',
	'Contact Us'	
);
$err=array('WP'=>'Invalid Details. Please try again.','SA'=>'Added Successfully.','FA'=>'Unable to Add. Please try again.','SE'=>'Updated Successfully.','FA'=>'Unable to Updated. Please try again.', 'DE'=>'Removed Successfully', 'SD'=>'Removed Successfully');

$items=array('gold'=>'gold','silver'=>'silver');

function generateCode($characters) {
	/* list all possible characters, similar looking characters and vowels have been removed */
	$possible = '23456789bcdfghjkmnpqrstvwxyz';
	$code = '';
	$i = 0;
	while ($i < $characters) 
	{ 
		$code .= substr($possible, mt_rand(0, strlen($possible)-1), 1);
		$i++;
	}
	return $code;
}
$_SESSION['code'] = generateCode(6);
if($_SERVER['QUERY_STRING'] != ""){
 	$current_page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
}else{
	$current_page = $_SERVER['PHP_SELF'];
}

$pgTitle="vnr Inc";
$pageTitle="vnr Inc";
$pgTitleStory="Tracking System";


//FINDING CURRENT PAGE	
$pg = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/')+1, strlen($_SERVER['PHP_SELF']));
 if($_SERVER['QUERY_STRING'] != ""){
 	$current_page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
 }else{
 	$current_page = $_SERVER['PHP_SELF'];
 }

if($pg=="index.php" || $pg=="login.php" || $pg=="register.php" || $pg=="ajax.php" || $pg=="actions.php" || $pg=="forgot.php" ){
	//$_SESSION['prev_url']="";
}else{
	$_SESSION['prev_url']=$current_page;
}
 
//Contact Details
$contact_id=777;
if ($cat = $mysqli->prepare("select mail,phone,face,linked,twitter,youtube,google_plus,addr,dt_created,web from tbl_other_links where cid =?"))
{
	$cat->bind_param('i',$contact_id );
	$cat->execute();
	$cat->store_result();
	if($cat->num_rows>0){
		$cat->bind_result($adminMail,$adminPhone,$adminFacebook,$adminLinked,$adminTwitter,$adminYoutube,$adminGPlus,$adminAddr,$adminMap,$adminWeb);
		$cat->fetch();
		$cat->close();
	}
}



?>