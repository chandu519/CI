 <div class="footer">   
      <div class="container">
          <div class="innerfooterdiv">
            <div class="footersection">
            <a href="#"><img src="images/logo1.png" alt=""></a>
          </div>

            <!--<div class="footersection">
            <ul class="footermenu">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Contact Us</a></li>
        </ul>
          </div>-->
          <div class="footersection footersection1">
            <!--<h3>Sales Inquires</h3>-->
            <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> &nbsp;&nbsp;info@excers.com</a><br><br>
            <a href="#"><i class="fa fa-phone" aria-hidden="true"></i> &nbsp;&nbsp;+1 469-804-0184 </a><br>
            <a href="#"><i class="fa fa-fax" aria-hidden="true"></i>&nbsp;&nbsp; +1 609-479-5158 </a>
          </div>
          
        
          <div class="footersection">
            <p>5600 Tennyson Pkwy,<br> suite 365,
Plano,<br> TX 75024, USA</p>
              </div>



          <div class="footersection">
            <ul class="socialicons">
              <li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="" target="_blank"><i class="fa fa-youtube"></i></a></li>
              <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
            </ul>
          </div>


        </div>

        <div class="copyright">Copyrights © 2019 &amp; Excers Inc., All Rights Reserved. | <a href="#">Sitemap</a></div>

      </div>
    </div>