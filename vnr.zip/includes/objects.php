<?php 
include_once DOC_ROOT_PATH."includes/functions.php"; 
$functions = new Functions();
?>