<div class="header fixed1" id="header">  

      <div class="header_right">
        <div class="container">
        
          <div class="logo">
            <a href="index.html"></a>
          </div>

          <div class="menu">
              <ul>
                  <li><a href="javascript:void(0);">About Us <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                    <div class="megamenu">
                        <ul>
                            <li><a href="aboutus.html">Our Company</a></li>
                            <li><a href="team.html">Our Team</a></li>
                            <li><a href="events.html">Events</a></li>
                            <li><a href="blog.html">Blog</a></li>
                        </ul>
                    </div>
                  </li>
                  <li><a href="javascript:void(0);" class="active">PPM Services <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                    <div class="megamenu">
                        <ul>
                          <li><a href="ca-ppm.html">CA PPM</a></li>
                          <li><a href="medallia.html">MEDALLIA</a></li>
                          <li><a href="servicecatalogues.html">Service Catalogues</a></li>
                          <li><a href="businessprocessgovernance.html">PPM Process & Governance</a></li>
                          <li><a href="applicationmanagementtechnology.html">Application Management & Technology</a></li>
                          <li><a href="ppmeducation.html">PPM Education</a></li>
                          <li><a href="ppmguru.html">PPM GURU</a></li>
                      </ul>
                    </div>
                  </li>
                  <li><a href="qeservices.html">QE Services <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                    <div class="megamenu">
                        <ul>
                          <li><a href="FunctionalEngineering.html">Functional Engineering</a></li>
                          <li><a href="QualityEngineering.html">Quality Engineering</a></li>
                          <li><a href="SpecializedConsulting.html">Specialized Consulting</a></li>
                      </ul>
                    </div>
                  </li>
                  <li><a href="careers.html">Careers</a></li>                        
                  <li><a href="contact.html">Contact Us</a></li>                 
                  <li><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></li>                 
              </ul>
          </div>

          </div>
      </div>
    </div>