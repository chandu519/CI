<?php 
echo date('D d M y h:i:s A');
?>