<?php
if($pg=="about.php"){ $id = "About";  }
if($pg=="services.php" ){ $id = 'pg-'.$id;  }
if($pg=="testimonials.php" ){ $id = "Testimonials";  }
if($pg=="pricing.php" ){ $id = "Pricing";  }
if($pg=="contact.php"){ $id = "Contactus";  }
if($pg=="gallery.php"){ $id = "Gallery";  }
if($pg=="refer.php"){ $id = "Reffer";  }


$query="select inc_img_id,image,title from tbl_inner_banners where prop_id=?";
$stmt = $mysqli->prepare($query);

$stmt->bind_param('s', $id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($inc_img_id,$inner_banner_img,$inner_banner_title);

if($stmt->num_rows>0){
$stmt->fetch();
    $inner_banner_img = $inner_banner_img;
}else{
	$inner_banner_img = 'banner1.jpg';
}
?>	
        <div class="ib_img" style="background-image: url(images/<?=$inner_banner_img?>);"></div>