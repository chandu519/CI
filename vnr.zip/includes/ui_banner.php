 <div class="fullbody homebanner">    
        <div id="home_banner" class="carousel carousel-fade slide" data-interval="5000" data-ride="carousel">
            <?php 
		$bannerStmt = $mysqli->prepare("SELECT b_name,b_link,b_content,b_image FROM tbl_banner WHERE b_status='1' ORDER BY b_sort_order ASC");
			$bannerStmt->execute();
			$bannerStmt->store_result();
			if($bannerStmt->num_rows>0)
			{
			$bannerStmtCount=$bannerStmt->num_rows;
		?>
			<div class="carousel-inner">
			
		<?php 
			
			$bannerStmt->bind_result($bcat_name,$blink,$bcontent,$bimage);	
			$i =1;
			while($bannerStmt->fetch())
			{
				 $bcontent = trim($bcontent);
			  $bcontent = str_replace('\"', '"', $bcontent);
			  $bcontent = str_replace("\'", "'", $bcontent);
			?>
                <div class="item <?php if($i==1){?>active <?php } ?>">
                    <img src="images/<?=$bimage?>">
                    <div class="banner_text">
                        <h2><?php echo html_entity_decode($bcat_name) ?></h2>
                        <h3><?php echo html_entity_decode($bcontent) ?></h3>
                    </div>
                </div>
				<?php $i++; }?>
         
                
            </div>
			<?php } ?>
            <a href="#home_banner" class="left carousel-control" role="button" data-slide="prev">
                <i class="fa fa-angle-left"></i>
            </a>
            <a href="#home_banner" class="right carousel-control" role="button" data-slide="next">
                <i class="fa fa-angle-right"></i>
            </a>
        </div>
    </div>